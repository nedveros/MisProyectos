<?php
	class Inicio extends CI_Controller {
		public function view($page = 'Home') {
			
			
			if ( ! file_exists('myapp/views/pages/'.$page.'.php')) {
				// no hemos creado una pagina 
				show_404();
			}
			
			//cargamos la cabecera
			$this->load->view('templates/header');
			
			$this->load->view('pages/'.$page); 
			//cargamos el cuerpo
			
		}
		public function cargarvistacabecera(){
			$idoneo = $_POST['cab'];
			
			
			if($idoneo == "Inicio"){
				$this->load->view('templates/header');
				$this->load->view('pages/Home');
			}else if($idoneo == 'Informacion'){
				$this->load->view('templates/header');
				$this->load->view('pages/VistaInformacion');
			}else if($idoneo == "Pistas"){
				$this->load->view('templates/header');
				$this->load->view('pages/selecion');
			}else if($idoneo == "Materiales"){
				$this->load->view('templates/header');
				$this->load->view('pages/seleccionMaterial');
			}else if($idoneo == "Login"){
				$this->load->view('templates/header');
				$this->load->view('pages/login');
			}else if($idoneo == "Desconectar"){
				$data = array(
					'email' => $idoneo,
					'login' => FALSE
					);
				$this->session->set_userdata($data);
				$this->load->view('templates/header');
				$this->load->view('pages/Home');
			}else if($idoneo == "VolverSelecion"){
				$this->load->view('templates/header');
				$this->load->view('pages/selecion');
			}
			else if($idoneo == "futbol" || $idoneo == "baloncesto" || $idoneo == "tenis"|| $idoneo == "padel"){
				$this->load->view('templates/header');
				$this->load->view('pages/CalendarioActividades',$_POST['cab']);
			}
			else if($idoneo == "pelotaFutbol" || $idoneo == "pelotaBaloncesto" || $idoneo == "raquetaTenis" || $idoneo == "raquetaPadel"){
				$this->load->view('templates/header');
				$this->load->view('pages/HorarioMateriales',$_POST['cab']);
			}
			
			
		}
		public function login() {
			
			
				$this->form_validation->set_rules('maillogin','e-mail','required|valid_email');      //   Configuramos las validaciones ayudandonos con la librería form_validation del Framework Codeigniter
				$this->form_validation->set_rules('passwordlogin','password','required');
				
				if(($this->form_validation->run()==FALSE)){					//   Verificamos si el usuario superó la validación
					
					$this->load->view('templates/header');
					$this->load->view('pages/login');                     //   En caso que no, volvemos a presentar la pantalla de login
				}
				else{                                       //   Si ambos campos fueron correctamente rellanados por el usuario,
				
					$this->load->model('usuarios_model');
					$ExisteUsuarioyPassoword=$this->usuarios_model->ValidarUsuario($_POST['maillogin'],$_POST['passwordlogin']);   //   comprobamos que el usuario exista en la base de datos y la password ingresada sea correcta
					if($ExisteUsuarioyPassoword){   // La variable $ExisteUsuarioyPassoword recibe valor TRUE si el usuario existe y FALSE en caso que no. Este valor lo determina el modelo.
					    
						$this->load->view('templates/header'); 
						$this->load->view('pages/Home');   //   Si el usuario ingresó datos de acceso válido, volvemos a la pagina inicia
					}
					else{   //   Si no logró validar
					   $data['error']="E-mail o password incorrecta, por favor vuelva a intentar";
					   $this->load->view('templates/header');
					   $this->load->view('pages/login',$data);   //   Lo regresamos a la pantalla de login y pasamos como parámetro el mensaje de error a presentar en pantalla
					}
				}
			
		}
		public function registrar(){
			
				$this->form_validation->set_rules('maillogin','e-mail','required|valid_email');      //   Configuramos las validaciones ayudandonos con la librería form_validation del Framework Codeigniter
				$this->form_validation->set_rules('passwordlogin','password','required');
				if(($this->form_validation->run()==FALSE)){					//   Verificamos si el usuario superó la validación
					$data['error']="no se puede validad los datos que has introducido";
					$this->load->view('templates/header');
					$this->load->view('pages/registro',$data);                     //   En caso que no, volvemos a presentar la pantalla de login
				}
				else{                                       //   Si ambos campos fueron correctamente rellanados por el usuario,
				
					$this->load->model('usuarios_model');
					$ExisteUsuarioyPassoword=$this->usuarios_model->ValidarUsuario($_POST['maillogin'],$_POST['passwordlogin']);   //   comprobamos que el usuario exista en la base de datos y la password ingresada sea correcta
					if($ExisteUsuarioyPassoword){   // La variable $ExisteUsuarioyPassoword recibe valor TRUE si el usuario existe y FALSE en caso que no. Este valor lo determina el modelo.
					    $data = array(
										'email' => $_POST['maillogin'],
										'login' => FALSE
									);
						$this->session->set_userdata($data);
						$data1['error']="Ya existe un usuario con ese correo";
						$this->load->view('templates/header');
						$this->load->view('pages/registro',$data1);
					}
					else{   //   Si no existe el usuario
						$ingresado = $this->usuarios_model->Ingresar($_POST['maillogin'],$_POST['passwordlogin'],$_POST['Nombre'],$_POST['Edad']);
						if($ingresado){
							$this->load->view('templates/header');
							$this->load->view('pages/Home');
						}else{
							$data1['error']="Ha habido algun error con la inserccion";
							$this->load->view('templates/header');
							$this->load->view('pages/registro',$data1);
						}
					   }
				}
		}
		//FUTBOL
		public function CargarHorario() {
			
			$dia=$_POST['diia'];
			$deporte=$_POST['deporte'];
			$this->load->view('templates/header');
			$this->load->view('pages/HorarioActividades',$dia,$deporte);
			
		}
		Public function ReservarHora(){
			
			$valor=$_POST["hora"];
			$d = $_POST['diia'];
			$deporte=$_POST['deporte'];
			$this->load->model('reserva_model');
			$SeHaReservado=$this->reserva_model->ReservaHoraDia($valor,$d,$deporte);
			$this->load->view('templates/header');
			$this->load->view('pages/ReciboActividades',$deporte,$d,$valor);
			
		}
		Public function PaginaMateriales(){
			$dia=$_POST['diia'];
			$deporte=$_POST['deporte'];
			
			$this->load->model('reserva_model');
			$pelotaReservada=$this->reserva_model->reservamaterial($dia,$deporte);
			$this->load->view('templates/header');
			$this->load->view('pages/ReciboMateriales',$dia,$deporte);
			
		}
		
	}
?>