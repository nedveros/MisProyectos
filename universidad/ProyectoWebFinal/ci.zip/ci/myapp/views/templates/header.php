<html>
<head>
	
	<link rel="stylesheet" href="../../../Plantilla/estilos/menuCabecera/estilo.css">
		<link rel="stylesheet" href="../../../Plantilla/estilos/prueba/style.css">
	<script src="../../../estilos/jquery-latest.js"></script>
	<script src="../../../estilos/main.js"></script>
	
	
<header>
		<div class="contenedor">
			<div id="logo" >
			<img src="../../../Plantilla/imagenes/logo.jpg" alt="">
		</div>
			<nav class="menu">
			<?php
				echo form_open('Inicio/cargarvistacabecera/'); 
				
				echo "<td><input type='submit' name='cab' value='Inicio'></td>";
				echo "<td><input type='submit' name='cab' value='Pistas'></td>";
				if( $this->session->userdata('login')){
					echo "<td><input type='submit' name='cab' value='Materiales'></td>";
				}
				echo "<td><input type='submit' name='cab' value='Login'></td>";
				if( $this->session->userdata('login')){
					echo "<td><input type='submit' name='cab' value='Desconectar'></td>";
				}
				echo "<td><input type='submit' name='cab' value='Informacion'></td>";
				echo "</form>";
				
			 ?>
					
				</ul>
			</nav>
		</div>
		
		</ div>
		
	</header>
	</head>
	</html>