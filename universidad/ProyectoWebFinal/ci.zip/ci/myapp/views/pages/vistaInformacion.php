<html>
    <head>
        <meta charset="utf-8">
        <title>Vista 12</title>
    </head>
    <body>

    <h1>Información Centro Deportivo Jaén</h1>
    <img src="../../../Plantilla/imagenes/campo.jpg" alt="">
    <h2>Instalaciones</h2>
    
    <p>Posee una serie de instalaciones para el uso y disfrute de una gran cantidad de modalidades deportivas. Pistas de Futbol, tenis, padel, baloncesto...</p>
    
    <h2>Tarifas de Uso</h2>
	<p>-Menores de 20 años -> 3€</p>
	<p>-Mayores de 20 años -> 6€</p>
	
	<h2>Horario de Apertura</h2>
	<p>Todos los días 9:00 - 15:00</p>
	
	<h2>Horario de Reservas</h2>
	<p>Todos los días 9:30 - 14:30</p>
	
	<h2>Ubicación</h2>
	<iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d201415.9500848075!2d-3.992415838760424!3d37.92752836997769!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0xd6dd7abb03f2513%3A0xa7be38790a1ecbc!2sPabell%C3%B3n+Deportivo+Universidad+de+Ja%C3%A9n!5e0!3m2!1ses!2ses!4v1495039696571" width="600" height="450" frameborder="0" style="border:0" allowfullscreen></iframe>

    </body>
</html>