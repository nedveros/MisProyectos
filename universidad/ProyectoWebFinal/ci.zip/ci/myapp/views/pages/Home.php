<html>
	<link rel="stylesheet" href="../../../Plantilla/estilos/prueba/style.css">
	
	<body>
		<div id="logo">
			<h1><a href="#">Centro deportivo Jaen</a></h1>
			<p><em>Disfruta de nuestras instalaciones cualquier dia</em></p>
		</div>
		
		<div id="page-bgtop">
		<div id="content">
			<div class="post">
				<p class="meta"><span class="date">viernes, mayo 19, 2017</span></p>
				<h2 class="title"><a href="#">Reserva de pista	</a></h2>
				<div class="entry">
					<p>No te pierdas nuestras ofertas para menores de 20 años</p>
					<p>Ahora la pista a mitad de precio!!!</p>
					<p>Pague de una forma segura con Paypal</p>
				</div>
			</div>
			<div class="post">
				<p class="meta"><span class="date">viernes, mayo 19, 2017</span></p>
				<h2 class="title"><a href="#">Reserva de material	</a></h2>
				<div class="entry">
					<p>¿necesitas algun material para disfrutar de tu deporte favorito?</p>
					<p>en nuestras instalaciones disponemos de todo lo que necesitas para disfrutar de un dia espectacular</p>
					<p>tenemos pelotas de futbol, pelotas de balonces, raquetas de tenis....</p>
				</div>
			</div>
			<div class="post">
				<p class="meta"><span class="date">viernes, mayo 19, 2017</span></p>
				<h2 class="title"><a href="#">¿no sabes donde estamos?</a></h2>
				<div class="entry">
					<p>visita nuestra pagina de informacion, donde podras encontrar todo lo que necesites saber sobre nosotros</p>
				</div>
			</div>
		</div>
		
		
		<div style="clear:both">&nbsp;</div>
	</div>
	</body>
</html>