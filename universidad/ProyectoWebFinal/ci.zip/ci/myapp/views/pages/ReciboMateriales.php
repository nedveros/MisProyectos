<html>
<head>
  <title>Vista 11</title>

</head>
	<link rel="stylesheet" href="../../../Plantilla/estilos/Recibos/tablaRecibo.css">
	<link rel="stylesheet" href="../../../Plantilla/estilos/prueba/style.css">
	<?php
		$deporte=$_POST['deporte'];
		$fecha=$_POST['diia'];
	?>
    <body>
		<p ALIGN=center><font FACE="impact" SIZE=16 COLOR="black" ><b>Datos de la reserva del material</b></font>
        <div class="page-container">
		
            <div class="pricing-table pricing-table-highlighted">
                <div class="pricing-table-header">
                    <h2>Recibo</h2>
                    <h3>Reserva de Material</h3>
                </div>
                <div class="pricing-table-space"></div>
                <div class="pricing-table-text">
                    <p><strong>SU MATERIAL HA SIDO RESERVADO </strong></p>
                </div>
                <div class="pricing-table-features">
                    <p><strong>Material: </strong><?php echo $deporte;?></p>
                    <p><strong>Fecha: </strong><?php echo $fecha;?></p>
                </div>
                <div class="pricing-table-sign-up">
                    <?php
				
				
			 ?>
                </div>
            </div>

        </div>
	</p>
    </body>

</html>










