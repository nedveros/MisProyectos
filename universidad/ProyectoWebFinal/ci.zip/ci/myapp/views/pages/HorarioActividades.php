<?php
//Conexion con la BD MySQL

	if(!($iden = mysqli_connect("localhost", "root", ""))) 
			die("Error: No se pudo conectar");
	
		// Selecciona la base de datos 
		if(!mysqli_select_db($iden,"proyectoweb")) 
				die("Error: No existe la base de datos");
			
			
?>


<style>
		#calendar2 {
			font-family:Arial;
			font-size:20px;
		}
		#calendar2 td {
			text-align:left;
			background-color:#003366;
			color:silver;
			font-size:15px;
		}
	
		
</style>

<html>
	<head>
		
	
	</head>
	<body>
		
		<?php
				echo form_open('Inicio/cargarvistacabecera/'); 
				
				echo "<td><input type='submit' name='cab' value='VolverSelecion'></td>";
				
				echo "</form>";
				
			 ?>
		
		<?php
		
		$day = $_POST['diia'];
		$deporte =$_POST['deporte'];
		
		if($deporte == "futbol"){
			$tabla = "actividadfutbol";
		}if($deporte == "baloncesto"){
			$tabla = "actividadbaloncesto";
		}if($deporte == "tenis"){
			$tabla = "actividadtenis";
		}if($deporte == "padel"){
			$tabla = "actividadpadel";
		}
		
		$consulta="SELECT * FROM $tabla WHERE dia= $day"; 
		$resultado=mysqli_query($iden,$consulta) or die("La consulta ha fallado");
		
		while ($row = mysqli_fetch_assoc($resultado)) {
			if($day == $row["dia"]){ ?>
				<?php echo form_open('Inicio/ReservarHora/');?>
					<table id="calendar2" border=1 width=400 height=400 style="position:absolute;top:150px;right:500px;">
						<tr>
							<td>
								<blockquote>
									<br></br>
												
									<?php 
										if($row["9:30 - 10:30"] == "Disponible"){
											echo "<h2><input type='radio' name='hora' value='9:30 - 10:30'> 9:30 - 10:30 ( "; echo $row["9:30 - 10:30"] ?> ) </h2><br>
											<?php 	echo "<input type='hidden' name='diia' value=$day >";
													echo "<input type='hidden' name='deporte' value=$deporte >";
											?>
										<?php }else { ?>
											<h2><s>9:30 - 10:30</s> ( <?php echo $row["9:30 - 10:30"]; ?> ) </h2><br>
											
										<?php }
										
										if($row["10:30 - 11:30"] == "Disponible"){
											echo "<h2><input type='radio' name='hora' value='10:30 - 11:30'> 10:30 - 11:30 ( "; echo $row["10:30 - 11:30"] ?> ) </h2><br>
											<?php 	echo "<input type='hidden' name='diia' value=$day >";
													echo "<input type='hidden' name='deporte' value=$deporte >";
											?>
										<?php }else { ?>
											<h2><s>10:30 - 11:30</s> ( <?php echo $row["10:30 - 11:30"]; ?> ) </h2><br>
										<?php }
												
										if($row["11:30 - 12:30"] == "Disponible"){
											echo "<h2><input type='radio' name='hora' value='11:30 - 12:30'> 11:30 - 12:30 ( "; echo $row["11:30 - 12:30"] ?> ) </h2><br>
											<?php 	echo "<input type='hidden' name='diia' value=$day >";
													echo "<input type='hidden' name='deporte' value=$deporte >";
											?>
										<?php }else { ?>
											<h2><s>11:30 - 12:30</s> ( <?php echo $row["11:30 - 12:30"]; ?> ) </h2><br>
										<?php }
												
										if($row["12:30 - 13:30"] == "Disponible"){
											echo "<h2><input type='radio' name='hora' value='12:30 - 13:30'> 12:30 - 13:30 ( "; echo $row["12:30 - 13:30"] ?> ) </h2><br>
											<?php 	echo "<input type='hidden' name='diia' value=$day >";
													echo "<input type='hidden' name='deporte' value=$deporte >";
											?>
										<?php }else { ?>
											<h2><s>12:30 - 13:30</s> ( <?php echo $row["12:30 - 13:30"]; ?> ) </h2><br>
										<?php }
												
										if($row["13:30 - 14:30"] == "Disponible"){
											echo "<h2><input type='radio' name='hora' value='13:30 - 14:30'> 13:30 - 14:30 ( "; echo $row["13:30 - 14:30"] ?> ) </h2><br>
											<?php 	echo "<input type='hidden' name='diia' value=$day >";
													echo "<input type='hidden' name='deporte' value=$deporte >";
											?>
										<?php }else { ?>
											<h2><s>13:30 - 14:30</s> ( <?php echo $row["13:30 - 14:30"]; ?> ) </h2><br>
										<?php } ?>
										
												
								</blockquote>
							</td>
						</tr>
					</table>
					<input type='submit'  value= 'Continuar' >
				<?php echo form_close();?>
				
		<?php
			}
		}
			mysqli_free_result($resultado);
				
		?>
		
	</body>
</html>