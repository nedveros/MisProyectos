
<link href="../../../style.css" rel="stylesheet" type="text/css" media="screen" />
	<link rel="stylesheet" href="../../../Plantilla/estilos/prueba/style.css">
<script language="JavaScript">
function newPage(url){
window.open(url,"","");
}
</script>
<?php echo form_open('Inicio/login/'); ?>
<!--<form action="" method="post" class="login">-->
	<div><?php
      if(isset($error)){
         echo "<p>".$error."</p>";
      }
      echo form_error('maillogin');
      ?></div>
	<div><label>E-mail</label><input type="text" name="maillogin" value="<?= set_value('maillogin'); ?>" /></div>
	<div><label>Password</label><input type="password" name="passwordlogin" value="<?= set_value('passwordlogin'); ?>"/></div>
	<div class="login"><input type="submit" value="Ingresar"></div>
	<div class="registrar"><input name="login" type="submit" value="Registrar" onClick="newPage('http://localhost/ci/index.php/Inicio/view/registro')"></div>

</form>
<?php //echo form_close();?>
