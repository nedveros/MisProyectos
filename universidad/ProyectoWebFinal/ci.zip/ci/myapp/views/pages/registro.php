<link rel="stylesheet" href="../../../Plantilla/estilos/login/LogReg.css">
<script language="JavaScript">
function newPage(url){
window.open(url,"","");
}
</script>

	<?php echo form_open('Inicio/registrar/'); ?>
	<div  class="logincuadrado">
	<div><?php
      if(isset($error)){
         echo "<p>".$error."</p>";
      }
      ?></div>
	<div class="logindiv">E-mail</label><input type="text" name="maillogin" value="<?= set_value('maillogin'); ?>" /></div>
	<div class="logindiv">Password</label><input type="password" name="passwordlogin" value="<?= set_value('passwordlogin'); ?>"/></div>
	<div class="logindiv">Nombre</label><input type="text" name="Nombre" value="<?= set_value('Nombre'); ?>"/></div>
	<div class="logindiv">Edad</label><input type="number_format" name="Edad" value="<?= set_value('Edad'); ?>"/></div>
	<div class="registrar"><input type="submit" value="Registrar"></div>
	</div>
</form>

</form>

