<html>
<head>

<link rel="stylesheet" type="text/css" href="csstabla.css" media="screen" />
</head>
<body>





<div class='centraTabla'>
 <table> 
		<?php echo form_open('Inicio/cargarvistacabecera/'); ?>
           <tr>
	           <td>
          <p><li><?php echo "<td><input type='submit' name='cab' value='pelotaFutbol'></td>";?></li></p>
          </td>
          </tr>
          
          <tr>
	          <td>
            <p><li><?php echo "<td><input type='submit' name='cab' value='pelotaBaloncesto'></td>";?></a></li></p>
            </td>
          </tr>
          <tr>
	          <td>
	          <p><li><?php echo "<td><input type='submit' name='cab' value='raquetaTenis'></td>";?></a></li></p>
	          </td>
	          </tr>
	          <tr>
		          <td>
		          <p><li><?php echo "<td><input type='submit' name='cab' value='raquetaPadel'></td>";?></a></li></p>
		          </td>
		          </tr>
		<?php echo "</form>"; ?>
        </table>


</div>
</body>
</html>