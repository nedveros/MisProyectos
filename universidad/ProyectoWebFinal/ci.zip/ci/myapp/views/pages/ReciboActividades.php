<html>
<head>
  <title>Vista 10</title>
</head>
	<link rel="stylesheet" href="../../../Plantilla/estilos/Recibos/tablaRecibo.css">
		<link rel="stylesheet" href="../../../Plantilla/estilos/prueba/style.css">
	<?php
	$deporte=$_POST['deporte'];
	$fecha=$_POST['diia'];
	$hora=$_POST['hora'];
	
	?>
    <body>
		<p><font FACE="impact" SIZE=16 COLOR="black" ><b>Datos de la reserva de la actividad</b></font></p>
        <div  class="page-container">
		
			
		
            <div class="pricing-table pricing-table-highlighted">
                <div class="pricing-table-header">
                    <h2>Recibo</h2>
                    <h3>Reserva de Pista</h3>
                </div>
                <div class="pricing-table-space"></div>
                <div class="pricing-table-text">
                    <p><strong>Comprueba que todos los campos son correctos</strong></p>
                </div>
                <div class="pricing-table-features">
                    <p><strong>Pista: </strong><?php echo $deporte;?></p>
                    <p><strong>Fecha: </strong><?php echo $fecha;?></p>
                    <p><strong>Hora: </strong><?php echo $hora;?></p>
					
					<?php if($this->session->userdata('edad')>20 || $this->session->userdata('login')== FALSE) {
						echo"<p><strong>Coste Actividad: </strong>6</p>";
						echo "<a href='https://www.paypal.me/cdeportesjaen/6'><img src='../../../Plantilla/imagenes/paypal.png'></a>";
					}else {
						echo "<a href='https://www.paypal.me/cdeportesjaen/3'><img src='../../../Plantilla/imagenes/paypal.png'></a>";
						echo "<p><strong>Coste Actividad: </strong>3</p>";
					}?>
                </div>
            </div>
        </div>

    </body>

</html>



</body>
</html>







