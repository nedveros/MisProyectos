
<?php
class reserva_model extends CI_Model{
	function ReservaHoraDia($hora,$d,$deporte){         //   Consulta Mysql para buscar en la tabla Usuario aquellos usuarios que coincidan con el mail y password ingresados en pantalla de login
		
		if(!($iden = mysqli_connect("localhost", "root", ""))) 
			die("Error: No se pudo conectar");
	
		// Selecciona la base de datos 
		if(!mysqli_select_db($iden,"proyectoweb")) 
				die("Error: No existe la base de datos");
		
		if($deporte == "baloncesto"){
			$tabla="actividadbaloncesto";
		}else if($deporte =="futbol"){
			$tabla="actividadfutbol";
		}else if($deporte =="tenis"){
			$tabla="actividadtenis";
		}else if($deporte =="padel"){
			$tabla="actividadpadel";
		}
		if($hora == "9:30 - 10:30"){
			$query = "UPDATE $tabla SET `9:30 - 10:30` = 'Ocupado' WHERE dia=$d";
			$result = mysqli_query($iden,$query) or die('Consulta fallida: ' . mysql_error());
		}
	
		if($hora == "10:30 - 11:30"){
			$query = "UPDATE $tabla SET `10:30 - 11:30` = 'Ocupado' WHERE dia=$d";
			$result = mysqli_query($iden,$query) or die('Consulta fallida: ' . mysql_error());
		}
		
		if($hora == "11:30 - 12:30"){
			$query = "UPDATE $tabla SET `11:30 - 12:30` = 'Ocupado' WHERE dia=$d";
			$result = mysqli_query($iden,$query) or die('Consulta fallida: ' . mysql_error());
		}
	
		if($hora == "12:30 - 13:30"){
			$query = "UPDATE $tabla SET `12:30 - 13:30` = 'Ocupado' WHERE dia=$d";
			$result = mysqli_query($iden,$query) or die('Consulta fallida: ' . mysql_error());
		}
	
		if($hora == "13:30 - 14:30"){
			$query = "UPDATE $tabla SET `13:30 - 14:30` = 'Ocupado' WHERE dia=$d";
			$result = mysqli_query($iden,$query) or die('Consulta fallida: ' . mysql_error());
		}
		return true;
	}
	function reservamaterial($d,$deporte){
	if(!($iden = mysqli_connect("localhost", "root", ""))) 
			die("Error: No se pudo conectar");
	
		// Selecciona la base de datos 
		if(!mysqli_select_db($iden,"proyectoweb")) 
				die("Error: No existe la base de datos");
		
		if($deporte == 'futbol'){
			$this->load->database();
			$query = $this->db->query("Update materialfutbol SET dia = 'Ocupado' Where num ='$d'");

}
			if($deporte == 'Baloncesto'){
			$this->load->database();
			$query = $this->db->query("Update materialbaloncesto SET dia = 'Ocupado' Where num ='$d'");

}

		if($deporte == 'tenis'){
			$this->load->database();
			$query = $this->db->query("Update materialtenis SET dia = 'Ocupado' Where num ='$d'");

}

		if($deporte == 'padel'){
			
			$this->load->database();
			$query = $this->db->query("Update materialpadel SET dia = 'Ocupado' Where num ='$d'");


}
		return true;
	}
}
?>