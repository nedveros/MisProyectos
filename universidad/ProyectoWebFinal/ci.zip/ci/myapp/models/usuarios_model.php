
<?php
class Usuarios_model extends CI_Model{
	function ValidarUsuario($email,$password){         //   Consulta Mysql para buscar en la tabla Usuario aquellos usuarios que coincidan con el mail y password ingresados en pantalla de login
      
		if(!($iden = mysqli_connect("localhost", "root", ""))) 
			die("Error: No se pudo conectar");
	
		// Selecciona la base de datos 
		if(!mysqli_select_db($iden,"proyectoweb")) 
				die("Error: No existe la base de datos");
			
			
		$consulta = "SELECT id,edad FROM usuarios WHERE Usuario ='$email' AND password='$password'";
		$result = mysqli_query($iden,$consulta) or die("La consulta ha fallado");
		
		$line = mysqli_fetch_array($result, MYSQLI_ASSOC);		
		if ($line['id'] > '0' ){
			$data = array(
					'email' => $email,
					'login' => TRUE,
					'edad'  => $line['edad']
					);
			$this->session->set_userdata($data);
			
			
			return true;
		}else{
			return false;
		}
	}
	function Ingresar($email,$password,$nombre,$edad){
		if(!($iden = mysqli_connect("localhost", "root", ""))) 
			die("Error: No se pudo conectar");
	
		// Selecciona la base de datos 
		if(!mysqli_select_db($iden,"proyectoweb")) 
				die("Error: No existe la base de datos");
			
			
		$consulta = "SELECT id FROM usuarios WHERE Usuario ='$email' AND password='$password'";
		$result = mysqli_query($iden,$consulta) or die("La consulta ha fallado");
		
		$line = mysqli_fetch_array($result, MYSQLI_ASSOC);		
		if ($line['id'] > '0' ){
			//si lo encuentra es que ya esta registrado, con lo cual, no se puede registrar
			echo "hemos encontrado un repetido";
			return false;
		}else{
			//si no lo encuentra es porque no esta registrado, con lo cual, le permite que se registre
					$this->load->database();
	$query = $this->db->query("INSERT INTO usuarios VALUES('','$email','$password','$nombre','$edad')");
	echo $query;
			return true;
		}
	}
}
?>