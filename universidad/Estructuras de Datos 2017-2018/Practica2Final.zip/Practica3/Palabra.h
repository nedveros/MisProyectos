/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   Palabra.h
 * Author: nedveros
 *
 * Created on 26 de septiembre de 2017, 15:31
 */

#ifndef PALABRA_H
#define PALABRA_H
#include <string>
#include <iostream>
using namespace std;
class Palabra {
public:
    Palabra();
    Palabra(const Palabra& orig);
    virtual ~Palabra();
    void SetTermino(string Termino);
    string GetTermino() const;
private:
    string Termino;
};

#endif /* PALABRA_H */

