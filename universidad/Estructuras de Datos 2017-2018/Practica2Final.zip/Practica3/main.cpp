/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   main.cpp
 * Author: nedveros
 *
 * Created on 26 de septiembre de 2017, 15:18
 */

#include <cstdlib>
#include "Diccionario.h"
#include "Vdinamico.h"

#include <stdio.h>
#include <string.h>
using namespace std;

/*
 * 
 */
int main(int argc, char** argv) {
   
    Diccionario d("listado-sin-acentos.txt");
    d.insertar("porcuna");
    std::cout <<d.buscar("porcuna")<<endl;
    d.borrar(80382);
    d.mostrarDatosDiccionario();
    return 0;
}

