/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   Vdinamico.cpp
 * Author: nedveros
 * 
 * Created on 26 de septiembre de 2017, 15:19
 */

#include "Vdinamico.h"
