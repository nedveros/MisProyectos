/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   Palabra.cpp
 * Author: nedveros
 * 
 * Created on 26 de septiembre de 2017, 15:31
 */

#include "Palabra.h"

Palabra::Palabra() {
}

Palabra::Palabra(const Palabra& orig) {
}

Palabra::~Palabra() {
}

void Palabra::SetTermino(string Termino) {
    this->Termino = Termino;
}

string Palabra::GetTermino() const {
    return Termino;
}

