/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   Vdinamico.h
 * Author: nedveros
 *
 * Created on 26 de septiembre de 2017, 15:19
 */

#ifndef VDINAMICO_H
#define VDINAMICO_H
#include <math.h>
#include "Palabra.h"
#include"FueraRango.h"
template <class T>
class Vdinamico {
public:
   
//    void SetTamaf(int tamaf);
//    int GetTamaf() const;
//    void SetTamal(int tamal);
//    int GetTamal() const;
//    void SetVector(T* vector);

Vdinamico() {
    
        tamal = 0;
        vector = new T[tamaf = 1];
}

Vdinamico(const Vdinamico& orig) {

     vector = new T[tamaf = orig.tamaf];
        tamal = orig.tamal;
        for (int i = 0; i < tamal; i++) {
            vector[i] = orig.vector[i];
        }


}

Vdinamico(int tamano){

    tamaf = Potencia (tamano );
    tamal = 0;
    vector = new T [tamaf];

    
    }

   Vdinamico<T>(const Vdinamico<T>& origen, unsigned inicio, unsigned num) {
        
        try {
            if (inicio < 0 || inicio + num > origen.tamaf) {
                throw"el valor esta fuera de rango";
            }
            
            tamal = num;
            tamaf = num;
            vector = new T [num];
            
            for (int i = inicio; i < inicio + num; i++) {
                
                vector[i - inicio] = origen.vector[i]; //si pones vector[i] se sale del vector
                
                
            }
            
        } catch (const char* msg) {
            cout << msg << endl;
        }
        
    }




int Potencia(int tamano ){
    int i =0;
    int valor=0;
    while(valor < tamano){
        
        
    
      valor =  pow(2,i);
     
      i++;
    
    }

    return valor;
    


}

T &operator[](unsigned i){

    return vector[i];

}


~Vdinamico() {
    if (vector)
        delete []vector;
};

void SetTamaf(int tamaf) {
    this->tamaf = tamaf;
}

int GetTamaf() const {
    return tamaf;
}

void SetTamal(int tamal) {
    this->tamal = tamal;
}

int GetTamal() const {
    return tamal;
}

void SetVector(T* vector) {
    this->vector = vector;
}

T* GetVector() const {
    return vector;
}

void insertar(T &dato){
    //std::cout << "entra en insertar de Vdinamico, tamaño lógico: "<< tamal << "tamaño fisico: "<< tamaf << endl;
    if(tamal == 0){         // si el tamaño logico es 0, es la primera vez que insertamos dato por tanto lo anadimos en la primera posicion del vector  
       vector[0] = dato; 
    }else{                  // si el tamaño logico  no es 0 tenemos que añadir por la posicion siguiente;
        vector[tamal] = dato;
    }
    tamal++;
    if (tamaf == tamal) {       //si el tamaño fisico es igual que el lógico significa que tenemos que expandir el vectorDinamico *2 
                
        aumentaTama();
        T* aux = new T[tamaf];          // vector auxiliar para no perder los datos al destruir el que se queda pequeño y crear uno mas grande.

        for (int i = 0; i < tamal; i++) {
            aux[i] = vector[i];
        }

        delete [] vector;
        vector = aux;
    }
    //std::cout << "finaliza en insertar de Vdinamico, tamaño lógico: "<< tamal << "tamaño fisico: "<< tamaf << endl;
}
//void insertar(T &dato, int pos){ //para que este metodo funcione con el mostarDiccionario de la clase diccionario hay que ordenar el vector no dejar huecos en blanco.
//    //std::cout << "tamaño logico: "<< tamal<< endl;
//    if(pos <tamaf){
//        //std::cout << "Entra en el if pos<tamaf"<< endl;
//        for(int i = tamal+1; i<pos;i--){
//            vector[i+1]=vector[i];
//        }
//        vector[pos] = dato;
//    }else{
//        //std::cout << "Posicion no existente"<<endl;
//    }
//    //std::cout << "incrementa tamal"<< endl;
//    tamal++;
//    if (tamaf == tamal) {       //si el tamaño fisico es igual que el lógico significa que tenemos que expandir el vectorDinamico *2 
//                
//        tamaf = tamaf * 2;
//        T* aux = new T[tamaf];          // vector auxiliar para no perder los datos al destruir el que se queda pequeño y crear uno mas grande.
//
//        for (int i = 0; i < tamal; i++) {
//            aux[i] = vector[i];
//        }
//
//        delete [] vector;
//        vector = aux;
//    }
//    //std::cout << "tamaño logico: "<< tamal<<" y tamaño fisico "<<tamaf<< endl;
//    //std::cout << "finaliza en insertar de Vdinamico, tamaño lógico: "<< tamal << "tamaño fisico: "<< tamaf << endl;
//}

void insertar(const T &dato, unsigned pos) {

    if (pos == UINT_MAX) {

        if (tamal == tamaf) {
            aumentaTama();
        }
        vector[tamal] = dato;
    } else {
        if (pos >= tamal)
            throw FueraRango();

            if (tamal == tamaf) {
                aumentaTama();
            }

        for (long int i = tamal - 1; i >= pos; i--) {
            vector[i + 1] = vector[i];
        }
        vector[pos] = dato;
    }
    tamal++;
};

void borrar(int pos){
    for(int i = pos; i<tamal; i++){
        vector[i]= vector[i+1];
    }
    tamal--;
}


void aumentaTama() {
    T *vaux;
    vaux = new T[tamaf = tamaf * 2];
    for (unsigned i = 0; i < tamal; i++)
        vaux[i] = vector[i];
    delete []vector;
    vector = vaux;
};

/*
 * @brief disminuye el tamaf si tamal sea 1/3 de tamaf
 * @pre estar el vector dinamico creado 
 * @return devuelve un entero
 */

int disminuyeTama() {
    tamaf = tamaf / 2;
    T *vaux = new T[tamaf];
    for (unsigned i = 0; i < tamal; i++) {
        vaux[i] = vector[i];
    };
    delete []vector;
    vector = vaux;
};


private:
    T *vector;
    int tamal;
    int tamaf;

};

#endif /* VDINAMICO_H */

