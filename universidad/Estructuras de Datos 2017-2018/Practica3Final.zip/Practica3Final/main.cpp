/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   main.cpp
 * Author: nedveros
 *
 * Created on 24 de octubre de 2017, 2:18
 */

#include <cstdlib>
#include "ListaEnlazada.h"
#include "Palabra.h"
#include <iostream>
#include "Diccionario.h"
using namespace std;

/*
 * 
 */
int main(int argc, char** argv) {
   //char* rutaChar = "listado-sin-acentos.txt";
  Diccionario d("listado-sin-acentos.txt");
//    Palabra m,j,f;
//    f.SetTermino("aa");
//    j.SetTermino("loco");
//    j.nuevoSucesor("yo");
//    j.nuevoSucesor("no");
//    j.sucesores();
//    m.SetTermino("a");
//     d.insertar(j);
//     d.insertar(m);
//     d.insertar(f);
//   
//    
//    d.busqueda_binaria(0,d.GET_tamano(),"loco");
//    cout<<d.GET_tamano();
//   
//    

//  d.entrena("goku es un saiyan y hace la kamekameha");
//  d.entrena("goku es un saiyan y hace la kamekameha");
//    
//    
  int pos;  
  d.usaCorpus("corpus-david.txt");
  d.quicksort(0,d.GET_tamano());
 

  d.mostrarSucesores(41096);
  
    
    
    

    
      
    
    
    
    return 0;
}

