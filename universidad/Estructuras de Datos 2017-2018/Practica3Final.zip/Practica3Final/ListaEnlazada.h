/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   ListaEnlazada.h
 * Author: nedveros
 *
 * Created on 23 de octubre de 2017, 0:15
 */
#include <iostream>
using namespace std;
#ifndef LISTAENLAZADA_H
#define LISTAENLAZADA_H
template<class T>
class ListaEnlazada;//sin esto la friend class no funciona
template<typename T>
class Nodo{
public:
    T dato;
    Nodo *sig;
    Nodo(const T &aDato,Nodo *aSig=0)
    {dato=aDato;sig=aSig;}
    ~Nodo(){}
};
template <class T>
class Iterador {
     
    friend class ListaEnlazada<T>;
    public:
        Nodo<T> *nodo;
        Iterador(Nodo<T> *aNodo) : nodo(aNodo) {}
        bool fin() { return nodo == 0; }
        void siguiente() {
        nodo = nodo->sig;
        }
        T &dato() {
            return nodo->dato; 
        }
};

template<typename T>
class ListaEnlazada {
    public:
    Nodo<T> *cab,*cola;
 
    ListaEnlazada():cab(0),cola(0){}
    
    ~ListaEnlazada(){}
    void borrarFinal();
    void insertarFinal(const T &dato);
    void inserta(Iterador<T> &i, T&dato);
    void insertarInicio(const T &dato);
    ListaEnlazada(const ListaEnlazada<T> &lista);

    void borra(Iterador<T> &i);
    
    T& inicio();
    T& Fin();
    
    ListaEnlazada<T> &operator=(const ListaEnlazada<T> &l) {
    Nodo<T> *p = cab;
    while (p != 0) {
        borrarInicio();
        p = cab;
    }
    cab = 0;
    cola = 0;
    p = l.cab;

    while (p != 0) {
        insertarFinal(p->dato); 
        p = p->sig;
    }
    return (*this);
}
    void borrarInicio() ;
   
  

    

};
    




template<class T>
void ListaEnlazada<T>::insertarFinal(const T &dato) {
    Nodo<T> *nuevo;
    nuevo = new Nodo<T>(dato, 0);
    if (cab == 0)
        cab = nuevo; 

    if (cola != 0)
        cola->sig = nuevo;

    cola = nuevo;
}
template<class T>
ListaEnlazada<T>::ListaEnlazada(const ListaEnlazada<T> &lista) {
    Nodo<T> *p;
    cab = 0;
    cola = 0;
    p = lista.cab;
    Nodo<T> *nuevo;
    while (p != 0) {
        
          nuevo = new Nodo<T>(p->dato, 0);
    if (cab == 0)
        cab = nuevo; 

    if (cola != 0)
        cola->sig = nuevo;

    cola = nuevo;
   
        p = p->sig;
    }
}

template<class T>
void ListaEnlazada<T>::borrarInicio() {
    if (cab) {
        Nodo<T> *borrado = cab;
        cab = cab->sig;
        delete borrado;
        if (cab == 0){
            cab=0;
       
            cola = 0;}
    }
}

template<class T>
T& ListaEnlazada<T>::inicio(){

    if(cab!=0){
        
    return cab->dato;
        
        
    }
    
    std::cout<<"esta vacia la lista"<<std::endl;
     
    return cab->dato;


}


template<class T>
T& ListaEnlazada<T>::Fin(){

    
  if(cab!=0){
        
    return cola->dato;
        
        
    }
    
    std::cout<<"esta vacia la lista"<<std::endl;
     
    return cola->dato;



}
template<class T>
void ListaEnlazada<T>::inserta(Iterador<T> &i, T&dato){
    Iterador<ListaEnlazada> it;
    it=cab;
    
    while(it.siguiente() == i){
    
        it++;
    }
    
    *it=dato;

}

template<class T>
void ListaEnlazada<T>::insertarInicio(const T &dato) {
    Nodo<T> *nuevo;
    Nodo<T> *aux;
    nuevo = new Nodo<T>(dato, 0);
    if (cola == 0) {
        cola = nuevo;
    }
    if (cab != 0) {
        aux=cab;
        cab=nuevo;
        cab->sig=aux;
    }
    cab = nuevo;
};

template<class T>
void ListaEnlazada<T>::borrarFinal() {

    
    int contador=0;
            Nodo<T> *anterior = 0;
            if (cab != cola) {
                anterior = cab;
                while (anterior->sig != cola){
                    contador++;
                    std::cout<<contador<<std::endl;
                    anterior = anterior->sig;
                }
            }
            delete cola;
            cola = anterior;
            if (anterior != 0){
                anterior->sig = 0;
            }else{
               cab = 0; 
            }

    
}

template<class T>
void ListaEnlazada<T>::borra(Iterador<T> &i){
Nodo<T> *borrado = i;
Nodo<T> *anterior=cab;
while(anterior->sig != i){

    anterior=anterior->sig;

}

anterior->sig=i.nodo->sig;

}





#endif /* LISTAENLAZADA_H */

