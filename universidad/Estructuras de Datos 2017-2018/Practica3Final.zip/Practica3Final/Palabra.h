/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   Palabra.h
 * Author: nedveros
 *
 * Created on 26 de septiembre de 2017, 15:31
 */

#ifndef PALABRA_H
#define PALABRA_H
#include <string>
#include <iostream>
#include "ListaEnlazada.h"
#include "Sucesores.h"
using namespace std;
class Palabra {
public:
    Palabra();
    Palabra(const Palabra& orig);
    virtual ~Palabra();
    void SetTermino(string Termino);
    string GetTermino() const;
    void nuevoSucesor(string termino){
    
    
        siguientes.insertarFinal(termino);
    
    }
    void sucesores(){
        Iterador<string> it = siguientes.cab;
        int cont=0;
        while(!it.fin()){
        
            std::cout<<cont <<it.dato()<<" de la Palabra "<<Termino<<std::endl;
            it.siguiente();
            cont++;
        
        }
    
    
    
    
    }
    
  
    
private:
    string Termino;
    ListaEnlazada <string> siguientes;
};

#endif /* PALABRA_H */

