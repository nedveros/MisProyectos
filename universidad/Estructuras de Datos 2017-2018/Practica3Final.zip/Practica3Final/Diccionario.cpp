/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   Diccionario.cpp
 * Author: Usuario
 * 
 * Created on 4 de octubre de 2017, 21:05
 */

#include "Diccionario.h"

Diccionario::Diccionario() {
    
}
Diccionario::Diccionario(char* ruta) {
   //  ruta = "listado-sin-acentos.txt";
    Palabra p;
    std::fstream fe; //Creamos el flujo de entrada
    std::string linea;
    int total = 0;
    //Asociamos el flujo de un fichero y lo abrimos
    fe.open(ruta);
    if(fe.good()){
        //Mientras no se haya llegado al final del fichero
        while(!fe.eof()){
            getline(fe, linea); //toma una linea del fichero
            if(linea!=""){  //ignoramos lineas en blanco
                //std::cout << linea<<std::endl;
                p.SetTermino(linea);
                diccionarioVector.insertar(p);
                total++;
            }

        }
        std::cout << "Total de palabras en el archivo: "<< total<< std::endl;
    }else{
        std::cerr << "No se puede abrir el fichero" << std::endl;
    }
    
    
}

Diccionario::Diccionario(const Diccionario& orig) {
}

Diccionario::~Diccionario() {
}

