/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   Sucesores.cpp
 * Author: nedveros
 * 
 * Created on 24 de octubre de 2017, 2:31
 */

#include "Sucesores.h"

Sucesores::Sucesores() {
}

Sucesores::Sucesores(const Sucesores& orig) {
}

Sucesores::~Sucesores() {
}

void Sucesores::SetNum_ocurrencias(int num_ocurrencias) {
    this->num_ocurrencias = num_ocurrencias;
}

int Sucesores::GetNum_ocurrencias() const {
    return num_ocurrencias;
}

void Sucesores::SetTermino(std::string termino) {
    this->termino = termino;
}

std::string Sucesores::GetTermino() const {
    return termino;
}

