/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   Diccionario.h
 * Author: Usuario
 *
 * Created on 4 de octubre de 2017, 21:05
 */

#ifndef DICCIONARIO_H
#define DICCIONARIO_H
#include "Vdinamico.h"
#include <fstream>
#include <cstdlib>
#include <string>       // std::string
#include <iostream>     // std::cout
#include <sstream>  
class Diccionario {
public:
    Diccionario();
    Diccionario(char *ruta);
    Diccionario(int tam);
    Diccionario(const Diccionario& orig);
    virtual ~Diccionario();
    
    void insertar(Palabra &p){
        diccionarioVector.insertar(p);
        quicksort(0,diccionarioVector.GetTamal()-1);
    }
    void insertar(Palabra &p, int pos){
        diccionarioVector.insertar(p,pos);
        quicksort(0,diccionarioVector.GetTamal()-1);
    }
    void insertar(string dato){
        Palabra p;
        p.SetTermino(dato);
        diccionarioVector.insertar(p);
        quicksort(0,diccionarioVector.GetTamal()-1);
    }
    void insertar(string dato, int pos){
        Palabra p;
        p.SetTermino(dato);
        diccionarioVector.insertar(p,pos);
        quicksort(0,diccionarioVector.GetTamal()-1);
    }
    void mostrarDatosDiccionario(){
        int tam = diccionarioVector.GetTamal();
        for(int i = 0; i<tam; i++){
            std::cout << diccionarioVector[i].GetTermino() <<endl;
        }
    }
    
    void mostrarSucesores(int pos){
        
        
            diccionarioVector[pos].sucesores();
        
    }
    
    
    
    
    
    
    void mostrarDatosDiccionario(int pos){
        std::cout << diccionarioVector[pos].GetTermino() <<endl;
    }
    void mostrarDatosDeTodasLasPosicionesFisicas(){
        int tam = diccionarioVector.GetTamaf();
        for(int i = 0; i<tam; i++){
            std::cout << diccionarioVector[i].GetTermino() <<endl;
        }
    }
    
    void borrar(int pos){
        diccionarioVector.borrar(pos);
    }
    void leerDiccionario(){ // inserta las palabras de listado-general.txt a nuestro vector dinamico.
        Palabra p;
        std::fstream fe; //Creamos el flujo de entrada
        std::string linea;
        int total = 0;
        //Asociamos el flujo de un fichero y lo abrimos
        fe.open("listado-general.txt");
        if(fe.good()){
            //Mientras no se haya llegado al final del fichero
            while(!fe.eof()){
                getline(fe, linea); //toma una linea del fichero
                if(linea!=""){  //ignoramos lineas en blanco
                    //std::cout << linea<<std::endl;
                    p.SetTermino(linea);
                    diccionarioVector.insertar(p);
                    total++;
                }

            }
            std::cout << "Total de palabras en el archivo: "<< total<< std::endl;
        }else{
            std::cerr << "No se puede abrir el fichero" << std::endl;
        }
    }
    int buscar (string dato) const {
        int pos = 0;
        for(int i = 0; i<diccionarioVector.GetTamal(); i ++){
            if(diccionarioVector.GetVector()[i].GetTermino() == dato){
                return pos;
            }
            pos++;
        }
        return -1; // Si no encuentra el dato devuelve -1
    }
    
     void quicksort(int comienzo,int final){
 
     int derecha;
     string pivote;
     int izquierda;
     izquierda=comienzo;
     derecha =final;
     pivote = diccionarioVector[(comienzo + final)/2].GetTermino();
     while(izquierda < derecha ){
     
         while(diccionarioVector[izquierda].GetTermino() < pivote ) izquierda++;
         while (diccionarioVector[derecha].GetTermino() > pivote )derecha--;
         Palabra Ptemporal;
         Palabra Ptemporal2;
         if (izquierda <= derecha ) {
             string temporal = diccionarioVector[izquierda].GetTermino();
             Ptemporal.SetTermino(diccionarioVector[derecha].GetTermino());
             diccionarioVector[izquierda].SetTermino(Ptemporal.GetTermino());
             Ptemporal2.SetTermino(temporal);
             diccionarioVector[derecha].SetTermino(Ptemporal2.GetTermino());
             izquierda++;
             derecha--;
         }
     }
     if (comienzo < derecha ) quicksort(comienzo,derecha);
     if (izquierda < final )quicksort(izquierda,final);
    
         }
     
         int busqueda_binaria(int inicio, int final, string x)
    {
        
        int medio = 0;
        bool flag = false;
        while((inicio < final) && (!flag))
        {
            medio = (inicio + final) / 2;
            //para comparar usamos compare() de string
            //std::cout<<diccionario[medio]->GetTermino();
            if(x.compare(diccionarioVector[medio].GetTermino()) > 0) inicio = medio + 1;
            else if(x.compare(diccionarioVector[medio].GetTermino()) < 0) final = medio - 1;
            else flag = true;
        }
        if(flag) {cout << "Elemento" <<" "<< x << " "<<"encontrado en la posicion " << medio << endl;
            return medio;
        }
        else {cout << "El elemento no esta en la lista" << endl;
            return -1;
        }
    }
          int GET_tamano(){
    
        return diccionarioVector.GetTamal();
        
    }
          
          
    void entrena(string cadena){
    
    
    std::cout<<GET_tamano()<<std::endl;
    
    string palabra;
    string palabra2;
    stringstream ss;
    int total;
    ss<<cadena;
    while(!ss.eof()){
        ss>>palabra;
        
        if(palabra!=""){
            int buscador;
            //cout<<++total<<" "<<palabra<<endl;
            buscador=busqueda_binaria(0,GET_tamano(),palabra);
            
            if(buscador == -1){
                Palabra p;
                p.SetTermino(palabra);
                diccionarioVector.insertar(p);
                quicksort(0,diccionarioVector.GetTamal()-1);
            
            
            }else{
                ss>>palabra2;
                buscador=busqueda_binaria(0,GET_tamano(),palabra);
                diccionarioVector[buscador].nuevoSucesor(palabra2);
                std::cout<<"he metido el sucesor "<<palabra2<<" de la palabra "<<palabra<<std::endl;
            
            
            
            }
            
            
            
            palabra="";
        
        
        }
        
  
    
    }
    
    std::cout<<GET_tamano()<<std::endl;

    }      
          
      void usaCorpus(string ruta){
      
        //  ruta = "listado-sin-acentos.txt";
    Palabra p;
    std::fstream fe; //Creamos el flujo de entrada
    std::string linea;
    int total = 0;
    //Asociamos el flujo de un fichero y lo abrimos
    fe.open(ruta);
    if(fe.good()){
        //Mientras no se haya llegado al final del fichero
        while(!fe.eof()){
            getline(fe, linea); //toma una linea del fichero
            
            entrena(linea);
               
            

        }
        std::cout << "Total de palabras en el archivo: "<< total<< std::endl;
    }else{
        std::cerr << "No se puede abrir el fichero" << std::endl;
    }
      
      
      }
      
      
        void escribir(){
  

    }
      
      
      
      
      
      
private:
    Vdinamico<class Palabra>  diccionarioVector;

};

#endif /* DICCIONARIO_H */

