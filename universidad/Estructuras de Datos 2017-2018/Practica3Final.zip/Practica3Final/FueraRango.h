/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   FueraRango.h
 * Author: Alejandro Gómez
 *
 * Created on 11 de octubre de 2016, 8:45
 */

#ifndef FUERARANGO_H
#define FUERARANGO_H

#include <exception>

using namespace std;

class FueraRango:public exception{
public:
    const char* what() const throw()
    {
        return "\nError: La posicion se sale del vector, de rango";
    }
};


#endif /* FUERARANGO_H */

