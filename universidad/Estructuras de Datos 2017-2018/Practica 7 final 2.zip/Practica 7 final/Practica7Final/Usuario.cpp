/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   Usuario.cpp
 * Author: nedveros
 * 
 * Created on 17 de noviembre de 2017, 10:55
 */
#include <sstream>
#include "Usuario.h"
#include "Palabra.h"
#include "Sucesores.h"
#include "TextoPredictivo.h"
#include "Diccionario2.h"
#include<vector>
#include <list>
using namespace std;
Usuario::Usuario(std::string id,std::string nombre,TextoPredictivo *tp):id(id),nombre(nombre), tp(tp) ,MiDic(){
   
    
}

void Usuario::setTp(TextoPredictivo* tp) {
   this->tp = tp;
}

TextoPredictivo* Usuario::getTp() const {
    return tp;
}


Diccionario2 Usuario::getMiDic() const {
    return MiDic;
}

void Usuario::setNombre(string nombre) {
    this->nombre = nombre;
}

string Usuario::getNombre() const {
    return nombre;
}

void Usuario::setId(string id) {
    this->id = id;
}

string Usuario::getId() const {
    return id;
}

Usuario::Usuario(const Usuario& orig):id(orig.id),nombre(orig.nombre),tp(orig.tp),MiDic(orig.MiDic) {
    
}

Usuario::~Usuario() {
}


 void Usuario::Escribe_Frase(string cadena){
 
 
     
             
   
        

       //     if(tp->GetDicBase().buscar()[palabra].Termino == palabra){
     
         //       tp->GetDicBase().entrenar(palabra,palabrasiguiente);
                
        //    }else{
                
                MiDic.entrenar(cadena);
                
          //  }
     
     
        
        
     
        
  
    
    }
    
  
std::list<Sucesores>Usuario::SucesoresPAlabra(Usuario u,string cadena){

return u.getTp()->Sugerencia(cadena);
    
}
    
std::list<Sucesores>Usuario::Sugerencia(string cadena){
  
    Palabra p;
    p.SetTermino(cadena);
    unsigned long clave= p.djb2(p.GetTermino());
  
    
    if(MiDic.getMAPPalabra()[cadena].GetTermino() == cadena  && tp->GetDicBase().GetDiccionario().buscar(clave,p)){
//    if (MiDic.getMAPPalabra()[cadena].GetTermino() == cadena && tp->GetDicBase().getMAPPalabra()[cadena].GetTermino()==cadena){
//        list<Sucesores> lista = MiDic.getMAPPalabra()[cadena].sucesores();
        list<Sucesores> lista =  MiDic.getMAPPalabra()[cadena].sucesores();
         list<Sucesores> lista2 = tp->GetDicBase().GetDiccionario().tabla[tp->GetDicBase().GetDiccionario().posicion(clave,p)].dato.sucesores();
//        list<Sucesores> lista2 = tp->GetDicBase().getMAPPalabra()[cadena].sucesores();
       
       
        list<Sucesores> listaDefinitiva;
        list<Sucesores>::iterator it= lista.begin();
        list<Sucesores>::iterator it2 = lista2.begin();
        int cont =0 ;
        while(cont < 5 && it != lista.end()){
            
            listaDefinitiva.push_back((*it));
            
            it++;
            cont++;
        }
        cont=0;
        while(cont < 5 && it2 != lista2.end()){
            
            listaDefinitiva.push_back((*it2));
            
            it2++;
            cont++;
        }
        //std::cout<<"entro1";
        return listaDefinitiva;
        
    }
    
    
    else if (MiDic.getMAPPalabra()[cadena].GetTermino() == cadena
              && tp->GetDicBase().GetDiccionario().buscar(clave,p) == false){
    
       // std::cout<<"entro2";
        return MiDic.getMAPPalabra()[cadena].sucesores();
    
    
    }else if (MiDic.getMAPPalabra()[cadena].GetTermino() != cadena
              && tp->GetDicBase().GetDiccionario().buscar(clave,p) == true){
       // std::cout<<"entro3";
        return tp->GetDicBase().GetDiccionario().tabla[tp->GetDicBase().GetDiccionario().posicion(clave,p)].dato.sucesores();
    
    }
    //std::cout<<"entro4";
    list<Sucesores> listavacia;
    return listavacia;
    
}

std::list<Sucesores>Usuario::Sugerenciasdicbase(string cadena){
    Palabra p;
    p.SetTermino(cadena);
    unsigned long clave = p.djb2(p.GetTermino());

   // return getTp()->GetDicBase().getMAPPalabra()[cadena].sucesores();
    //return getTP()->GetDicBase().GetDiccionario().tabla[getTp()->GetDicBase().GetDiccionario().posicion(clave,p)].dato.sucesores();
return tp->GetDicBase().GetDiccionario().tabla[tp->GetDicBase().GetDiccionario().posicion(clave,p)].dato.sucesores();


}
         
 
void Usuario::escribe(){
    list<Sucesores> lista;
    string lcRepetirPrograma;
    vector<string> vector;
    int pos;
    
    
    do {
        std::cout<<"***************************"<<std::endl;
        std::cout<<"- escribe para terminar - exit -"<<std::endl;
        std::cout<<"- escribe para borrar texto - clear -"<<std::endl;
        std::cout<<"- para crear usuario escriba - new -"<<std::endl;
        std::cout<<"- listar usuarios - list -"<<std::endl;
        std::cout<<"- cambiar de usuario - change -"<<std::endl;
        std::cout<<"- ver numero de elementos - Nelementos -"<<std::endl;
        std::cout<<"- ver media de las colisiones - Pcolisiones -"<<std::endl;
        std::cout<<"- ver numero maximo de colisiones -Mcolisiones -"<<std::endl;
        std::cout<<"- Ver factor de carga - Fcarga -"<<std::endl;
        std::cout<<"- Usuario cargado <"<<getNombre()<<">"<<" con id "<<getId()<<std::endl;
        std::cout<<"*******************************************************"<<std::endl;
       
        std::cout<<"--------------------------------------------------------"<<std::endl;
        std::cout<<"--------------------------------------------------------"<<std::endl;
        std::cout<<"--------------------------------------------------------"<<std::endl;
        for(int i =0 ; i < vector.size();i++){
            std::cout<<vector[i]<<" ";
        }
        std::cin >>lcRepetirPrograma;
        if(lcRepetirPrograma== "clear"){
        
            vector.clear();
            lcRepetirPrograma="";
        }
        if(lcRepetirPrograma == "new"){
            string id;
            string usuario;
            std::cout<<"introduce el id"<<std::endl;
            cin>>id;
            std::cout<<"introduce el nombre del usuario"<<std::endl;
            cin>>usuario;
            tp->NuevoUsuario(id, usuario);
            tp->getusuario(id).escribe();
            
        }
        if(lcRepetirPrograma == "Nelementos"){
            std::cout<<"numero de elementos en Diccionario base "<<tp->GetDicBase().GetDiccionario().tamaTabla()<<std::endl;
            std::cout<<"numero de elementos en el diccionario de "<<nombre<<" "<<MiDic.numeronodos();
            vector.clear();
            lcRepetirPrograma="";
        }
        if(lcRepetirPrograma == "Pcolisiones"){
        
            std::cout<<"colisiones en el diccionario base "<<tp->GetDicBase().GetDiccionario().colisiones_media()<<std::endl;

            vector.clear();
            lcRepetirPrograma="";
        
        }
        if(lcRepetirPrograma == "Mcolisiones"){
            std::cout<<"colisiones maximas del diccionario base "<<tp->GetDicBase().GetDiccionario().getmaxima()<<std::endl;
          
            vector.clear();
            lcRepetirPrograma="";
        
        }
        if(lcRepetirPrograma == "Fcarga"){
        
            std::cout<<"el factor de carga del diccionario base "<<tp->GetDicBase().GetDiccionario().factorCarga()<<std::endl;
          
            vector.clear();
            lcRepetirPrograma="";
        
        
        }
        
        
        if(lcRepetirPrograma == "list"){
        
            tp->listarUsuarios();
            vector.clear();
            lcRepetirPrograma="";
        
        }
        if(lcRepetirPrograma== "change"){
            string id;
            tp->listarUsuarios();
        
            std::cout<<"elige el id de usuario"<<std::endl;
            cin >> id;
            
            tp->getusuario(id).escribe();
            vector.clear();
        }
        //pos=busqueda_binaria(0,vectorDiccionario.size(),lcRepetirPrograma
        //Palabra p,t;
       // p.SetTermino(lcRepetirPrograma);
        string aux="";
        for(int i =0 ; i < vector.size();i++){
            aux+=vector[i]+" ";
        }
        Escribe_Frase(aux);
        //lista=vectorDiccionario[pos].sucesores();
        
        lista=Sugerencia(lcRepetirPrograma);
        list<Sucesores>::iterator it = lista.begin();
        while(it != lista.end()){
            
            std::cout<<"numero de ocurrencias "<<(*it).num_ocurrencias << " palabra " <<(*it).termino<<std::endl;
            it++;
        }
        vector.push_back(lcRepetirPrograma);
        
        if(lcRepetirPrograma=="exit"){
            exit(0);
        }
        
        
        
        
    } while (lcRepetirPrograma !="exit");
    
    
    
    
    
}





