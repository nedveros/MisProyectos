/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   THashCerrada.h
 * Author: nedveros
 *
 * Created on 3 de diciembre de 2017, 23:51
 */

#ifndef THASHCERRADA_H
#define THASHCERRADA_H
#include "Entrada.h"
#include <vector>
using namespace std;

class THashCerrada {
public:
    THashCerrada(unsigned long tam);
    THashCerrada(const THashCerrada& orig);
    virtual ~THashCerrada();
    unsigned FHash(unsigned long clave, int conteo);
    unsigned FuncionDisper(unsigned long clave, int i);
    bool insertar(unsigned long clave, const Palabra& dato);
    bool borrar(unsigned long clave, Palabra &dato);
    unsigned long posicion (unsigned long clave,Palabra &dato);
    bool buscar(unsigned long clave, Palabra &dato);
    void comparamaxima(unsigned long i);
    float colisiones_media();
    unsigned long getmaxima();
    unsigned tamaTabla();
    float factorCarga();
    unsigned long transforma(unsigned long num);
    unsigned long maxima;
    unsigned long  colisiones;
    unsigned long tamafisico;
    unsigned long tamalogico;
    vector<Entrada > tabla;
};

#endif /* THASHCERRADA_H */

