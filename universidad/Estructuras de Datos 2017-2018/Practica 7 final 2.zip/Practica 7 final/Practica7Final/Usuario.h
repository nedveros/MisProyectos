/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/*
 * File:   Usuario.h
 * Author: nedveros
 *
 * Created on 17 de noviembre de 2017, 10:55
 */

#ifndef USUARIO_H
#define USUARIO_H
#include <iostream>
#include "Diccionario.h"
#include "Diccionario2.h"
#include <fstream>
#include <cstdlib>
#include <sstream>



using namespace std;

class TextoPredictivo; //sin llaves XD


class Usuario {
public:
    Usuario(std::string id,std::string nombre,TextoPredictivo *tp);
    Usuario(const Usuario& orig);
    virtual ~Usuario();
 
    
    
    void setMiDic(Diccionario2 MiDic);
    Diccionario2 getMiDic() const;
    void setNombre(string nombre);
    string getNombre() const;
    void setId(string id);
    string getId() const;
    
    bool operator<(Usuario &rc)const {
        return nombre< rc.nombre;
    }
    
    bool operator>(Usuario &rc)const {
        return nombre > rc.nombre;
    }
    
    bool operator==(Usuario &rc)const {
        return nombre == rc.nombre;
    }
    
    std::list<Sucesores> Sugerencia(string cadena);
    
    std::list<Sucesores> Sugerenciasdicbase(string cadena);
    
    std::list<Sucesores> SucesoresPAlabra(Usuario u,string cadena);
    
    void Escribe_Frase(string cadena);
    void entrena(string cadena);
    void setTp(TextoPredictivo* tp);
    
    TextoPredictivo* getTp() const;
    void escribe();
private:
    string id;
    string nombre;
    Diccionario2 MiDic;
    TextoPredictivo *tp;
};

#endif /* USUARIO_H */

