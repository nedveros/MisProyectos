/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   Entrada.cpp
 * Author: nedveros
 * 
 * Created on 3 de diciembre de 2017, 23:53
 */

#include "Entrada.h"

Entrada::Entrada(): disponible(true), clave(0) {
}
Entrada::Entrada(unsigned long aClave, const Palabra &aDato) : clave(aClave), dato(aDato), disponible(false) {
    }
Entrada::Entrada(const Entrada& orig):clave(orig.clave),dato(orig.dato),disponible(orig.disponible){}


Entrada::~Entrada() {
}

   bool Entrada::operator<(Entrada &rc)const {
            return clave < rc.clave;
        }
    bool Entrada::operator>(Entrada &rc)const {
        return clave > rc.clave;
    }
    bool Entrada::operator==(Entrada &rc)const {
        return clave == rc.clave;
    }
    
//    Entrada& Entrada::operator=(const Entrada &rhs) {
//    if (&rhs == this) return *this;
//
//    clave = rhs.clave;
//    dato = rhs.dato;
//    disponible=rhs.disponible;
//
//    return *this;
//
//
//
//}
