/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   Diccionario2.h
 * Author: nedveros
 *
 * Created on 5 de diciembre de 2017, 13:28
 */

#ifndef DICCIONARIO2_H
#define DICCIONARIO2_H
#include "Palabra.h"

#include <fstream>
#include <cstdlib>
#include <sstream>  
#include <map>
class Diccionario2 {
public:
    Diccionario2();
    Diccionario2(const Diccionario2& orig);
    virtual ~Diccionario2();
      void insertar(Palabra &p);
    Diccionario2(char *ruta);
    
   
    void entrenar(string cadena);

    void inorden() {
        map<string,Palabra>::iterator it;
        it=MAPPalabra.begin();
        while(it!= MAPPalabra.end()){
        
            std::cout<<(*it).second.Termino<<std::endl;
            it++;
        
        
        }
        

    }
    
    void nuevoSucesor(string termino ,string cadena){
    
        MAPPalabra[termino].nuevoSucesor(cadena);
        
    
    }

  
    void usaCorpus(char* ruta);
 

    void escribe();
    int numeronodos(){
    
        return MAPPalabra.size();
    }
    void setMAPPalabra(map<string, Palabra> MAPPalabra);
    map<string, Palabra> getMAPPalabra() const;
private:
map<string,Palabra> MAPPalabra;
};

#endif /* DICCIONARIO2_H */

