/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   THashCerrada.cpp
 * Author: nedveros
 * 
 * Created on 3 de diciembre de 2017, 23:51
 */

#include "THashCerrada.h"

THashCerrada::THashCerrada(unsigned long tam) : tamafisico(tam), tabla(tamafisico, Entrada()), tamalogico(0), colisiones(0), maxima(0) {
}

THashCerrada::THashCerrada(const THashCerrada& orig) : tamafisico(orig.tamafisico), tamalogico(orig.tamalogico), tabla(orig.tabla), colisiones(orig.colisiones), maxima(orig.maxima) {
}

THashCerrada::~THashCerrada() {
}

unsigned THashCerrada::FHash(unsigned long clave, int conteo) {

    unsigned long valor;
    unsigned long bin = clave % 10;
    bin = transforma(bin);

    return valor = (bin + clave + (1 * conteo)) % tamafisico;


}

unsigned THashCerrada::FuncionDisper(unsigned long clave, int i) {
    unsigned long posicionfinal;
    posicionfinal = (clave + (i * i)) % tamafisico;
    return posicionfinal;
}

bool THashCerrada::insertar(unsigned long clave, const Palabra& dato) {
    unsigned long i = 0;
    unsigned long pos;
    int intentos = 10;
    bool encontrado = false;
    while (!encontrado && i < intentos) {
        // pos = FHash(clave, i);
        pos = FuncionDisper(clave, i);
        if (tabla[pos].disponible == true) {
            Entrada elem(clave, dato);
            tabla[pos] = elem;
            encontrado = true; //Encontre un sitio libre  
            //cout << "ha insertado en el intento numero: " << i << " en la posicion " << pos << endl;
        } else
            ++i; //No he dado aun con una posicion libre
    }
    if (!encontrado) {
        return false;
    }
    tamalogico++;
    colisiones = colisiones + i;
    comparamaxima(i);

    return true;
}

bool THashCerrada::borrar(unsigned long clave, Palabra &dato) {
    bool enc = false;
    unsigned long pos;
    for (int i = 0; i < 10; i++) {
      
        if (enc == false) {
           
            //pos = FHash(clave, i);
            pos = FuncionDisper(clave, i);
           
            if (tabla[pos].dato == dato) {
               
                //dato encontrado
                tabla[pos].disponible == true;
                tabla[pos].dato.SetTermino("");
               
                tamalogico--;
                dato = tabla[pos].dato;
              
                enc = true;

                cout << "dato encontrado en el intento: " << i << endl;
                break;

            }
        }
    }
    if (enc == false) {
        return false;
    } else {

        return true;
    }
}

bool THashCerrada::buscar(unsigned long clave, Palabra &dato) {
    unsigned long i = 0, pos = 0;
    bool enc = false;
    for (; i < 10; i++) {
        if (enc == false) {
            //pos = FHash(clave, i);
            pos = FuncionDisper(clave, i);
            if (tabla[pos].dato == dato) {
                if (tabla[pos].disponible == false) {
                    enc = true; //lo encontre y salgo del bucle
                    dato = tabla[pos].dato;
                   // cout << "Encontrado en el intento: " << i << " en la posicion " << pos << endl;
                    return true;
                } else {
                    return false;
                }
            }
        }
    }
    return enc;
}

void THashCerrada::comparamaxima(unsigned long i) {

    if (i > maxima) {
        maxima = i;
    }


}

float THashCerrada::colisiones_media() {

    float valor = (float)colisiones / tamalogico;


    return valor;
}

unsigned long THashCerrada::getmaxima() {

    return maxima;

}

unsigned THashCerrada::tamaTabla() {
    return tamalogico;
}

float THashCerrada::factorCarga() {
    float result;
    float a = tamalogico;
    float b = tamafisico;
    result = a / b;
    return result;
    //return (float) tamal/tamaf;
}

unsigned long THashCerrada::transforma(unsigned long num) {
switch (num) {
         case 1:
            return 1;
            break;
        case 2:
            return 10;
            break;
        case 3:
            return 11;
            break;
        case 4:
            return 100;
            break;
        case 5:
            return 101;
            break;
        case 6:
            return 110;
            break;
        case 7:
            return 111;
            break;
        case 8:
            return 1000;
            break;
        case 9:
            return 1001;
            break;
        default:
            return 0000;
            break;
    }
}

unsigned long THashCerrada::posicion(unsigned long clave, Palabra& dato) {

    unsigned long i = 0, pos = 0;
    bool enc = false;
    for (; i < 10; i++) {
        if (enc == false) {
            //pos = FHash(clave, i);
            pos = FuncionDisper(clave, i);
            if (tabla[pos].dato == dato) {
                if (tabla[pos].disponible == false) {
                    enc = true; //lo encontre y salgo del bucle
                    dato = tabla[pos].dato;
                   // cout << "Encontrado en el intento: " << i << " en la posicion " << pos << endl;
                    return pos;
                } else {
                    pos = -1;
                    return pos;
                }
            }
        }
    }
    return enc;
    
    
    
    
}
