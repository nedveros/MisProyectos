/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   main.cpp
 * Author: nedveros
 *
 * Created on 1 de diciembre de 2017, 2:15
 */


#include "THashCerrada.h"
#include "Diccionario.h"
#include "Palabra.h"
#include <fstream>
#include <cstdlib>
#include <sstream>  
#include <string>     // std::string, std::stol
#include "Entrada.h"
#include <ctime>
#include "TextoPredictivo.h"
using namespace std;

/*
 * 
 */
int main(int argc, char** argv) {


//string ruta = "primos.txt";
//std::fstream fe; //Creamos el flujo de entrada
// std::string linea;
//        fe.open(ruta);
//    if(fe.good()){
//        //Mientras no se haya llegado al final del fichero
//        while(!fe.eof()){
//       
//            getline(fe, linea); //toma una linea del fichero
//            if(linea!=""){  //ignoramos lineas en blanco
//                unsigned long tama ;
//                 
//                tama = std::stol(linea);
//                std::cout<<tama;
//    unsigned t0,t1;
//    t0=clock();
//    
   
 
//                 unsigned long tama = 188527;
//////   // unsigned long tama =255173;
//                  Diccionario d(tama);
//                  Palabra p ; 
//                  p.SetTermino("david");
//                  unsigned long clave = p.djb2(p.GetTermino());
//                  d.GetDiccionario().insertar(clave,p);
//                  std::cout<<"la posicion en la que esta despues de la busqueda es "<<d.GetDiccionario().posicion(clave,p)<<std::endl;
//                  d.entrenar("david baudet moreno");
//                  list<Sucesores> lista = d.GetDiccionario().tabla[d.GetDiccionario().posicion(clave,p)].dato.sucesores();
//                    list<Sucesores>::iterator it=lista.begin();
//                    while(it != lista.end()){
//                    
//                        std::cout<<(*it).GetTermino()<<std::endl;
//                        it++;
//                    }
//    
//                     std::cout<<d.GetDiccionario().tamaTabla()<<std::endl;
//                     std:cout<<d.GetDiccionario().factorCarga()<<std::endl;
                     
//                     t1=clock();
//    double time = (double(t1-t0)/CLOCKS_PER_SEC);
//    std::cout<<"******************************************************************************************"<<std::endl;
//    std::cout << "tiempo ejecucion Practica 6" << time <<"tiempo ejecucion Practica 5 4 minutos "<< endl;
//    std::cout<<d.GetDiccionario().factorCarga()<<std::endl;
    
//    std::cout<<"el tamaño de la tabla es "<<d.GetDiccionario().tamaTabla()<<std::endl;
//    std::cout<<"colsisiones media "<<d.GetDiccionario().colisiones_media()<<std::endl;
//    std::cout<<"colisiones maximas "<<d.GetDiccionario().getmaxima()<<std::endl;

//    string nombre;
//    nombre="insertados.txt";
//    fstream fs;
//    fs.open(nombre.c_str(), ios::app);
//    fs <<  d.GetDiccionario().tamaTabla() <<endl;
//    fs.close();
//    
//                 
//     
//            }
//
//        }
//      
//    }

//   
//    Palabra p;
//    p.SetTermino("david");
//    unsigned long clave = p.djb2(p.GetTermino());
//    unsigned long tama=11111;
//    THashCerrada tabla(tama);
//    tabla.insertar(clave,p);
//    
//    if (tabla.buscar(clave,p)){
//    
//        std::cout<<"lo he encontrado";
//    
//    }
//   

    
//    
//                   //unsigned long tama = 188527;
//                   unsigned long tama = 287557;
//
//                  Diccionario d(tama);
//                  d.escribe();
//    
    
    
      
    unsigned t0,t1;
    t0=clock();
    TextoPredictivo *pt = new TextoPredictivo();
    pt->NuevoUsuario("1", "david");
    pt->NuevoUsuario("2", "miguel");
    
    string id="1";
      string id2="2";
    pt->getusuario(id).Escribe_Frase("de algebra");
    pt->getusuario(id).Escribe_Frase("de discreta");
    pt->getusuario(id2).Escribe_Frase("de metaeuristica");
    pt->getusuario(id2).Escribe_Frase("de grafica");
    t1=clock();
    double time = (double(t1-t0)/CLOCKS_PER_SEC);
    std::cout<<"******************************************************************************************"<<std::endl;
    std::cout << "tiempo ejecucion Practica 7" << time <<"tiempo ejecucion Practica 5 4 minutos "<< endl;
    std::cout<<"******************************************************************************************"<<std::endl;
   
    pt->getusuario(id).escribe();
    
    
    
    
    
    
    return 0;
}

