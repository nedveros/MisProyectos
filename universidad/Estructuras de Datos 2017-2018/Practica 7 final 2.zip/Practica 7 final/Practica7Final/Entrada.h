/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   Entrada.h
 * Author: nedveros
 *
 * Created on 3 de diciembre de 2017, 23:53
 */

#ifndef ENTRADA_H
#define ENTRADA_H
#include <climits>
#include "Palabra.h"


class Entrada {
public:
    Entrada();
     Entrada(unsigned long aClave, const Palabra &aDato);
    Entrada(const Entrada& orig);
    bool operator<(Entrada &rc)const;
    bool operator>(Entrada &rc)const;
    bool operator==(Entrada &rc)const;
    
     Entrada& operator=(const Entrada& right) {
        // Check for self-assignment!
        if (this != &right) {
            
            dato = right.dato;
            disponible = right.disponible;

            
        }
        return *this;
     }
    virtual ~Entrada();

unsigned long clave;
    Palabra dato;
    bool disponible;
};

#endif /* ENTRADA_H */

