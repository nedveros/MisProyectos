/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   Diccionario.h
 * Author: nedveros
 *
 * Created on 2 de diciembre de 2017, 15:37
 */

#ifndef DICCIONARIO_H
#define DICCIONARIO_H
#include "THashCerrada.h"
#include <fstream>
#include <cstdlib>
#include <sstream>  


class Diccionario {
public:
     Diccionario(unsigned long tama);
     Diccionario();
  

    Diccionario(const Diccionario& orig);
    virtual ~Diccionario();
    void SetDiccionario(THashCerrada diccionario);
    THashCerrada& GetDiccionario();
    void entrenar(string cadena);
     void usaCorpus(char* ruta);
     void escribe();
   
private:
    THashCerrada diccionario;
};

#endif /* DICCIONARIO_H */

