/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   TextoPredictivo.h
 * Author: nedveros
 *
 * Created on 13 de noviembre de 2017, 23:30
 */

#ifndef TEXTOPREDICTIVO_H
#define TEXTOPREDICTIVO_H
#include "Diccionario.h"
#include <list>

class TextoPredictivo {
public:
    TextoPredictivo();
    TextoPredictivo(char* ruta);
    TextoPredictivo(const TextoPredictivo& orig);
    virtual ~TextoPredictivo();
    std::list<Sucesores> sugerencia(string cadena){
        Palabra p;
        p.SetTermino(cadena);
        return diccidioma.dsucesores(p);
    
    }
    void entrena(string cadena){
    
    
        diccidioma.entrenar(cadena);
    
    }
    
    void escribe(){
    
    
        diccidioma.escribe();
    
    }
    
    
    
private:
    void usaCorpus(char* ruta){
    
        diccidioma.usaCorpus(ruta);
    
    }
    Diccionario diccidioma;
};

#endif /* TEXTOPREDICTIVO_H */

