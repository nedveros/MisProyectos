#ifndef AVL_h
#define AVL_h
#include <iostream>
using namespace std;

template <typename U>
class Nodo {
public:
    Nodo<U> *izq, *der;
    U dato;
    char bal;

    Nodo(U &ele) : izq(0), der(0), bal(0), dato(ele) {
    }

    Nodo(const Nodo& orig) : dato(orig.dato), izq(orig.izq), der(orig.der), bal(orig.bal) {
    }
};

template <typename T>
class AVL {
    Nodo<T> *raiz;
private:
    void Paltura(Nodo<T>* p, int nivel, int &result);
    int inserta(Nodo<T>* &c, T &dato);
    void rotDecha(Nodo<T>* &p);
    void rotIzq(Nodo<T>* &p);
    void inorden(Nodo<T> *p, int contador);
    void BorraAVL(Nodo<T>* &p);
    Nodo<T>* buscarClave(T& dato, Nodo<T> *p);
    void CopiaAVL(Nodo<T>* p, Nodo<T> &origen);
    void Pnumeronodos(Nodo<T>* p, int &numero);
public:

    AVL() {
        raiz = 0;
    }
    bool inserta(T &dato);
    bool buscar(T &ele, T &result);

    int altura();
    void recorreInorden();
    AVL<T>& operator=(AVL<T> &a);
    int numeronodos();
    T* buscarañadir(T& dato);

    virtual ~AVL() {
        BorraAVL(raiz);
    }
};

template<typename T>
bool AVL<T>::inserta(T& dato) {


    // AumentaNodos();
    return inserta(raiz, dato);



}
template<typename T>
T* AVL<T>::buscarañadir(T& dato){

    T* re=0;
    Nodo<T> *p = buscarClave(dato,raiz);
    if(p){
    
        re=&p->dato;
        
    }

    return re;





}




template<typename T>
void AVL<T>::rotIzq(Nodo<T>* &p) {
    Nodo<T> *q = p, *r;
    p = r = q->der;
    q->der = r->izq;
    r->izq = q;
    q->bal++;
    if (r->bal < 0) q->bal += -r->bal;
    r->bal++;
    if (q->bal > 0) r->bal += q->bal;
}

template<typename T>
void AVL<T>::rotDecha(Nodo<T> * &p) {
    Nodo<T> *q = p, *l;
    p = l = q->izq;
    q->izq = l->der;
    l->der = q;
    q->bal--;
    if (l->bal > 0)q->bal -= l->bal;
    l->bal--;
    if (q->bal < 0)l->bal -= -q->bal;



}

template<typename T>
int AVL<T>::inserta(Nodo<T> * &c, T &dato) {

    Nodo<T> *p = c;
    int deltaH = 0;
    if (!p) {

        p = new Nodo<T>(dato);
        c = p;
        deltaH = 1;


    } else if (dato > p->dato) {
        if (inserta(p->der, dato)) {
            p->bal--;
            if (p->bal == -1)deltaH = 1;
            else if (p->bal == -2) {
                if (p->der->bal == 1)rotDecha(p->der);
                rotIzq(c);
            }

        }
    } else if (dato < p->dato) {
        if (inserta(p->izq, dato)) {
            p->bal++;
            if (p->bal == 1)deltaH = 1;
            else if (p->bal == 2) {
                if (p->izq->bal == -1)
                    rotDecha(c);
            }
        }
    }

    return deltaH;

}

template <typename T>
void AVL<T>::Pnumeronodos(Nodo<T>* p, int &numero) {

    if (p != 0) {
        numero++;
        Pnumeronodos(p->izq, numero);

        Pnumeronodos(p->der, numero);
    }

}
template <typename T>
int AVL<T>::altura() {
    int nivelanterior = 0;
    Paltura(raiz, 0, nivelanterior);
    return nivelanterior;
}

template <typename T>
void AVL<T>::recorreInorden() {
    inorden(raiz, 0);
}

template <typename T>
void AVL<T>::inorden(Nodo<T> *p, int contador) {

    if (p) {

        inorden(p->izq, contador + 1);
        std::cout << p->dato << "nivel  " << contador << " ";
        inorden(p->der, contador + 1);

    }

}

template <typename T>
void AVL<T>::Paltura(Nodo<T>* p, int nivel, int &nivelanterior) {
    if (p != 0) {
        Paltura(p->izq, nivel++, nivelanterior);
        if (nivel > nivelanterior)
            nivelanterior = nivel;
        Paltura(p->der, nivel++, nivelanterior);
    }
}

template <typename T>
void AVL<T>::BorraAVL(Nodo<T>* &p) {

    if (p != 0) {
        BorraAVL(p->izq);
        BorraAVL(p->der);
        delete p;

        p = 0;
    }
}
template <typename T>
Nodo<T>* AVL<T>::buscarClave(T &dato, Nodo<T> *p) {
    
    if (!p)
        return 0;
    else if (dato < p->dato)
        return buscarClave(dato, p->izq);
    else if (dato > p->dato)
        return buscarClave(dato, p->der);
    
    else return p;

}

template<typename T>
bool AVL<T>::buscar(T &ele, T &result) {

    Nodo<T> *p = buscarClave(ele, raiz);
    if (p) {
        result = p->dato;
        return true;

    }

    return false;

}

template<typename T>
AVL<T>& AVL<T>::operator=(AVL<T> &a) {

    BorraAVL(raiz);
    CopiaAVL(raiz, a);



}

template <class T>
void AVL<T>::CopiaAVL(Nodo<T>* p, Nodo<T> &origen) {
    Nodo<T> *nuevo = new Nodo<T> (origen);
    CopiaAVL(p->izq, nuevo);
    if (p->izq == 0) {
        nuevo->izq = 0;
    }
    CopiaAVL(p->izq, nuevo);
}

template <typename T>
int AVL<T>::numeronodos() {
    int num = 0;

    Pnumeronodos(raiz, num);
    return num;
}

#endif /* AVL_h */
