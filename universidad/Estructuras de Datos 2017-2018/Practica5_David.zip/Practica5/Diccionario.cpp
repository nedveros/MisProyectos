/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   Diccionario.cpp
 * Author: nedveros
 * 
 * Created on 31 de octubre de 2017, 3:26
 */

#include "Diccionario.h"

Diccionario::Diccionario() {
}
Diccionario::Diccionario(char* ruta) {
   
    //char* rutaChar = "listado-general.txt";
    Palabra p;
    std::fstream fe; //Creamos el flujo de entrada
    std::string linea;
    int total = 0;
    //Asociamos el flujo de un fichero y lo abrimos
    fe.open(ruta);
    if(fe.good()){
        //Mientras no se haya llegado al final del fichero
        while(!fe.eof()){
           // std::vector<Palabra>::iterator it = vectorDiccionario.begin();
            getline(fe, linea); //toma una linea del fichero
            if(linea!=""){  //ignoramos lineas en blanco
                //std::cout << linea<<std::endl;
                p.SetTermino(linea);
                //vectorDiccionario.push_back(p);
                AVLDiccionario.inserta(p);
                total++;
            }

        }
        std::cout << "Total de palabras en el archivo: "<< total<< std::endl;
    }else{
       // std::cerr << "No se puede abrir el fichero" << std::endl;
    }
   // std::cout<<vectorDiccionario.size();
   // std::cout << "Tamaño logico: "<< tamal<< "tamaño fisico: "<< tamaf<<endl;
}

Diccionario::Diccionario(const Diccionario& orig) {
}

Diccionario::~Diccionario() {
}

void Diccionario::insertar(Palabra &p) {

    Palabra j;
    if (AVLDiccionario.buscar(p, j)) {

        //std::cout << "esta insertado" << std::endl;

    } else {

        AVLDiccionario.inserta(p);
       // std::cout << "se inserto " << std::endl;
    }





}


     
     
         void Diccionario::entrenar(string cadena){
             
    string palabra;
    string palabrasiguiente;
    stringstream ss;
    stringstream ss2;
    int total;
    ss<<cadena;
    ss2<<cadena;
    ss2>>palabrasiguiente;
   
    while(!ss.eof()){
        
        
       ss>>palabra; 
       
      if(!ss2.eof()){ 
      ss2>>palabrasiguiente;
      }
        if(palabra!=""){
            int buscador;
            bool resultado;
            Palabra p,t;
            p.SetTermino(palabra);
            //cout<<++total<<" "<<palabra<<endl;
           // buscador=busqueda_binaria(0,vectorDiccionario.size(),palabra);
            resultado=AVLDiccionario.buscar(p,t);

            if(resultado == false){
               // vector<Palabra>::iterator it=vectorDiccionario.begin()+buscador;
                Palabra p;
                p.SetTermino(palabra);
                AVLDiccionario.inserta(p);
                //vectorDiccionario.insert(it,p);
                
                //ss2>>palabrasiguiente;
                if(palabra != palabrasiguiente){
                //vectorDiccionario[buscador].nuevoSucesor(palabrasiguiente);
                AVLDiccionario.buscarañadir(p)->nuevoSucesor(palabrasiguiente);
                }
                
            }
            
            else{
            //hay que buscar si el sucesor ya existe
            //si existe le añadimos uno a al sucesor 
            //si no existe lo añadimos
            Palabra p;
                p.SetTermino(palabra);
                //ss2>>palabrasiguiente;
                if(palabra != palabrasiguiente){
//                vectorDiccionario[buscador].nuevoSucesor(palabrasiguiente);
                AVLDiccionario.buscarañadir(p)->nuevoSucesor(palabrasiguiente);
                }
            }
     
            palabra="";
        
        
        }
        
  
    
    }
    
  
         
         
         
         
         
         
         
         
         
         
         }

            void Diccionario::usaCorpus(char* ruta){
            
            
            
              
    //char* rutaChar = "listado-general.txt";
    
    std::fstream fe; //Creamos el flujo de entrada
    std::string linea;
    int total = 0;
    //Asociamos el flujo de un fichero y lo abrimos
    fe.open(ruta);
    if(fe.good()){
        //Mientras no se haya llegado al final del fichero
        while(!fe.eof()){
            
            getline(fe, linea); //toma una linea del fichero
            if(linea!=""){  //ignoramos lineas en blanco
                //std::cout << linea<<std::endl;
                //
                entrenar(linea);
                //std::cout<<total<<std::endl;
                total++;
            }

        }
        std::cout << "Total de palabras en el archivo: "<< total<< std::endl;
    }else{
       // std::cerr << "No se puede abrir el fichero" << std::endl;
    }
            
            
            
            }



             void Diccionario::escribe(){
                 list<Sucesores> lista;
               string lcRepetirPrograma;
                 vector<string> vector;
                 int pos;
               
             
  do {
      std::cout<<"***************************"<<std::endl;
      std::cout<<"escribe salir para terminar"<<std::endl;
      for(int i =0 ; i < vector.size();i++){
          std::cout<<vector[i]<<" ";
      }
      std::cin >>lcRepetirPrograma;
      //pos=busqueda_binaria(0,vectorDiccionario.size(),lcRepetirPrograma
      Palabra p,t;
      p.SetTermino(lcRepetirPrograma);
      Diccionario::AVLDiccionario.buscar(p,t);
      //lista=vectorDiccionario[pos].sucesores();
      lista=Diccionario::dsucesores(t);
      list<Sucesores>::iterator it = lista.begin();
      while(it != lista.end()){
      
          std::cout<<"numero de ocurrencias "<<(*it).num_ocurrencias << " palabra " <<(*it).termino<<std::endl;
          it++;
      }
      vector.push_back(lcRepetirPrograma);
      
      
      
      
      
      
    } while (lcRepetirPrograma !="salir");
             
             
             
             
             
             }
