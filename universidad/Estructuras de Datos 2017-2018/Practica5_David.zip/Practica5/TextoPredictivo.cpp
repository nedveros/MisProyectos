/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   TextoPredictivo.cpp
 * Author: nedveros
 * 
 * Created on 13 de noviembre de 2017, 23:30
 */

#include "TextoPredictivo.h"

TextoPredictivo::TextoPredictivo() {
}

TextoPredictivo::TextoPredictivo(char* ruta) {
    
     //char* rutaChar = "listado-general.txt";
    Palabra p;
    std::fstream fe; //Creamos el flujo de entrada
    std::string linea;
    int total = 0;
    //Asociamos el flujo de un fichero y lo abrimos
    fe.open(ruta);
    if(fe.good()){
        //Mientras no se haya llegado al final del fichero
        while(!fe.eof()){
           // std::vector<Palabra>::iterator it = vectorDiccionario.begin();
            getline(fe, linea); //toma una linea del fichero
            if(linea!=""){  //ignoramos lineas en blanco
                //std::cout << linea<<std::endl;
                p.SetTermino(linea);
                //vectorDiccionario.push_back(p);
               // AVLDiccionario.inserta(p);
                diccidioma.insertar(p);
                total++;
            }

        }
        std::cout << "Total de palabras en el archivo: "<< total<< std::endl;
    }else{
       // std::cerr << "No se puede abrir el fichero" << std::endl;
    }
   // std::cout<<vectorDiccionario.size();
   // std::cout << "Tamaño logico: "<< tamal<< "tamaño fisico: "<< tamaf<<endl;
    
    
    diccidioma.usaCorpus("corpus.txt");
    
}

TextoPredictivo::TextoPredictivo(const TextoPredictivo& orig) {
}

TextoPredictivo::~TextoPredictivo() {
}

