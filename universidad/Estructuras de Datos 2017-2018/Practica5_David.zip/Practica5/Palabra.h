/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   Palabra.h
 * Author: nedveros
 *
 * Created on 26 de septiembre de 2017, 15:31
 */

#ifndef PALABRA_H
#define PALABRA_H
#include <string>
#include <iostream>
#include <list>
#include <queue> 
#include "Sucesores.h"

using namespace std;

class Palabra {
    friend ostream &operator<<(ostream &, const Palabra &);
public:

    string Termino;
    list <Sucesores> siguientes;
    Palabra();
    Palabra(const Palabra& orig);
    virtual ~Palabra();
    void SetTermino(string Termino);
    string GetTermino() const;
    //int operator<(const Palabra &rhs);
    bool operator<(Palabra &rc)const {
            return Termino < rc.Termino;
        }
    bool operator>(Palabra &rc)const {
        return Termino > rc.Termino;
    }
    bool operator==(Palabra &rc)const {
        return Termino == rc.Termino;
    }
    //int operator>(const Palabra &rhs);

   // int operator==(const Palabra &rhs)const;
    Palabra& operator=(const Palabra &rhs);


        void aumentarSucesores(string p){
            
           list<Sucesores>::iterator it = siguientes.begin();
            
            while(it != siguientes.end()){
            
                if((*it).termino  == p){
                
                    (*it).num_ocurrencias +1;
                
                }
            
            
            }
        
        
        
        
        
        
        }
        void nuevoSucesor(string termino){
            list<Sucesores>::iterator itSucesores = siguientes.begin();
            bool encontrado = false;
            while(itSucesores!=siguientes.end()){
                
                if((*itSucesores).termino== termino){
                    //std::cout << "entra en el if de que el sucesor existe: "<<(*itSucesores).termino<<endl;
                    encontrado = true;
                    (*itSucesores).num_ocurrencias++;
                }
                itSucesores++;
            }
          
            if(!encontrado){
                Sucesores nuevo;
                nuevo.termino=termino;
                nuevo.num_ocurrencias = 1;
                siguientes.push_back(nuevo);
            }
            
            
        
        }
        std::list<Sucesores> sucesores(){
           list<Sucesores>::iterator it = siguientes.begin();
            std::priority_queue<Sucesores> orden;
            int cont =0;
            
            while(it != siguientes.end()){
                Sucesores nuevo;
                nuevo.num_ocurrencias= (*it).num_ocurrencias;
                nuevo.termino=(*it).termino;
                orden.push(nuevo);
                it++;
            
            }
            
           
            list<Sucesores> lista; 
           
            
            while(!orden.empty() && cont<10){
                Sucesores muestra = orden.top();
                orden.pop();
                Sucesores aux;
                aux.SetNum_ocurrencias(muestra.num_ocurrencias);
                aux.SetTermino(muestra.termino);
                lista.push_back(aux);
             
                cont++;
            
            }
            
            return lista;
        
        }
         
};

#endif /* PALABRA_H */

