/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   main.cpp
 * Author: nedveros
 *
 * Created on 13 de noviembre de 2017, 1:56
 */

#include <cstdlib>
#include "Diccionario.h"
#include <iostream>
#include "Palabra.h"
#include <list>
#include "TextoPredictivo.h"
#include <ctime> 

using namespace std;

/*
 * 
 */
int main(int argc, char** argv) {
       // AVL<Palabra> arbol;
//       Palabra num;
//       Palabra num3;
//       num3.SetTermino("zafra");
//       Palabra num4;
//       num4.SetTermino("mendoza");
//       Palabra num5;
//       num5.SetTermino("pablo");
//        num5.nuevoSucesor("melon");
//       num.SetTermino("david");
//       
//        arbol.inserta(num);
//        arbol.inserta(num3);
//        arbol.inserta(num4);
//        arbol.inserta(num5);
//        
//        Palabra num2;
//        num2.SetTermino("pablo");
//        arbol.recorreInorden();
//        Palabra r;
//        Palabra r2;
//      
//       
//       
//
//         
//        arbol.buscarañadir(num2)->nuevoSucesor("infame");
//bool resultado =arbol.buscar(num2,r);
//        list<Sucesores> d = r.sucesores();
//        list<Sucesores>::iterator it;
//        it = d.begin();
//        while(it != d.end()){
//        
//            std::cout<<"h "<<(*it).GetTermino()<<std::endl;
//            it++;
//        
//        }
        
//        
//        std::cout<<"numero de nodos "<<arbol.numeronodos()<<std::endl;
//        
//       if(resultado == false){
//           std::cout<<"no lo encontro"<<std::endl;
//       }else{std::cout<<"lo encontro"<<r.GetTermino()<<std::endl;}
//      
//        

   //Diccionario d("listado-sin-acentos.txt");
   //d.usaCorpus("corpus.txt");
   //d.escribe();
//    Palabra re;
//    Palabra busqueda;
//    busqueda.SetTermino("david");
//    Palabra p;
//    p.SetTermino("david");
//    p.nuevoSucesor("baudet");
//    // std::cout<<d.tama();
//    d.insertar(p);
//    d.insertar(p);
//    d.inorden();
//    std::cout << "altura es " << d.Altura()<<std::endl;
//    list<Sucesores> lista =d.dsucesores(p);
//    list<Sucesores>::iterator it;
//    it = lista.begin();
//    while(it != lista.end()){
//    
//        std::cout<<(*it).GetTermino()<<std::endl;
//        it++;
//    
//    }
//    
//    if(d.buscar(busqueda,re))
//        std::cout<<"existe"<<std::endl;
//    
//   
  // d.entrenar("david la david la david la david la ");
   //d.escribe();
    //auto start = std::chrono::system_clock::now();
    unsigned t0,t1;
    t0=clock();
    TextoPredictivo d("listado-sin-acentos.txt");
    t1=clock();
    double time = (double(t1-t0)/CLOCKS_PER_SEC);
    std::cout<<"******************************************************************************************"<<std::endl;
    std::cout << "tiempo ejecucion Practica 5" << time <<"tiempo ejecucion Practica 4 32 minutos "<< endl;
    std::cout<<"******************************************************************************************"<<std::endl;
   // auto end = std::chrono::system_clock::now();
 // auto elapsed_ms = std::chrono::duration_cast<std::chrono::milliseconds>(end- start).count(); 
   // auto elapsed_ms = end-start;
    
  //  std::cout   <<"Time spent (ms): "<<   elapsed_ms   <<"tiempo de la practica 4 32 minutos"<<endl;
    
    d.escribe();
    
    

    return 0;
}

