/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   Diccionario.cpp
 * Author: nedveros
 * 
 * Created on 31 de octubre de 2017, 3:26
 */

#include "Diccionario.h"

Diccionario::Diccionario() {
}

void Diccionario::setMAPPalabra(map<string, Palabra> MAPPalabra) {
    this->MAPPalabra = MAPPalabra;
}

map<string, Palabra> Diccionario::getMAPPalabra() const {
    return MAPPalabra;
}
Diccionario::Diccionario(char* ruta) {
   
    //char* rutaChar = "listado-general.txt";
    Palabra p;
    std::fstream fe; //Creamos el flujo de entrada
    std::string linea;
    int total = 0;
    //Asociamos el flujo de un fichero y lo abrimos
    fe.open(ruta);
    if(fe.good()){
        //Mientras no se haya llegado al final del fichero
        while(!fe.eof()){
           // std::vector<Palabra>::iterator it = vectorDiccionario.begin();
            getline(fe, linea); //toma una linea del fichero
            if(linea!=""){  //ignoramos lineas en blanco
                //std::cout << linea<<std::endl;
                p.SetTermino(linea);
                //vectorDiccionario.push_back(p);
               // AVLDiccionario.inserta(p);
                //std::cout<<p.GetTermino()<<std::endl;
                MAPPalabra[p.GetTermino()]=p;
                total++;
            }

        }
        std::cout << "Total de palabras en el archivo: "<< total<< std::endl;
    }else{
       // std::cerr << "No se puede abrir el fichero" << std::endl;
    }
    
    usaCorpus("corpus.txt");
   // std::cout<<vectorDiccionario.size();
   // std::cout << "Tamaño logico: "<< tamal<< "tamaño fisico: "<< tamaf<<endl;
}

Diccionario::Diccionario(const Diccionario& orig): MAPPalabra(orig.MAPPalabra){
}

Diccionario::~Diccionario() {
}

void Diccionario::insertar(Palabra &p) {
  
   
        pair<string,Palabra> nt;
        nt.second=p;
        nt.first=p.Termino;
        MAPPalabra.insert(nt);
    std::cout<<"se inserto";

 




}


     
     
         void Diccionario::entrenar(string cadena){
             
    string palabra;
    string palabrasiguiente;
    stringstream ss;
    stringstream ss2;
    int total;
    ss<<cadena;
    ss2<<cadena;
    ss2>>palabrasiguiente;
   
    while(!ss.eof()){
        
        
       ss>>palabra; 
       
      if(!ss2.eof()){ 
      ss2>>palabrasiguiente;
      }
        if(palabra!=""){
         
            Palabra p,t;
            p.SetTermino(palabra);
            //cout<<++total<<" "<<palabra<<endl;
           // buscador=busqueda_binaria(0,vectorDiccionario.size(),palabra);
            //resultado=AVLDiccionario.buscar(p,t);

            if(MAPPalabra[palabra].GetTermino() == palabra){
               
                
                //ss2>>palabrasiguiente;
                if(palabra != palabrasiguiente){
                    MAPPalabra[palabra].nuevoSucesor(palabrasiguiente);
                }
                
            }
            
            else{
            
            Palabra p;
                p.SetTermino(palabra);
                MAPPalabra[palabra]=p;
                //ss2>>palabrasiguiente;
                if(palabra != palabrasiguiente){
                    MAPPalabra[palabra].nuevoSucesor(palabrasiguiente);
                }
            }
     
            palabra="";
        
        
        }
        
  
    
    }
    
  
         
         
         
         
         
         
         
         
         
         
         }

            void Diccionario::usaCorpus(char* ruta){



    //char* rutaChar = "listado-general.txt";

    std::fstream fe; //Creamos el flujo de entrada
    std::string linea;
    int total = 0;
    //Asociamos el flujo de un fichero y lo abrimos
    fe.open(ruta);
    if(fe.good()){
        //Mientras no se haya llegado al final del fichero
        while(!fe.eof()){

            getline(fe, linea); //toma una linea del fichero
            if(linea!=""){  //ignoramos lineas en blanco
                //std::cout << linea<<std::endl;
                //
                entrenar(linea);
                //std::cout<<total<<std::endl;
                total++;
            }

        }
        std::cout << "Total de palabras en el archivo: "<< total<< std::endl;
    }else{
       // std::cerr << "No se puede abrir el fichero" << std::endl;
    }



            }



             void Diccionario::escribe(){
                 list<Sucesores> lista;
               string lcRepetirPrograma;
                 vector<string> vector;
                 int pos;
               
             
  do {
      std::cout<<"*********************************************"<<std::endl;
      std::cout<<"**** para borrar utilize clear ****"<<std::endl;
      std::cout<<"**** para cambiar usuario change usuario ****"<<std::endl;
      std::cout<<"**** listar usuarios users ****"<<std::endl;
      std::cout<<"**** escribe exit para terminar ****"<<std::endl;
      std::cout<<"********************************************"<<std::endl;
      for(int i =0 ; i < vector.size();i++){
          std::cout<<vector[i]<<" ";
      }
      std::cin >>lcRepetirPrograma;
      if(lcRepetirPrograma == "clear"){
      
          vector.clear();
      }
      if(lcRepetirPrograma == "users"){
      //recorrer el vector 
      
      
      
      }
      //pos=busqueda_binaria(0,vectorDiccionario.size(),lcRepetirPrograma
      Palabra p,t;
      p.SetTermino(lcRepetirPrograma);
     // Diccionario::AVLDiccionario.buscar(p,t);
      //lista=vectorDiccionario[pos].sucesores();
      //lista=Diccionario::dsucesores(t);
      list<Sucesores>::iterator it = lista.begin();
      while(it != lista.end()){
      
          std::cout<<"numero de ocurrencias "<<(*it).num_ocurrencias << " palabra " <<(*it).termino<<std::endl;
          it++;
      }
      vector.push_back(lcRepetirPrograma);
      
      
      
      
      
      
    } while (lcRepetirPrograma !="exit");
             
             
             
             
             
             }
