/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   Diccionario.h
 * Author: nedveros
 *
 * Created on 31 de octubre de 2017, 3:26
 */

#ifndef DICCIONARIO_H
#define DICCIONARIO_H
#include "Palabra.h"

#include <fstream>
#include <cstdlib>
#include <sstream>  
#include <map>

class Diccionario {
public:
    Diccionario();
    Diccionario(const Diccionario& orig);
    virtual ~Diccionario();
    void insertar(Palabra &p);
    Diccionario(char *ruta);
    
   
    void entrenar(string cadena);

    void inorden() {
        map<string,Palabra>::iterator it;
        it=MAPPalabra.begin();
        while(it!= MAPPalabra.end()){
        
            std::cout<<(*it).second.Termino<<std::endl;
            it++;
        
        
        }
        

    }
    
    void nuevoSucesor(string termino ,string cadena){
    
        MAPPalabra[termino].nuevoSucesor(cadena);
        
    
    }

  
    void usaCorpus(char* ruta);
 

    void escribe();
    int numeronodos(){
    
        return MAPPalabra.size();
    }
    void setMAPPalabra(map<string, Palabra> MAPPalabra);
    map<string, Palabra> getMAPPalabra() const;
private:
   // AVL<Palabra> AVLDiccionario;
    map<string,Palabra> MAPPalabra;
};

#endif /* DICCIONARIO_H */

