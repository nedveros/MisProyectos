/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/*
 * File:   TextoPredictivo.cpp
 * Author: nedveros
 *
 * Created on 17 de noviembre de 2017, 13:18
 */

#include "TextoPredictivo.h"

TextoPredictivo::TextoPredictivo() {
    
    char* fichero = (char*) "listado-sin-acentos.txt";
    
    TextoPredictivo::DicBase= Diccionario(fichero);
    
    
}
/*
 void TextoPredictivo::SetUsuarios(vector<Usuario> usuarios) {
 this->usuarios = usuarios;
 }
 
 vector<Usuario> TextoPredictivo::GetUsuarios() const {
 return usuarios;
 }
 */
void TextoPredictivo::SetDicBase(Diccionario DicBase) {
    this->DicBase = DicBase;
}

Diccionario TextoPredictivo::GetDicBase() const {
    return DicBase;
}

TextoPredictivo::TextoPredictivo(const TextoPredictivo& orig) {
    
    DicBase=orig.DicBase;
    usuarios=orig.usuarios;
    
    
    
}

TextoPredictivo::~TextoPredictivo() {
}

Usuario& TextoPredictivo::getusuario(string &id){
    vector<Usuario>::iterator it=usuarios.begin();
    
    while(it != usuarios.end()){
        
        if((*it).getId() == id){
            
            return (*it);
            
        }
        
        it++;
    }
    
    return (*it);
    
    
}

