//
//  main.cpp
//  prueba
//
//  Created by david baudet moreno on 20/11/17.
//  Copyright © 2017 david baudet moreno. All rights reserved.
//

#include <iostream>
#include "Palabra.h"
#include "Diccionario.h"
#include "Usuario.h"
#include "Sucesores.h"
#include "TextoPredictivo.h"
#include <map>
#include <ctime>
int main(int argc, const char * argv[]) {
    
    /*
     map<string,Palabra> arbol;
     Palabra p;
     p.SetTermino("david");
     
     arbol["1"]=p;
     
     arbol["1"].nuevoSucesor("baudet");
     std::cout<<arbol["1"].GetTermino()<<std::endl;
     
     list<Sucesores> lista = arbol["1"].sucesores();
     list<Sucesores>::iterator it = lista.begin();
     while (it!= lista.end()){
     
     std::cout<<(*it).GetTermino();
     it++;
     
     
     }
     */
    
    /*
    Palabra p;
    p.SetTermino("david");
    char* rutaChar = "listado-general.txt";
    Diccionario d(rutaChar);
    d.insertar(p);
    std::cout<<d.numeronodos()<<std::endl;
    d.nuevoSucesor("david", "baudet");
    list<Sucesores> lista2 = d.getMAPPalabra()["de"].sucesores();
    list<Sucesores>::iterator it2 = lista2.begin();
    while(it2!= lista2.end()){
        
        std::cout<<(*it2).GetTermino()<<" "<<(*it2).GetNum_ocurrencias()<<std::endl;
        it2++;
        
    }
    
    */
    
    
    /*
     Usuario u;
     u.setId("1");
     u.setNombre("david");
     
     u.Escribe_Frase("david esta en la biblioteca");
     
     std::cout<<u.numeronodos();
     std::list<Sucesores> lista =  u.Sugerencia("david");
     list<Sucesores>::iterator it= lista.begin();
     while(it!= lista.end()){
     
     std::cout<<(*it).GetTermino()<<" "<<(*it).GetNum_ocurrencias()<<std::endl;
     it++;
     
     }
     */
    /*
     TextoPredictivo t;
     t.NuevoUsuario("1","david");
     t.listarUsuarios();
     std::list<Sucesores> lista = t.Sugerencia("de");
     list<Sucesores>::iterator it = lista.begin();
     while (it!= lista.end()){
     
     std::cout<<(*it).GetTermino()<<" "<<(*it).GetNum_ocurrencias()<<std::endl;
     it++;
     
     }
     */
    /*
     
     
     // std::list<Sucesores> lista =  u.getTp()->Sugerencia("de");
     std::string id = "1";
     pt->getusuario(id).Escribe_Frase("de algebra");
     pt->getusuario(id).Escribe_Frase("de discreta");
     
     // pt->getusuario(id).Escribe_Frase("de algebra");
     //pt->getusuario(id).Escribe_Frase("de discreta");
     std::list<Sucesores> lista = pt->getusuario(id).Sugerencia("de");
     list<Sucesores>::iterator it = lista.begin();
     // std::list<Sucesores> lista = u.SucesoresPAlabra(u,"de");
     // std::list<Sucesores> lista = pt->getusuario("1").Sugerencia("de");
     while(it != lista.end()){
     
     std::cout<<(*it).GetTermino()<<" "<<(*it).GetNum_ocurrencias()<<std::endl;
     it++;
     
     
     
     }
     
     */
    
    
    
    
    
    
    
    
    
    unsigned t0,t1;
    t0=clock();
    TextoPredictivo *pt = new TextoPredictivo();
    pt->NuevoUsuario("1", "david");
    pt->NuevoUsuario("2", "miguel");
    
    string id="1";
      string id2="2";
    pt->getusuario(id).Escribe_Frase("de algebra");
    pt->getusuario(id).Escribe_Frase("de discreta");
    pt->getusuario(id2).Escribe_Frase("de metaeuristica");
    pt->getusuario(id2).Escribe_Frase("de grafica");
    t1=clock();
    double time = (double(t1-t0)/CLOCKS_PER_SEC);
    std::cout<<"******************************************************************************************"<<std::endl;
    std::cout << "tiempo ejecucion Practica 6" << time <<"tiempo ejecucion Practica 5 4 minutos "<< endl;
    std::cout<< "numero de nodos cargados en el arbol es : "<<pt->tama();
    std::cout<<"******************************************************************************************"<<std::endl;
    
    pt->getusuario(id).escribe();
    
    
    
    
    
    
    
    
 
    
    
    
    
    
    
    return 0;
}
