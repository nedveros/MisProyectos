/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   Sucesores.h
 * Author: nedveros
 *
 * Created on 24 de octubre de 2017, 2:31
 */

#ifndef SUCESORES_H
#define SUCESORES_H
#include <iostream>
using namespace std;

class Sucesores {
    friend ostream &operator<<(ostream &, const Sucesores &);
public:
    std::string termino;
    int num_ocurrencias;
    Sucesores();
    Sucesores(const Sucesores& orig);
    virtual ~Sucesores();
    void SetNum_ocurrencias(int num_ocurrencias);
    int GetNum_ocurrencias() const;
    void SetTermino(std::string termino);
    std::string GetTermino() const;
    int operator<(const Sucesores &rhs) const;
    int operator==(const Sucesores &rhs)const;
    Sucesores& operator=(const Sucesores &rhs);



};

#endif /* SUCESORES_H */

