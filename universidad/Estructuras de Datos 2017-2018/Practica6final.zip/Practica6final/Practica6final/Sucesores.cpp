/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   Sucesores.cpp
 * Author: nedveros
 * 
 * Created on 24 de octubre de 2017, 2:31
 */

#include "Sucesores.h"

Sucesores::Sucesores() {
}

Sucesores::Sucesores(const Sucesores& orig) {

    termino = orig.termino;
    num_ocurrencias = orig.num_ocurrencias;


}

Sucesores::~Sucesores() {
}

void Sucesores::SetNum_ocurrencias(int num_ocurrencias) {
    this->num_ocurrencias = num_ocurrencias;
}

int Sucesores::GetNum_ocurrencias() const {
    return num_ocurrencias;
}

void Sucesores::SetTermino(std::string termino) {
    this->termino = termino;
}

std::string Sucesores::GetTermino() const {
    return termino;
}

ostream &operator<<(ostream &output, const Sucesores &aaa) {
    output << aaa.termino << ' ' << aaa.num_ocurrencias << ' ';
    return output;
}

int Sucesores::operator<(const Sucesores &rhs)const {
    if (this->num_ocurrencias == rhs.num_ocurrencias) return 1;
    if (this->num_ocurrencias < rhs.num_ocurrencias) return 1;

    return 0;
}

int Sucesores::operator==(const Sucesores &rhs) const {
    if (this->termino != rhs.termino) return 0;
    if (this->num_ocurrencias != rhs.num_ocurrencias) return 0;

    return 1;
}

Sucesores& Sucesores::operator=(const Sucesores &rhs) {
    if (&rhs == this) return *this;
    termino = rhs.termino;
    num_ocurrencias = rhs.num_ocurrencias;
    return *this;



}