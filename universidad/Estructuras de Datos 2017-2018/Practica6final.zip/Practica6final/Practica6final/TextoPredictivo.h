/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/*
 * File:   TextoPredictivo.h
 * Author: nedveros
 *
 * Created on 17 de noviembre de 2017, 13:18
 */

#ifndef TEXTOPREDICTIVO_H
#define TEXTOPREDICTIVO_H
#include "Diccionario.h"
#include "Usuario.h"
#include<vector>
//class usuario;
class TextoPredictivo {
public:
    TextoPredictivo();
    TextoPredictivo(const TextoPredictivo& orig);
    virtual ~TextoPredictivo();
    
    void NuevoUsuario(string id,string nombre){
        Usuario p(id,nombre,this);
        
        
        usuarios.push_back(p);
    }
    
    void listarUsuarios(){
        vector<Usuario>::iterator it = usuarios.begin();
        std::cout<<"[ID] -------------------------- [Usuario]"<<std::endl;
        while(it != usuarios.end()){
            
            std::cout<<(*it).getId()<<"----------------------------------"<<(*it).getNombre()<<std::endl;
            it++;
        }
    }
    
    list<Sucesores> Sugerencia(string termino){
        
        return DicBase.getMAPPalabra()[termino].sucesores();
        
        
    }
    
    Usuario& getusuario(string &id);
    
    
    int tama(){
        
        return usuarios.size();
        
    }
    
    void entrena(string palabra1){
        
        
        DicBase.entrenar(palabra1);
        
        
    }
    
    void SetDicBase(Diccionario DicBase);
    
    Diccionario GetDicBase() const;
    
private:
    
    Diccionario DicBase;
    vector<Usuario> usuarios;
    
};

#endif /* TEXTOPREDICTIVO_H */

