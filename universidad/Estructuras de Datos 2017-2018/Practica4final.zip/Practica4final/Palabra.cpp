/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   Palabra.cpp
 * Author: nedveros
 * 
 * Created on 26 de septiembre de 2017, 15:31
 */

#include "Palabra.h"

Palabra::Palabra() {
}

Palabra::Palabra(const Palabra& orig) {
    
    Termino = orig.Termino;
    siguientes=orig.siguientes;
}

Palabra::~Palabra() {
}

void Palabra::SetTermino(string Termino) {
    this->Termino = Termino;
}

string Palabra::GetTermino() const {
    return Termino;
}
        ostream &operator<<(ostream &output, const Palabra &aaa)
{
   output << aaa.Termino << ' '  ;
   return output;
}
    
        
    int Palabra::operator<(const Palabra &rhs)const
{
   if( this->Termino == rhs.Termino) return 1;
   if( this->Termino < rhs.Termino) return 1;
  
   return 0;
}
    
        int Palabra::operator==(const Palabra &rhs) const
{
   if( this->Termino != rhs.Termino) return 0;
  
 
   return 1;
}
        
 
     
    
        
        
        
        
        
        
        
        Palabra& Palabra::operator=(const Palabra &rhs)
{
    if(&rhs == this) return *this;
    Termino = rhs.Termino;
    
    return *this;
    
    
    
}