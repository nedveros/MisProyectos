/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   main.cpp
 * Author: nedveros
 *
 * Created on 31 de octubre de 2017, 3:08
 */

#include <cstdlib>
#include <iostream>

#include "Diccionario.h"

using namespace std;

/*
 * 
 */
int main(int argc, char** argv) {
   Diccionario d("listado-sin-acentos.txt");
//    Diccionario d;
//    Palabra p ,q; 
//    
//     q .SetTermino("maria");
//    q.nuevoSucesor("baudet");
//    q.nuevoSucesor("moreno");
//    q.sucesores();
//    
//    
//    
//    p .SetTermino("david");
//    p.nuevoSucesor("baudet");
//    p.nuevoSucesor("moreno");
//    p.sucesores();
//    
//    d.insertar(p);
//    d.insertar(q);
//    
//    d.dsucesores(p);
//    d.dsucesores(q);
//    
//    std::cout<<d.tama();
//    
//   
//    

    
    d.usaCorpus("corpus_spanish.txt");
    d.entrenar("david y el futbol");
    
    d.escribe();
    
//   
 
//    
    
    
    
    
    
    
    return 0;
}

