/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   Diccionario.cpp
 * Author: nedveros
 * 
 * Created on 31 de octubre de 2017, 3:26
 */

#include "Diccionario.h"

Diccionario::Diccionario() {
}
Diccionario::Diccionario(char* ruta) {
   
    //char* rutaChar = "listado-general.txt";
    Palabra p;
    std::fstream fe; //Creamos el flujo de entrada
    std::string linea;
    int total = 0;
    //Asociamos el flujo de un fichero y lo abrimos
    fe.open(ruta);
    if(fe.good()){
        //Mientras no se haya llegado al final del fichero
        while(!fe.eof()){
            std::vector<Palabra>::iterator it = vectorDiccionario.begin();
            getline(fe, linea); //toma una linea del fichero
            if(linea!=""){  //ignoramos lineas en blanco
                //std::cout << linea<<std::endl;
                p.SetTermino(linea);
                vectorDiccionario.push_back(p);
                total++;
            }

        }
        std::cout << "Total de palabras en el archivo: "<< total<< std::endl;
    }else{
       // std::cerr << "No se puede abrir el fichero" << std::endl;
    }
   // std::cout<<vectorDiccionario.size();
   // std::cout << "Tamaño logico: "<< tamal<< "tamaño fisico: "<< tamaf<<endl;
}
Diccionario::Diccionario(const Diccionario& orig) {
}

Diccionario::~Diccionario() {
}

 void Diccionario::insertar(Palabra &p){
     int pos = busqueda_binaria(0,vectorDiccionario.size(),p.GetTermino());
 
     if(vectorDiccionario.size()==0){
     
     vectorDiccionario.push_back(p);
     
     }else{
     
     
         if(vectorDiccionario[pos].Termino != p.GetTermino()){
             vector<Palabra>::iterator it = vectorDiccionario.begin()+pos;
             vectorDiccionario.insert(it,p);
         
         
         
         }
     
     
     
     
     
     
     }
     
     
     
 
 
 }
 
     int Diccionario::busqueda_binaria(int inicio, int final, string x){
        
        int medio = 0;
        bool flag = false;
        while((inicio < final) && (!flag)){
            medio = (inicio + final) / 2;
            //para comparar usamos compare() de string
            //std::cout<<diccionario[medio]->GetTermino();
            if(x.compare(vectorDiccionario[medio].GetTermino()) > 0) inicio = medio + 1;
            else if(x.compare(vectorDiccionario[medio].GetTermino()) < 0) final = medio - 1;
            else flag = true;
        }
        if(flag) {
            cout << "Elemento" <<" "<< x << " "<<"encontrado en la posicion " << medio << endl;
            return medio;
        }
        else {
           
            return medio;
        }
    }
     
     
         void Diccionario::entrenar(string cadena){
         
         
         
         
         
         
    
    
    
    
    string palabra;
 
    string aux;
    int posaux;
    int cont=0;
    stringstream ss;
    int total;
    ss<<cadena;
   
    while(!ss.eof()){
        
       ss>>palabra;  
        if(palabra!=""){
            int buscador;
            //cout<<++total<<" "<<palabra<<endl;
            buscador=busqueda_binaria(0,vectorDiccionario.size(),palabra);
            
            
            if(cont == 0 ){
            
            
            if(vectorDiccionario[buscador].GetTermino() != palabra){
                vector<Palabra>::iterator it=vectorDiccionario.begin()+buscador;
                Palabra p;
                p.SetTermino(palabra);
                vectorDiccionario.insert(it,p);
                aux=palabra;
                ss>>palabra;
                
                cont++;
            }
            
            }else{
                int buscador2=busqueda_binaria(0,vectorDiccionario.size(),aux);
                if(aux != ""){
                    
                vectorDiccionario[buscador2].nuevoSucesor(palabra);
                cont++;
                }
            
             if(vectorDiccionario[buscador].GetTermino() != palabra){
                 
                vector<Palabra>::iterator it=vectorDiccionario.begin()+buscador;
                Palabra p;
                p.SetTermino(palabra);
                vectorDiccionario.insert(it,p);
                aux=palabra;
                ss>>palabra;
                cont++;
             }
            
            }
            

            
            
            
            palabra="";
        
        
        }
        
  
    
    }
    
  
         
         
         
         
         
         
         
         
         
         
         }
     
            void Diccionario::usaCorpus(char* ruta){
            
            
            
              
    //char* rutaChar = "listado-general.txt";
    
    std::fstream fe; //Creamos el flujo de entrada
    std::string linea;
    int total = 0;
    //Asociamos el flujo de un fichero y lo abrimos
    fe.open(ruta);
    if(fe.good()){
        //Mientras no se haya llegado al final del fichero
        while(!fe.eof()){
            
            getline(fe, linea); //toma una linea del fichero
            if(linea!=""){  //ignoramos lineas en blanco
                //std::cout << linea<<std::endl;
                //
                entrenar(linea);
                total++;
            }

        }
        std::cout << "Total de palabras en el archivo: "<< total<< std::endl;
    }else{
       // std::cerr << "No se puede abrir el fichero" << std::endl;
    }
            
            
            
            }
            
            
            
             void Diccionario::escribe(){
               string lcRepetirPrograma;
                 vector<string> vector;
                 int pos;
               
             
  do {
      
      std::cout<<"escribe salir para terminar"<<std::endl;
      for(int i =0 ; i < vector.size();i++){
          std::cout<<vector[i]<<" ";
      }
      std::cin >>lcRepetirPrograma;
      pos=busqueda_binaria(0,vectorDiccionario.size(),lcRepetirPrograma);
      vectorDiccionario[pos].sucesores();
      vector.push_back(lcRepetirPrograma);
      
      
      
      
      
      
    } while (lcRepetirPrograma !="salir");
             
             
             
             
             
             }
