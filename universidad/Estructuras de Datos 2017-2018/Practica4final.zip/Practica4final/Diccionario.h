/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   Diccionario.h
 * Author: nedveros
 *
 * Created on 31 de octubre de 2017, 3:26
 */

#ifndef DICCIONARIO_H
#define DICCIONARIO_H
#include "Palabra.h"
#include <vector>
#include <fstream>
#include <cstdlib>
#include <sstream>  

class Diccionario {
public:
    Diccionario();
    Diccionario(const Diccionario& orig);
    virtual ~Diccionario();
    void insertar(Palabra &p);
    Diccionario(char *ruta);
   void entrenar(string cadena);
   
    void usaCorpus(char* ruta);
      int busqueda_binaria(int inicio, int final, string x);
      int tama(){
      
          return vectorDiccionario.size();
      }
    void dsucesores(Palabra &p){
    
        p.sucesores();
    
    
    }
    Palabra get(string p){
        int pos = busqueda_binaria(0,vectorDiccionario.size(),p);
        return vectorDiccionario[pos];
    
    }
    
    void escribe();
private:
    vector<Palabra> vectorDiccionario;
};

#endif /* DICCIONARIO_H */

