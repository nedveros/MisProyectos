/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   VectorEstatico.h
 * Author: nedveros
 *
 * Created on 19 de septiembre de 2017, 18:42
 */

#ifndef VECTORESTATICO_H
#define VECTORESTATICO_H
#include "Palabra.h"
#include <iostream>
using namespace std;

class VectorEstatico {
public:
    VectorEstatico();
    VectorEstatico(const VectorEstatico& orig);
    virtual ~VectorEstatico();
   string getVector(int i){
        return vector[i].GetTermino();
    }
    void setVector(int pos,Palabra p){
        vector[pos].SetTermino(p.GetTermino());
    }
    void ensena(){
        for (int i =0 ; i < 80383 ; i++){
        
            std::cout<<vector[i].GetTermino()<<endl;
        
        }
    
    }


    void setTamano(int tamano);
    int getTamano() const;
    
private:
    int tamano;
    Palabra vector[80383];
};

#endif /* VECTORESTATICO_H */

