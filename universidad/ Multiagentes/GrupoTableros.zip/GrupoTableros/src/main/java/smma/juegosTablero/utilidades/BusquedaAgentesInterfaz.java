package utilidades;
import jade.core.AID;
import java.util.List;

/**
 *
 * @author  javiermq
 */
public interface BusquedaAgentesInterfaz {
   
    public void finBusqueda(List<AID> aids, String servicio);

}
