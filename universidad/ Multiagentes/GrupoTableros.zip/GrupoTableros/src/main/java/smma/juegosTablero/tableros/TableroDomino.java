/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package smma.juegosTablero.tableros;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import java.util.concurrent.TimeUnit;
import javafx.util.Pair;
import javax.swing.JButton;
import javax.swing.JTextArea;
import javax.swing.SwingConstants;
import juegosTablero.Vocabulario;
import juegosTablero.aplicacion.domino.Ficha;
import juegosTablero.dominio.elementos.Jugador;

/**
 *
 * @author davidbaudetmoreno
 */
public class TableroDomino extends javax.swing.JFrame {

    /**
     * Creates new form tablero
     */
    private int valorIzquierda = 0;
    private int valorDerecha = 0;

    private int tamTableroX = 600;
    private int tamTableroY = 800;

    boolean verticalidadFichaActual = false;
    boolean fichaDireccionDerecha = false;

    boolean primeraFichaBordeDerecha = true;
    boolean primeraFichaBordeIzquierda = true;

    private static Pair<Integer, Integer> posFichaDerecha;
    private static Pair<Integer, Integer> posFichaIzquierda;
    private String empieza = "";

    private boolean verticalDerecha = false;
    private boolean verticalIzquierda = false;

    private boolean derechaSentidoDerecha = true;
    private boolean izquierdaSentidoIzquierda = true;

    private int tamFichaX = 60;
    private int tamFichaY = 40;

    private int posInicialX = tamTableroX / 2 - 20;
    private int posInicialY = tamTableroY / 2 - 30;

    private int numeroFicha = 1;

    private String PrimerJugador;
    private String SegundoJugador;
    private String TercerJugador;
    private String CuartoJugador;
    private String TipoPartida;
    private JTextArea area;

    private java.util.List<java.util.List<juegosTablero.aplicacion.domino.Ficha>> matrizDeFichas;

    public TableroDomino(String tipoPartida, String nombre1, String nombre2, String nombre3, String nombre4) {
        PrimerJugador = nombre1;
        SegundoJugador = nombre2;
        TercerJugador = nombre3;
        CuartoJugador = nombre4;
        this.TipoPartida = tipoPartida;

        initComponents();
        jLabel1.setText(TipoPartida);
        jLabel2.setText(PrimerJugador);
        jLabel3.setText(SegundoJugador);
        jLabel4.setText(TercerJugador);
        jLabel5.setText(CuartoJugador);
        area = jTextArea1;
        area.setLineWrap(true);
        setVisible(true);
        this.matrizDeFichas = repartir();

        for (int i = 0; i < 4; i++) {
            System.out.println(i + 1);
            for (int j = 0; j < 7; j++) {

                System.out.println(matrizDeFichas.get(i).get(j).getValorSup() + "|" + matrizDeFichas.get(i).get(j).getValorInf());

            }
            System.out.println("-----------------------------");

        }

        System.out.println("Jugador que empieza " + this.empieza);

    }

    private TableroDomino() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    private void ComprobarVerticalidad(int primero, int segundo) {
        if (primero == segundo) {

            verticalidadFichaActual = true;

        } else {

            verticalidadFichaActual = false;
        }

    }

    private boolean ExistePosicion(int primero, int segundo) {

        return (this.valorDerecha == primero || this.valorDerecha == segundo || this.valorIzquierda == primero || this.valorIzquierda == segundo);

    }

    private void ComprobarSentidoFicha(int primero, int segundo, Vocabulario.Colocacion colocacion) {
//        if(valorDerecha == valorIzquierda){
//            if(colocacion.equals(Vocabulario.Colocacion.DERECHA)){
//                fichaDireccionDerecha = true;
//            }else{
//                fichaDireccionDerecha = false;
//            }
//        }else{
//            if (primero == this.valorDerecha) {
//                this.fichaDireccionDerecha = true;
//            } else if (primero == this.valorIzquierda) {
//                this.fichaDireccionDerecha = false;
//            } else if (segundo == this.valorDerecha) {
//                this.fichaDireccionDerecha = true;
//            } else if (segundo == this.valorIzquierda) {
//                this.fichaDireccionDerecha = false;
//            }
//            
//        }

        if (colocacion.equals(Vocabulario.Colocacion.DERECHA)) {
            fichaDireccionDerecha = true;
        } else {
            fichaDireccionDerecha = false;
        }

    }

    private java.util.List<java.util.List<juegosTablero.aplicacion.domino.Ficha>> repartir() {

        Random rn = new Random();
        int answer;

        int contador1, contador2, contador3, contador4;
        ArrayList<juegosTablero.aplicacion.domino.Ficha> jugador1 = new ArrayList<>();
        ArrayList<juegosTablero.aplicacion.domino.Ficha> jugador2 = new ArrayList<>();
        ArrayList<juegosTablero.aplicacion.domino.Ficha> jugador3 = new ArrayList<>();
        ArrayList<juegosTablero.aplicacion.domino.Ficha> jugador4 = new ArrayList<>();

        java.util.List<java.util.List<juegosTablero.aplicacion.domino.Ficha>> matriz = new ArrayList<>();

        contador1 = 0;
        contador2 = 0;
        contador3 = 0;
        contador4 = 0;

        List<juegosTablero.aplicacion.domino.Ficha> f = new ArrayList<>();
        int a = 0;
        int b = 0;

        while (a != 7) {
            for (int j = b; j < 7; j++) {

                juegosTablero.aplicacion.domino.Ficha nueva = new Ficha(a, j);
                //   new ficha(a, j);
                f.add(nueva);

            }
            b++;
            a++;
        }

        a = 0;
        while (a != f.size()) {

            answer = rn.nextInt(4) + 1;

            if (answer == 1 && contador1 != 7) {
                if (f.get(a).getValorSup() == 6 && f.get(a).getValorInf() == 6) {

                    empieza = this.PrimerJugador;

                }
                jugador1.add(f.get(a));
                contador1++;
                a++;

            }
            if (answer == 2 && contador2 != 7) {

                if (f.get(a).getValorSup() == 6 && f.get(a).getValorInf() == 6) {

                    empieza = this.SegundoJugador;

                }

                jugador2.add(f.get(a));
                contador2++;
                a++;

            }
            if (answer == 3 && contador3 != 7) {

                if (f.get(a).getValorSup() == 6 && f.get(a).getValorInf() == 6) {

                    empieza = this.TercerJugador;

                }

                jugador3.add(f.get(a));
                contador3++;

                a++;
            }
            if (answer == 4 && contador4 != 7) {

                if (f.get(a).getValorSup() == 6 && f.get(a).getValorInf() == 6) {

                    empieza = this.CuartoJugador;

                }

                jugador4.add(f.get(a));
                contador4++;

                a++;
            }

        }

        matriz.add(jugador1);
        matriz.add(jugador2);
        matriz.add(jugador3);
        matriz.add(jugador4);

        return matriz;

    }

    public boolean Borde(int posX, boolean direccionDerecha, boolean sentidoOriginal) {

        if (direccionDerecha) {
            if (sentidoOriginal) {
                int anchoOcupado = posX;
                if (this.verticalDerecha) {
                    anchoOcupado += 40;
                } else {
                    anchoOcupado += 60;
                }

                anchoOcupado = this.tamTableroX - anchoOcupado;

                System.out.println(anchoOcupado);
                return anchoOcupado > 60;
            } else {
                return posX > 60;
            }
        } else {
            if (sentidoOriginal) {
                return posX > 60;
            } else {
                int anchoOcupado = posX;
                if (this.verticalIzquierda) {
                    anchoOcupado += 40;
                } else {
                    anchoOcupado += 60;
                }

                anchoOcupado = this.tamTableroX - anchoOcupado;
                return anchoOcupado > 60;

            }
        }

    }

    public void ficha(int primerValor, int segundoValor, Vocabulario.Colocacion colocacion, String Jugador) throws InterruptedException {

        if (numeroFicha == 1) {
            String primervalor = "<html><p align=\"left\">" + 6 + "</p><p align=\"left\">-</p><p align=\"left\">" + 6 + "</p></html>";
            JButton nuevo = new JButton(primervalor);

            nuevo.setBounds(this.posInicialX, this.posInicialY, tamFichaY, tamFichaX);
            panelJuego.add(nuevo);
            area.append(Jugador + "\n");
            area.append("puso la ficha " + 6 + "|" + 6 + "\n");
            area.setCaretPosition(area.getDocument().getLength());
            this.repaint();

            posFichaDerecha = new Pair<Integer, Integer>(posInicialX, posInicialY);
            posFichaIzquierda = new Pair<Integer, Integer>(posInicialX, posInicialY);

            this.valorIzquierda = 6;
            this.valorDerecha = 6;

            this.verticalDerecha = true;
            this.verticalIzquierda = true;

            numeroFicha++;
        } else {

            if (ExistePosicion(primerValor, segundoValor)) {

                ComprobarSentidoFicha(primerValor, segundoValor, colocacion);
                ComprobarVerticalidad(primerValor, segundoValor);

                if (fichaDireccionDerecha) {
                    if (derechaSentidoDerecha) {
                        if (Borde(posFichaDerecha.getKey(), true, true)) {

                            if (verticalDerecha) {
                                //CASO 17
                                System.out.println("CASO 17");
                                int novaX = posFichaDerecha.getKey() + 40;
                                int novaY = posFichaDerecha.getValue() + 10;
                                System.out.println(novaX + "," + novaY);
                                posFichaDerecha = new Pair<>(novaX, posFichaDerecha.getValue());

                                String primervalor = "";
                                if (primerValor != this.valorDerecha) {
                                    primervalor = segundoValor + "|" + primerValor;
                                    this.valorDerecha = primerValor;
                                } else {
                                    primervalor = primerValor + "|" + segundoValor;
                                    this.valorDerecha = segundoValor;
                                }

                                JButton nuevo = new JButton(primervalor);

                                nuevo.setBounds(novaX, novaY, tamFichaX, tamFichaY);

                                //this.add(nuevo);
                                panelJuego.add(nuevo);

                                area.append(Jugador + "\n");
                                area.append("puso la ficha " + primervalor + "\n");
                                area.setCaretPosition(area.getDocument().getLength());
                                TimeUnit.SECONDS.sleep(1);
                                this.repaint();
                                this.verticalDerecha = false;

                            } else {
                                if (verticalidadFichaActual) {
                                    //Caso 16
                                    System.out.println("CASO 16");
                                    int novaX = posFichaDerecha.getKey() + 60;
                                    int novaY = posFichaDerecha.getValue();
                                    System.out.println(novaX + "," + novaY);
                                    posFichaDerecha = new Pair<>(novaX, posFichaDerecha.getValue());
                                    String p1 = primerValor + "";
                                    String p2 = segundoValor + "";
                                    String primervalor = "<html><p align=\"left\">" + primerValor + "</p><p align=\"left\">-</p><p align=\"left\">" + segundoValor + "</p></html>";
                                    JButton nuevo = new JButton(primervalor);

                                    nuevo.setBounds(novaX, novaY, tamFichaY, tamFichaX);

                                    //this.add(nuevo);
                                    panelJuego.add(nuevo);
                                    area.append(Jugador + "\n");
                                    area.append("puso la ficha " + p1 + "|" + p2 + "\n");
                                    area.setCaretPosition(area.getDocument().getLength());
                                    TimeUnit.SECONDS.sleep(1);
                                    this.repaint();
                                    this.verticalDerecha = true;
                                    this.valorDerecha = primerValor;

                                } else {
                                    //CASO 15
                                    System.out.println("CASO 15");
                                    int novaX = posFichaDerecha.getKey() + 60;
                                    int novaY = posFichaDerecha.getValue() + 10;
                                    System.out.println(novaX + "," + novaY);
                                    posFichaDerecha = new Pair<>(novaX, posFichaDerecha.getValue());

                                    String primervalor = "";
                                    if (primerValor != this.valorDerecha) {
                                        primervalor = segundoValor + "|" + primerValor;
                                        this.valorDerecha = primerValor;
                                    } else {
                                        primervalor = primerValor + "|" + segundoValor;
                                        this.valorDerecha = segundoValor;
                                    }

                                    JButton nuevo = new JButton(primervalor);

                                    nuevo.setBounds(novaX, novaY, tamFichaX, tamFichaY);

                                    //this.add(nuevo);
                                    panelJuego.add(nuevo);
                                    area.append(Jugador + "\n");
                                    area.append("puso la ficha " + primervalor + "\n");
                                    area.setCaretPosition(area.getDocument().getLength());
                                    TimeUnit.SECONDS.sleep(1);
                                    this.repaint();
                                    this.verticalDerecha = false;

                                }
                            }
                        } else {
                            if (primeraFichaBordeDerecha) {
                                if (verticalDerecha) {
                                    //CASO 19
                                    System.out.println("CASO 19");
                                    int novaX = posFichaDerecha.getKey();
                                    int novaY = posFichaDerecha.getValue() - 60;
                                    System.out.println(novaX + "," + novaY);
                                    posFichaDerecha = new Pair<>(novaX, novaY);
                                    String p1 = primerValor + "";
                                    String p2 = segundoValor + "";
                                    String primervalor = "";
                                    if (primerValor != this.valorDerecha) {
                                        primervalor = "<html><p align=\"left\">" + primerValor + "</p><p align=\"left\">-</p><p align=\"left\">" + segundoValor + "</p></html>";
                                        this.valorDerecha = primerValor;
                                    } else {
                                        primervalor = "<html><p align=\"left\">" + segundoValor + "</p><p align=\"left\">-</p><p align=\"left\">" + primerValor + "</p></html>";

                                        this.valorDerecha = segundoValor;
                                    }
                                    System.out.println(valorDerecha);
                                    JButton nuevo = new JButton(primervalor);

                                    nuevo.setBounds(novaX, novaY, tamFichaY, tamFichaX);

                                    //this.add(nuevo);
                                    panelJuego.add(nuevo);
                                    area.append(Jugador + "\n");
                                    area.append("puso la ficha " + p1 + "|" + p2 + "\n");
                                    area.setCaretPosition(area.getDocument().getLength());
                                    TimeUnit.SECONDS.sleep(1);
                                    this.repaint();
                                    this.verticalDerecha = true;
                                } else {
                                    //Caso 18
                                    System.out.println("CASO 18");
                                    int novaX = posFichaDerecha.getKey() + 20;
                                    int novaY = posFichaDerecha.getValue() - 50;
                                    System.out.println(novaX + "," + novaY);
                                    posFichaDerecha = new Pair<>(novaX, novaY);
                                    String p1 = primerValor + "";
                                    String p2 = segundoValor + "";
                                    String primervalor = "";
                                    if (primerValor != this.valorDerecha) {
                                        primervalor = "<html><p align=\"left\">" + primerValor + "</p><p align=\"left\">-</p><p align=\"left\">" + segundoValor + "</p></html>";
                                        this.valorDerecha = primerValor;
                                    } else {
                                        primervalor = "<html><p align=\"left\">" + segundoValor + "</p><p align=\"left\">-</p><p align=\"left\">" + primerValor + "</p></html>";
                                        this.valorDerecha = segundoValor;
                                    }
                                    System.out.println(this.valorDerecha);
                                    JButton nuevo = new JButton(primervalor);

                                    nuevo.setBounds(novaX, novaY, tamFichaY, tamFichaX);

                                    //this.add(nuevo);
                                    panelJuego.add(nuevo);
                                    area.append(Jugador + "\n");
                                    area.append("puso la ficha " + p1 + "|" + p2 + "\n");
                                    area.setCaretPosition(area.getDocument().getLength());
                                    TimeUnit.SECONDS.sleep(1);
                                    this.repaint();
                                    this.verticalDerecha = true;
                                }
                                primeraFichaBordeDerecha = false;
                            } else {
                                if (verticalidadFichaActual) {
                                    //Caso 20
                                    System.out.println("CASO 20");
                                    int novaX = posFichaDerecha.getKey();
                                    int novaY = posFichaDerecha.getValue() - 60;
                                    System.out.println(novaX + "," + novaY);
                                    posFichaDerecha = new Pair<>(novaX, novaY);
                                    String p1 = primerValor + "";
                                    String p2 = segundoValor + "";
                                    String primervalor = "";
                                    if (primerValor != this.valorDerecha) {
                                        primervalor = "<html><p align=\"left\">" + primerValor + "</p><p align=\"left\">-</p><p align=\"left\">" + segundoValor + "</p></html>";
                                        this.valorDerecha = primerValor;
                                    } else {
                                        primervalor = "<html><p align=\"left\">" + segundoValor + "</p><p align=\"left\">-</p><p align=\"left\">" + primerValor + "</p></html>";

                                        this.valorDerecha = segundoValor;
                                    }
                                    System.out.println(valorDerecha);
                                    JButton nuevo = new JButton(primervalor);

                                    nuevo.setBounds(novaX, novaY, tamFichaY, tamFichaX);

                                    //this.add(nuevo);
                                    panelJuego.add(nuevo);
                                    area.append(Jugador + "\n");
                                    area.append("puso la ficha " + p1 + "|" + p2 + "\n");
                                    area.setCaretPosition(area.getDocument().getLength());
                                    TimeUnit.SECONDS.sleep(1);
                                    this.repaint();
                                    this.verticalDerecha = true;
                                } else {
                                    //Caso 21
                                    System.out.println("CASO 21");
                                    int novaX = posFichaDerecha.getKey() - 20;
                                    int novaY = posFichaDerecha.getValue() - 40;
                                    System.out.println(novaX + "," + novaY);
                                    posFichaDerecha = new Pair<>(novaX, novaY - 10);
                                    String p1 = primerValor + "";
                                    String p2 = segundoValor + "";
                                    String primervalor = "";
                                    if (primerValor != this.valorDerecha) {
                                        primervalor = "<html><p align=\"left\">" + primerValor + " | " + segundoValor + "</html>";
                                        this.valorDerecha = primerValor;
                                    } else {
                                        primervalor = "<html><p align=\"left\">" + segundoValor + " | " + primerValor + "</html>";
                                        this.valorDerecha = segundoValor;
                                    }
                                    System.out.println(this.valorDerecha);
                                    JButton nuevo = new JButton(primervalor);

                                    nuevo.setBounds(novaX, novaY, tamFichaX, tamFichaY);

                                    //this.add(nuevo);
                                    panelJuego.add(nuevo);
                                    area.append(Jugador + "\n");
                                    area.append("puso la ficha " + p1 + "|" + p2 + "\n");
                                    area.setCaretPosition(area.getDocument().getLength());
                                    TimeUnit.SECONDS.sleep(1);
                                    this.repaint();
                                    this.verticalDerecha = false;
                                    derechaSentidoDerecha = false;
                                    primeraFichaBordeDerecha = true;
                                }
                            }
                        }
                    } else {
                        if (Borde(posFichaDerecha.getKey(), true, false)) {

                            if (verticalDerecha) {
                                //Caso 24
                                System.out.println("Caso 24");
                                int novaX = posFichaDerecha.getKey() - 60;
                                int novaY = posFichaDerecha.getValue() + 10;
                                System.out.println(novaX + "," + novaY);
                                posFichaDerecha = new Pair<>(novaX, posFichaDerecha.getValue());
                                String p1 = primerValor + "";
                                String p2 = segundoValor + "";
                                String primervalor = "";
                                if (segundoValor != this.valorDerecha) {
                                    primervalor = "<html><p align=\"left\">" + segundoValor + " | " + primerValor + "</html>";
                                    this.valorDerecha = segundoValor;
                                } else {
                                    primervalor = "<html><p align=\"left\">" + primerValor + " | " + segundoValor + "</html>";
                                    this.valorDerecha = primerValor;
                                }

                                JButton nuevo = new JButton(primervalor);

                                nuevo.setBounds(novaX, novaY, tamFichaX, tamFichaY);

                                //this.add(nuevo);
                                panelJuego.add(nuevo);
                                area.append(Jugador + "\n");
                                area.append("puso la ficha " + p1 + "|" + p2 + "\n");
                                area.setCaretPosition(area.getDocument().getLength());
                                TimeUnit.SECONDS.sleep(1);
                                this.repaint();
                                this.verticalDerecha = false;
                            } else {
                                if (verticalidadFichaActual) {
                                    //Caso 23
                                    System.out.println("Caso 23");
                                    int novaX = posFichaDerecha.getKey() - 40;
                                    int novaY = posFichaDerecha.getValue();
                                    System.out.println(novaX + "," + novaY);
                                    posFichaDerecha = new Pair<>(novaX, posFichaDerecha.getValue());
                                    String p1 = primerValor + "";
                                    String p2 = segundoValor + "";
                                    String primervalor = "<html><p align=\"left\">" + primerValor + "</p><p align=\"left\">-</p><p align=\"left\">" + segundoValor + "</p></html>";
                                    JButton nuevo = new JButton(primervalor);

                                    nuevo.setBounds(novaX, novaY, tamFichaY, tamFichaX);

                                    //this.add(nuevo);
                                    panelJuego.add(nuevo);
                                    area.append(Jugador + "\n");
                                    area.append("puso la ficha " + p1 + "|" + p2 + "\n");
                                    area.setCaretPosition(area.getDocument().getLength());
                                    TimeUnit.SECONDS.sleep(1);
                                    this.repaint();
                                    this.verticalDerecha = true;
                                    this.valorDerecha = primerValor;
                                } else {
                                    //caso 22
                                    System.out.println("CASO 22");
                                    int novaX = posFichaDerecha.getKey() - 60;
                                    int novaY = posFichaDerecha.getValue() + 10;
                                    System.out.println(novaX + "," + novaY);
                                    posFichaDerecha = new Pair<>(novaX, posFichaDerecha.getValue());
                                    String p1 = primerValor + "";
                                    String p2 = segundoValor + "";
                                    String primervalor = "";
                                    if (segundoValor != this.valorDerecha) {
                                        primervalor = "<html><p align=\"left\">" + segundoValor + " | " + primerValor + "</html>";
                                        this.valorDerecha = segundoValor;
                                    } else {
                                        primervalor = "<html><p align=\"left\">" + primerValor + " | " + segundoValor + "</html>";
                                        this.valorDerecha = primerValor;
                                    }

                                    JButton nuevo = new JButton(primervalor);

                                    nuevo.setBounds(novaX, novaY, tamFichaX, tamFichaY);

                                    //this.add(nuevo);
                                    panelJuego.add(nuevo);
                                    area.append(Jugador + "\n");
                                    area.append("puso la ficha " + p1 + "|" + p2 + "\n");
                                    area.setCaretPosition(area.getDocument().getLength());
                                    TimeUnit.SECONDS.sleep(1);
                                    this.repaint();
                                    this.verticalDerecha = false;
                                }
                            }
                        } else {
                            System.out.println("Borde Derecha Sentido Izquierda");
                            if (primeraFichaBordeDerecha) {
                                if (verticalDerecha) {
                                    //Caso 26
                                    System.out.println("CASO 26");
                                    int novaX = posFichaDerecha.getKey();
                                    int novaY = posFichaDerecha.getValue() - 60;
                                    System.out.println(novaX + "," + novaY);
                                    posFichaDerecha = new Pair<>(novaX, novaY);
                                    String p1 = primerValor + "";
                                    String p2 = segundoValor + "";
                                    String primervalor = "";
                                    if (primerValor != this.valorDerecha) {
                                        primervalor = "<html><p align=\"left\">" + primerValor + "</p><p align=\"left\">-</p><p align=\"left\">" + segundoValor + "</p></html>";
                                        this.valorDerecha = primerValor;
                                    } else {
                                        primervalor = "<html><p align=\"left\">" + segundoValor + "</p><p align=\"left\">-</p><p align=\"left\">" + primerValor + "</p></html>";

                                        this.valorDerecha = segundoValor;
                                    }
                                    System.out.println(valorDerecha);
                                    JButton nuevo = new JButton(primervalor);

                                    nuevo.setBounds(novaX, novaY, tamFichaY, tamFichaX);

                                    //this.add(nuevo);
                                    panelJuego.add(nuevo);
                                    area.append(Jugador + "\n");
                                    area.append("puso la ficha " + p1 + "|" + p2 + "\n");
                                    area.setCaretPosition(area.getDocument().getLength());
                                    TimeUnit.SECONDS.sleep(1);
                                    this.repaint();
                                    this.verticalDerecha = true;
                                } else {
                                    //Caso 25
                                    System.out.println("CASO 25");
                                    int novaX = posFichaDerecha.getKey();
                                    int novaY = posFichaDerecha.getValue() - 50;
                                    System.out.println(novaX + "," + novaY);
                                    posFichaDerecha = new Pair<>(novaX, novaY);
                                    String p1 = primerValor + "";
                                    String p2 = segundoValor + "";
                                    String primervalor = "";
                                    if (primerValor != this.valorDerecha) {
                                        primervalor = "<html><p align=\"left\">" + primerValor + "</p><p align=\"left\">-</p><p align=\"left\">" + segundoValor + "</p></html>";
                                        this.valorDerecha = primerValor;
                                    } else {
                                        primervalor = "<html><p align=\"left\">" + segundoValor + "</p><p align=\"left\">-</p><p align=\"left\">" + primerValor + "</p></html>";
                                        this.valorDerecha = segundoValor;
                                    }
                                    System.out.println(this.valorDerecha);
                                    JButton nuevo = new JButton(primervalor);

                                    nuevo.setBounds(novaX, novaY, tamFichaY, tamFichaX);

                                    //this.add(nuevo);
                                    panelJuego.add(nuevo);
                                    area.append(Jugador + "\n");
                                    area.append("puso la ficha " + p1 + "|" + p2 + "\n");
                                    area.setCaretPosition(area.getDocument().getLength());
                                    TimeUnit.SECONDS.sleep(1);
                                    this.repaint();
                                    this.verticalDerecha = true;
                                }
                                primeraFichaBordeDerecha = false;
                            } else {
                                if (verticalidadFichaActual) {
                                    //Caso 27
                                    System.out.println("CASO 27");
                                    int novaX = posFichaDerecha.getKey();
                                    int novaY = posFichaDerecha.getValue() - 60;
                                    System.out.println(novaX + "," + novaY);
                                    posFichaDerecha = new Pair<>(novaX, novaY);
                                    String p1 = primerValor + "";
                                    String p2 = segundoValor + "";
                                    String primervalor = "<html><p align=\"left\">" + primerValor + "</p><p align=\"left\">-</p><p align=\"left\">" + segundoValor + "</p></html>";
                                    this.valorDerecha = primerValor;
                                    System.out.println(valorDerecha);
                                    JButton nuevo = new JButton(primervalor);

                                    nuevo.setBounds(novaX, novaY, tamFichaY, tamFichaX);
                                    panelJuego.add(nuevo);
                                    area.append(Jugador + "\n");
                                    area.append("puso la ficha " + p1 + "|" + p2 + "\n");
                                    area.setCaretPosition(area.getDocument().getLength());
                                    TimeUnit.SECONDS.sleep(1);
                                    this.repaint();
                                    this.verticalDerecha = true;
                                } else {
                                    //Caso 28
                                    System.out.println("CASO 28");
                                    System.out.println(valorDerecha);
                                    int novaX = posFichaDerecha.getKey();
                                    int novaY = posFichaDerecha.getValue() - 40;
                                    System.out.println(novaX + "," + novaY);
                                    posFichaDerecha = new Pair<>(novaX, novaY - 10);
                                    String p1 = primerValor + "";
                                    String p2 = segundoValor + "";
                                    String primervalor = "";
                                    if (segundoValor != this.valorDerecha) {
                                        primervalor = "<html><p align=\"left\">" + primerValor + " | " + segundoValor + "</html>";
                                        this.valorDerecha = segundoValor;
                                    } else {
                                        primervalor = "<html><p align=\"left\">" + segundoValor + " | " + primerValor + "</html>";
                                        this.valorDerecha = primerValor;
                                    }
                                    System.out.println(this.valorDerecha);
                                    JButton nuevo = new JButton(primervalor);

                                    nuevo.setBounds(novaX, novaY, tamFichaX, tamFichaY);

                                    //this.add(nuevo);
                                    panelJuego.add(nuevo);
                                    area.append(Jugador + "\n");
                                    area.append("puso la ficha " + p1 + "|" + p2 + "\n");
                                    area.setCaretPosition(area.getDocument().getLength());
                                    TimeUnit.SECONDS.sleep(1);
                                    this.repaint();
                                    this.verticalDerecha = false;
                                    derechaSentidoDerecha = true;
                                    primeraFichaBordeDerecha = true;
                                }
                            }
                        }
                    }
                } else {
                    if (izquierdaSentidoIzquierda) {
                        if (Borde(posFichaIzquierda.getKey(), false, true)) {
                            if (verticalIzquierda) {
                                // caso 3 no se puede colocar vertical anterior vertical

                                System.out.println("CASO 3");
                                int novaX = posFichaIzquierda.getKey() - 60;
                                int novaY = posFichaIzquierda.getValue() + 10;
                                System.out.println(novaX + "," + novaY);
                                posFichaIzquierda = new Pair<>(novaX, posFichaIzquierda.getValue());
                                String p1 = primerValor + "";
                                String p2 = segundoValor + "";
                                String primervalor = "";
                                if (segundoValor != this.valorIzquierda) {
                                    primervalor = segundoValor + "|" + primerValor;
                                    this.valorIzquierda = segundoValor;
                                } else {
                                    primervalor = primerValor + "|" + segundoValor;
                                    this.valorIzquierda = primerValor;
                                }

                                System.out.println(valorIzquierda);
                                JButton nuevo = new JButton(primervalor);

                                nuevo.setBounds(novaX, novaY, tamFichaX, tamFichaY);

                                //this.add(nuevo);
                                panelJuego.add(nuevo);
                                area.append(Jugador + "\n");
                                area.append("puso la ficha " + p1 + "|" + p2 + "\n");
                                area.setCaretPosition(area.getDocument().getLength());
                                TimeUnit.SECONDS.sleep(1);
                                this.repaint();
                                this.verticalIzquierda = false;

                            } else {
                                if (verticalidadFichaActual) {
                                    //caso 2
                                    System.out.println("CASO 2");
                                    int novaX = posFichaIzquierda.getKey() - 40;
                                    int novaY = posFichaIzquierda.getValue();
                                    System.out.println(novaX + "," + novaY);
                                    posFichaIzquierda = new Pair<>(novaX, posFichaIzquierda.getValue());
                                    String p1 = primerValor + "";
                                    String p2 = segundoValor + "";
                                    String primervalor = "<html><p align=\"left\">" + primerValor + "</p><p align=\"left\">-</p><p align=\"left\">" + segundoValor + "</p></html>";
                                    JButton nuevo = new JButton(primervalor);

                                    nuevo.setBounds(novaX, novaY, tamFichaY, tamFichaX);

                                    //this.add(nuevo);
                                    panelJuego.add(nuevo);
                                    area.append(Jugador + "\n");
                                    area.append("puso la ficha " + p1 + "|" + p2 + "\n");
                                    area.setCaretPosition(area.getDocument().getLength());
                                    TimeUnit.SECONDS.sleep(1);
                                    this.repaint();
                                    this.verticalIzquierda = true;
                                    this.valorIzquierda = primerValor;

                                } else {
                                    //Caso 1

                                    System.out.println("CASO 1");
                                    int novaX = posFichaIzquierda.getKey() - 60;
                                    int novaY = posFichaIzquierda.getValue() + 10;
                                    System.out.println(novaX + "," + novaY);
                                    posFichaIzquierda = new Pair<>(novaX, posFichaIzquierda.getValue());

                                    String primervalor = "";
                                    if (segundoValor != this.valorIzquierda) {
                                        primervalor = segundoValor + "|" + primerValor;
                                        this.valorIzquierda = segundoValor;
                                    } else {
                                        primervalor = primerValor + "|" + segundoValor;
                                        this.valorIzquierda = primerValor;
                                    }
                                    System.out.println(valorIzquierda);
                                    JButton nuevo = new JButton(primervalor);

                                    nuevo.setBounds(novaX, novaY, tamFichaX, tamFichaY);

                                    //this.add(nuevo);
                                    panelJuego.add(nuevo);
                                    area.append(Jugador + "\n");
                                    area.append("puso la ficha " + primervalor + "\n");
                                    area.setCaretPosition(area.getDocument().getLength());
                                    TimeUnit.SECONDS.sleep(1);
                                    this.repaint();
                                    this.verticalIzquierda = false;

                                }
                            }
                        } else {
                            if (primeraFichaBordeIzquierda) {
                                if (verticalIzquierda) {
                                    //Caso 5
                                    System.out.println("CASO 5");
                                    int novaX = posFichaIzquierda.getKey();
                                    int novaY = posFichaIzquierda.getValue() + 60;
                                    System.out.println(novaX + "," + novaY);
                                    posFichaIzquierda = new Pair<>(novaX, novaY);
                                    String p1 = primerValor + "";
                                    String p2 = segundoValor + "";
                                    String primervalor = "";
                                    if (segundoValor != this.valorIzquierda) {
                                        primervalor = "<html><p align=\"left\">" + primerValor + "</p><p align=\"left\">-</p><p align=\"left\">" + segundoValor + "</p></html>";
                                        this.valorIzquierda = segundoValor;
                                    } else {
                                        primervalor = "<html><p align=\"left\">" + segundoValor + "</p><p align=\"left\">-</p><p align=\"left\">" + primerValor + "</p></html>";
                                        this.valorIzquierda = primerValor;
                                    }
                                    System.out.println(valorIzquierda);
                                    JButton nuevo = new JButton(primervalor);

                                    nuevo.setBounds(novaX, novaY, tamFichaY, tamFichaX);

                                    //this.add(nuevo);
                                    panelJuego.add(nuevo);
                                    area.append(Jugador + "\n");
                                    area.append("puso la ficha " + p1 + "|" + p2 + "\n");
                                    area.setCaretPosition(area.getDocument().getLength());
                                    TimeUnit.SECONDS.sleep(1);
                                    this.repaint();
                                    this.verticalIzquierda = true;
                                } else {
                                    //Caso 4
                                    System.out.println("CASO 4");
                                    int novaX = posFichaIzquierda.getKey();
                                    int novaY = posFichaIzquierda.getValue() + 50;
                                    System.out.println(novaX + "," + novaY);
                                    posFichaIzquierda = new Pair<>(novaX, novaY);
                                    String p1 = primerValor + "";
                                    String p2 = segundoValor + "";
                                    String primervalor = "";
                                    if (segundoValor != this.valorIzquierda) {
                                        primervalor = "<html><p align=\"left\">" + primerValor + "</p><p align=\"left\">-</p><p align=\"left\">" + segundoValor + "</p></html>";
                                        this.valorIzquierda = segundoValor;
                                    } else {
                                        primervalor = "<html><p align=\"left\">" + segundoValor + "</p><p align=\"left\">-</p><p align=\"left\">" + primerValor + "</p></html>";
                                        this.valorIzquierda = primerValor;
                                    }
                                    System.out.println(valorIzquierda);
                                    JButton nuevo = new JButton(primervalor);

                                    nuevo.setBounds(novaX, novaY, tamFichaY, tamFichaX);

                                    //this.add(nuevo);
                                    panelJuego.add(nuevo);
                                    area.append(Jugador + "\n");
                                    area.append("puso la ficha " + p1 + "|" + p2 + "\n");
                                    area.setCaretPosition(area.getDocument().getLength());
                                    TimeUnit.SECONDS.sleep(1);
                                    this.repaint();
                                    this.verticalIzquierda = true;
                                }
                                primeraFichaBordeIzquierda = false;
                            } else {
                                if (verticalidadFichaActual) {
                                    //Caso 6
                                    System.out.println("CASO 6");
                                    int novaX = posFichaIzquierda.getKey();
                                    int novaY = posFichaIzquierda.getValue() + 60;
                                    System.out.println(novaX + "," + novaY);
                                    posFichaIzquierda = new Pair<>(novaX, novaY);
                                    String p1 = primerValor + "";
                                    String p2 = segundoValor + "";
                                    String primervalor = "";
                                    if (segundoValor != this.valorIzquierda) {
                                        primervalor = "<html><p align=\"left\">" + primerValor + "</p><p align=\"left\">-</p><p align=\"left\">" + segundoValor + "</p></html>";
                                        this.valorIzquierda = primerValor;
                                    } else {
                                        primervalor = "<html><p align=\"left\">" + segundoValor + "</p><p align=\"left\">-</p><p align=\"left\">" + primerValor + "</p></html>";
                                        this.valorIzquierda = segundoValor;
                                    }
                                    System.out.println(valorIzquierda);
                                    JButton nuevo = new JButton(primervalor);

                                    nuevo.setBounds(novaX, novaY, tamFichaY, tamFichaX);

                                    //this.add(nuevo);
                                    panelJuego.add(nuevo);
                                    area.append(Jugador + "\n");
                                    area.append("puso la ficha " + p1 + "|" + p2 + "\n");
                                    area.setCaretPosition(area.getDocument().getLength());
                                    TimeUnit.SECONDS.sleep(1);
                                    this.repaint();
                                    this.verticalIzquierda = true;
                                } else {
                                    //Caso 7
                                    System.out.println("CASO 7");
                                    int novaX = posFichaIzquierda.getKey();
                                    int novaY = posFichaIzquierda.getValue() + 60;
                                    System.out.println(novaX + "," + novaY);
                                    posFichaIzquierda = new Pair<>(novaX, novaY - 10);
                                    String p1 = primerValor + "";
                                    String p2 = segundoValor + "";
                                    String primervalor = "";
                                    if (segundoValor != this.valorIzquierda) {
                                        primervalor = "<html><p align=\"left\">" + primerValor + " | " + segundoValor + "</p></html>";
                                        this.valorIzquierda = segundoValor;
                                    } else {
                                        primervalor = "<html><p align=\"left\">" + segundoValor + " | " + primerValor + "</p></html>";
                                        this.valorIzquierda = primerValor;
                                    }
                                    System.out.println(valorIzquierda);
                                    JButton nuevo = new JButton(primervalor);

                                    nuevo.setBounds(novaX, novaY, tamFichaX, tamFichaY);

                                    //this.add(nuevo);
                                    panelJuego.add(nuevo);
                                    area.append(Jugador + "\n");
                                    area.append("puso la ficha " + p1 + "|" + p2 + "\n");
                                    area.setCaretPosition(area.getDocument().getLength());
                                    TimeUnit.SECONDS.sleep(1);
                                    this.repaint();
                                    this.verticalIzquierda = false;
                                    this.izquierdaSentidoIzquierda = false;
                                    this.primeraFichaBordeIzquierda = true;

                                }
                            }
                        }
                    } else {
                        if (Borde(posFichaIzquierda.getKey(), false, false)) {
                            if (this.verticalIzquierda) {
                                //Caso 10
                                System.out.println("CASO 10");
                                int novaX = posFichaIzquierda.getKey() + 40;
                                int novaY = posFichaIzquierda.getValue() + 10;
                                System.out.println(novaX + "," + novaY);
                                posFichaIzquierda = new Pair<>(novaX, posFichaIzquierda.getValue());
                                String p1 = primerValor + "";
                                String p2 = segundoValor + "";
                                String primervalor = "";
                                if (primerValor != this.valorIzquierda) {
                                    primervalor = "<html><p align=\"left\">" + segundoValor + " | " + primerValor + "</p></html>";
                                    this.valorIzquierda = primerValor;
                                } else {
                                    primervalor = "<html><p align=\"left\">" + primerValor + " | " + segundoValor + "</p></html>";
                                    this.valorIzquierda = segundoValor;
                                }
                                System.out.println(valorIzquierda);
                                JButton nuevo = new JButton(primervalor);

                                nuevo.setBounds(novaX, novaY, tamFichaX, tamFichaY);

                                //this.add(nuevo);
                                panelJuego.add(nuevo);
                                area.append(Jugador + "\n");
                                area.append("puso la ficha " + p1 + "|" + p2 + "\n");
                                area.setCaretPosition(area.getDocument().getLength());
                                TimeUnit.SECONDS.sleep(1);
                                this.repaint();
                                this.verticalIzquierda = false;
                            } else {
                                if (verticalidadFichaActual) {
                                    //Caso 9
                                    System.out.println("CASO 9");
                                    int novaX = posFichaIzquierda.getKey() + 60;
                                    int novaY = posFichaIzquierda.getValue();
                                    System.out.println(novaX + "," + novaY);
                                    posFichaIzquierda = new Pair<>(novaX, posFichaIzquierda.getValue());
                                    String p1 = primerValor + "";
                                    String p2 = segundoValor + "";
                                    String primervalor = "<html><p align=\"left\">" + primerValor + "</p><p align=\"left\">-</p><p align=\"left\">" + segundoValor + "</p></html>";
                                    JButton nuevo = new JButton(primervalor);

                                    nuevo.setBounds(novaX, novaY, tamFichaY, tamFichaX);

                                    //this.add(nuevo);
                                    panelJuego.add(nuevo);
                                    area.append(Jugador + "\n");
                                    area.append("puso la ficha " + p1 + "|" + p2 + "\n");
                                    area.setCaretPosition(area.getDocument().getLength());
                                    TimeUnit.SECONDS.sleep(1);
                                    this.repaint();
                                    this.verticalIzquierda = true;
                                    this.valorIzquierda = primerValor;
                                } else {
                                    //Caso 8
                                    System.out.println("CASO 8");
                                    int novaX = posFichaIzquierda.getKey() + 60;
                                    int novaY = posFichaIzquierda.getValue() + 10;
                                    System.out.println(novaX + "," + novaY);
                                    posFichaIzquierda = new Pair<>(novaX, posFichaIzquierda.getValue());
                                    String p1 = primerValor + "";
                                    String p2 = segundoValor + "";
                                    String primervalor = "";
                                    if (primerValor != this.valorIzquierda) {
                                        primervalor = "<html><p align=\"left\">" + segundoValor + " | " + primerValor + "</p></html>";
                                        this.valorIzquierda = primerValor;
                                    } else {
                                        primervalor = "<html><p align=\"left\">" + primerValor + " | " + segundoValor + "</p></html>";
                                        this.valorIzquierda = segundoValor;
                                    }
                                    System.out.println(valorIzquierda);
                                    JButton nuevo = new JButton(primervalor);

                                    nuevo.setBounds(novaX, novaY, tamFichaX, tamFichaY);

                                    //this.add(nuevo);
                                    panelJuego.add(nuevo);
                                    area.append(Jugador + "\n");
                                    area.append("puso la ficha " + p1 + "|" + p2 + "\n");
                                    area.setCaretPosition(area.getDocument().getLength());
                                    TimeUnit.SECONDS.sleep(1);
                                    this.repaint();
                                    this.verticalIzquierda = false;
                                }
                            }
                        } else {
                            System.out.println("Borde Izquierda Sentido Derecha");
                            if (primeraFichaBordeIzquierda) {
                                if (this.verticalIzquierda) {
                                    //Caso 12
                                    System.out.println("CASO 12");
                                    int novaX = posFichaIzquierda.getKey();
                                    int novaY = posFichaIzquierda.getValue() + 60;
                                    System.out.println(novaX + "," + novaY);
                                    posFichaIzquierda = new Pair<>(novaX, novaY);
                                    String p1 = primerValor + "";
                                    String p2 = segundoValor + "";
                                    String primervalor = "";
                                    if (segundoValor != this.valorIzquierda) {
                                        primervalor = "<html><p align=\"left\">" + primerValor + "</p><p align=\"left\">-</p><p align=\"left\">" + segundoValor + "</p></html>";
                                        this.valorIzquierda = segundoValor;
                                    } else {
                                        primervalor = "<html><p align=\"left\">" + segundoValor + "</p><p align=\"left\">-</p><p align=\"left\">" + primerValor + "</p></html>";
                                        this.valorIzquierda = primerValor;
                                    }
                                    System.out.println(valorIzquierda);
                                    JButton nuevo = new JButton(primervalor);

                                    nuevo.setBounds(novaX, novaY, tamFichaY, tamFichaX);

                                    //this.add(nuevo);
                                    panelJuego.add(nuevo);
                                    area.append(Jugador + "\n");
                                    area.append("puso la ficha " + p1 + "|" + p2 + "\n");
                                    area.setCaretPosition(area.getDocument().getLength());
                                    TimeUnit.SECONDS.sleep(1);
                                    this.repaint();
                                    this.verticalIzquierda = true;
                                } else {
                                    //Caso 11
                                    System.out.println("CASO 11");
                                    int novaX = posFichaIzquierda.getKey() + 20;
                                    int novaY = posFichaIzquierda.getValue() + 50;
                                    System.out.println(novaX + "," + novaY);
                                    posFichaIzquierda = new Pair<>(novaX, novaY);

                                    String primervalor = "";
                                    if (segundoValor != this.valorIzquierda) {
                                        primervalor = "<html><p align=\"left\">" + primerValor + "</p><p align=\"left\">-</p><p align=\"left\">" + segundoValor + "</p></html>";
                                        this.valorIzquierda = segundoValor;
                                    } else {
                                        primervalor = "<html><p align=\"left\">" + segundoValor + "</p><p align=\"left\">-</p><p align=\"left\">" + primerValor + "</p></html>";
                                        this.valorIzquierda = primerValor;
                                    }
                                    System.out.println(valorIzquierda);
                                    JButton nuevo = new JButton(primervalor);

                                    nuevo.setBounds(novaX, novaY, tamFichaY, tamFichaX);

                                    //this.add(nuevo);
                                    panelJuego.add(nuevo);
                                    area.append(Jugador + "\n");
                                    area.append("puso la ficha " + primervalor + "\n");
                                    area.setCaretPosition(area.getDocument().getLength());
                                    TimeUnit.SECONDS.sleep(1);
                                    this.repaint();

                                    this.verticalIzquierda = true;
                                }
                                primeraFichaBordeIzquierda = false;
                            } else {
                                if (verticalidadFichaActual) {
                                    //Caso 13
                                    System.out.println("CASO 13");
                                    int novaX = posFichaIzquierda.getKey();
                                    int novaY = posFichaIzquierda.getValue() + 60;
                                    System.out.println(novaX + "," + novaY);
                                    posFichaIzquierda = new Pair<>(novaX, novaY);
                                    String p1 = primerValor + "";
                                    String p2 = segundoValor + "";
                                    String primervalor = "<html><p align=\"left\">" + primerValor + "</p><p align=\"left\">-</p><p align=\"left\">" + segundoValor + "</p></html>";
                                    this.valorIzquierda = primerValor;
                                    System.out.println(valorIzquierda);
                                    JButton nuevo = new JButton(primervalor);

                                    nuevo.setBounds(novaX, novaY, tamFichaY, tamFichaX);

                                    //this.add(nuevo);
                                    panelJuego.add(nuevo);
                                    area.append(Jugador + "\n");
                                    area.append("puso la ficha " + p1 + "|" + p2 + "\n");
                                    area.setCaretPosition(area.getDocument().getLength());
                                    TimeUnit.SECONDS.sleep(1);
                                    this.repaint();

                                    this.verticalIzquierda = true;
                                } else {
                                    //Caso 14
                                    System.out.println("CASO 14");
                                    int novaX = posFichaIzquierda.getKey() - 20;
                                    int novaY = posFichaIzquierda.getValue() + 60;
                                    System.out.println(novaX + "," + novaY);
                                    posFichaIzquierda = new Pair<>(novaX, novaY - 10);
                                    String p1 = primerValor + "";
                                    String p2 = segundoValor + "";
                                    String primervalor = "";
                                    if (segundoValor != this.valorIzquierda) {
                                        primervalor = "<html><p align=\"left\">" + segundoValor + " | " + primerValor + "</p></html>";
                                        this.valorIzquierda = segundoValor;
                                    } else {
                                        primervalor = "<html><p align=\"left\">" + primerValor + " | " + segundoValor + "</p></html>";
                                        this.valorIzquierda = primerValor;
                                    }
                                    System.out.println(valorIzquierda);
                                    JButton nuevo = new JButton(primervalor);

                                    nuevo.setBounds(novaX, novaY, tamFichaX, tamFichaY);

                                    //this.add(nuevo);
                                    panelJuego.add(nuevo);
                                    area.append(Jugador + "\n");
                                    area.append("puso la ficha " + p1 + "|" + p2 + "\n");
                                    area.setCaretPosition(area.getDocument().getLength());
                                    TimeUnit.SECONDS.sleep(1);
                                    this.repaint();

                                    this.verticalIzquierda = false;
                                    this.izquierdaSentidoIzquierda = true;
                                    this.primeraFichaBordeIzquierda = true;
                                }

                            }
                        }
                    }
                }
            }

        }
        System.out.println("Izquierda" + valorIzquierda + "-Derecha" + valorDerecha);
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        panelJuego = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTextArea1 = new javax.swing.JTextArea();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        panelJuego.setBackground(new java.awt.Color(255, 255, 255));
        panelJuego.setPreferredSize(new java.awt.Dimension(600, 800));

        javax.swing.GroupLayout panelJuegoLayout = new javax.swing.GroupLayout(panelJuego);
        panelJuego.setLayout(panelJuegoLayout);
        panelJuegoLayout.setHorizontalGroup(
            panelJuegoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 600, Short.MAX_VALUE)
        );
        panelJuegoLayout.setVerticalGroup(
            panelJuegoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 800, Short.MAX_VALUE)
        );

        jLabel1.setText("jLabel1");

        jLabel2.setText("jLabel2");

        jLabel3.setText("jLabel3");

        jLabel4.setText("jLabel4");

        jLabel5.setText("jLabel5");

        jTextArea1.setColumns(20);
        jTextArea1.setRows(5);
        jScrollPane1.setViewportView(jTextArea1);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(29, 29, 29)
                .addComponent(jLabel1)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(29, 29, 29)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel2)
                            .addComponent(jLabel3)
                            .addComponent(jLabel4)
                            .addComponent(jLabel5))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 357, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)))
                .addComponent(panelJuego, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(427, 427, 427))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(16, 16, 16)
                .addComponent(jLabel1)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(panelJuego, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addContainerGap(9, Short.MAX_VALUE))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(42, 42, 42)
                        .addComponent(jLabel2)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jLabel3)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jLabel4)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jLabel5)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 117, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(48, 48, 48))))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(TableroDomino.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(TableroDomino.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(TableroDomino.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(TableroDomino.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new TableroDomino().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTextArea jTextArea1;
    private javax.swing.JPanel panelJuego;
    // End of variables declaration//GEN-END:variables

    /**
     * @return the matrizDeFichas
     */
    public java.util.List<java.util.List<juegosTablero.aplicacion.domino.Ficha>> getMatrizDeFichas() {
        return matrizDeFichas;
    }

    /**
     * @param matrizDeFichas the matrizDeFichas to set
     */
    public void setMatrizDeFichas(java.util.List<java.util.List<juegosTablero.aplicacion.domino.Ficha>> matrizDeFichas) {
        this.matrizDeFichas = matrizDeFichas;
    }

    public String getEmpieza() {
        return empieza;
    }
}
