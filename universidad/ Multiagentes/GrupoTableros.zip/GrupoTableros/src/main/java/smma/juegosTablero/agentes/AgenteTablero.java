/*
 * Copyright (C) 2019 David
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
package smma.juegosTablero.agentes;

import jade.content.Concept;
import jade.content.ContentElement;
import jade.content.ContentManager;
import jade.content.Predicate;
import jade.content.lang.Codec;
import jade.content.lang.sl.SLCodec;
import jade.content.onto.BeanOntologyException;
import jade.content.onto.OntologyException;
import jade.content.onto.basic.Action;
import jade.core.AID;
import jade.core.Agent;
import jade.core.behaviours.OneShotBehaviour;
import jade.domain.FIPAAgentManagement.NotUnderstoodException;
import jade.domain.FIPAAgentManagement.RefuseException;
import jade.domain.FIPANames;
import jade.lang.acl.ACLMessage;
import jade.lang.acl.MessageTemplate;
import jade.proto.AchieveREInitiator;
import jade.proto.ContractNetInitiator;
import jade.proto.ProposeInitiator;
import jade.proto.SimpleAchieveREResponder;
import java.util.ArrayList;
import java.util.Date;
import java.util.Enumeration;
import java.util.Vector;
import java.util.concurrent.TimeUnit;
import java.util.logging.Level;
import java.util.logging.Logger;
import juegosTablero.Vocabulario;
import juegosTablero.Vocabulario.Efecto;
import juegosTablero.Vocabulario.Incidencia;
import juegosTablero.aplicacion.barcos.ColocarBarcos;
import juegosTablero.aplicacion.barcos.EstadoJuego;
import juegosTablero.aplicacion.barcos.JuegoBarcos;
import juegosTablero.aplicacion.barcos.Localizacion;
import juegosTablero.aplicacion.barcos.MovimientoEntregado;
import juegosTablero.aplicacion.barcos.PosicionBarcos;
import juegosTablero.aplicacion.barcos.ResultadoMovimiento;
import juegosTablero.aplicacion.conecta4.JuegoConecta4;
import juegosTablero.aplicacion.domino.Ficha;
import juegosTablero.aplicacion.domino.JuegoDomino;
import juegosTablero.aplicacion.domino.RepartirFichas;
import juegosTablero.dominio.OntologiaJuegosTablero;
import juegosTablero.dominio.elementos.ClasificacionJuego;
import juegosTablero.dominio.elementos.CompletarJuego;
import juegosTablero.dominio.elementos.IncidenciaJuego;
import juegosTablero.dominio.elementos.Juego;
import juegosTablero.dominio.elementos.JuegoAceptado;
import juegosTablero.dominio.elementos.Jugador;
import juegosTablero.dominio.elementos.Motivacion;
import juegosTablero.dominio.elementos.PedirMovimiento;
import smma.juegosTablero.tableros.TableroDomino;
import smma.juegosTablero.tableros.tableroBarcos;
import smma.juegosTablero.tableros.tableroConecta4;
import utilidades.ArrayConversor;
import utilidades.GestorSuscripciones;
import utilidades.ManejadorSuscripcion;

/**
 *
 * @author David
 */
public class AgenteTablero extends AgenteOntologiaJuegos {

    //Variables del agente
    private boolean clasificacionEnviada = false;
    private tableroBarcos tBarcos = null;
    private tableroConecta4 tConecta = null;
    private TableroDomino tDomino = null;
    private GestorSuscripciones gestor;

    private java.util.List<Jugador> jugadores;
    private ArrayList<String> log;

    private Vocabulario.TipoJuego tipJuego;
    private Concept informacionJuego; // Concept tipo juego

    private jade.content.onto.Ontology ontologiaBarcos;
    private jade.content.onto.Ontology ontologiaConecta4;
    private jade.content.onto.Ontology ontologiaDomino;
    private jade.content.onto.Ontology ontologiaDominio;
    private final jade.content.lang.Codec codec = new SLCodec();
    private final jade.content.ContentManager managerBarcos = (ContentManager) getContentManager();
    private final jade.content.ContentManager managerConecta4 = (ContentManager) getContentManager();
    private final jade.content.ContentManager managerDomino = (ContentManager) getContentManager();
    private final jade.content.ContentManager managerDominio = (ContentManager) getContentManager();

    private int modo = 2;
    private int turno;
    private int maxJugadores = 2;
    private int numJugadoresPasando = 0;
    private ArrayList<AID> jugadoresPuntuacionAID;
    private ArrayList<Integer> puntuacionJugadores;
    private AID grupo;

    private Juego juego;
    private ACLMessage templateContractNet;
    private int jugadoresColocados = 0;
    private int jugadoresRespondidos = 0;
    private int proxTurno;

    @Override
    protected void setup() {
        super.setup();
        turno = 0;
        proxTurno = 0;
        jugadoresPuntuacionAID = new ArrayList<>();
        puntuacionJugadores = new ArrayList<>();
        //Inicialización de las variables del agente
        gestor = new GestorSuscripciones();
        MessageTemplate plantilla = MessageTemplate.MatchProtocol(FIPANames.InteractionProtocol.FIPA_SUBSCRIBE);
        ManejadorSuscripcion hacerSuscripcion = new ManejadorSuscripcion(this, plantilla, gestor);
        //Configuración del GUI
        //Registro del agente en las Páginas Amarrillas
        try {
            //Registro de la Ontología
            ontologiaDominio = OntologiaJuegosTablero.getInstance();
            ontologiaBarcos = juegosTablero.aplicacion.OntologiaJuegoBarcos.getInstance();
            ontologiaConecta4 = juegosTablero.aplicacion.OntologiaJuegoConecta4.getInstance();
            ontologiaDomino = juegosTablero.aplicacion.OntologiaJuegoDomino.getInstance();
        } catch (BeanOntologyException ex) {
            Logger.getLogger(AgenteTablero.class.getName()).log(Level.SEVERE, null, ex);
        }

        managerDominio.registerLanguage(codec);
        managerDominio.registerOntology(ontologiaDominio);
        managerBarcos.registerLanguage(codec);
        managerBarcos.registerOntology(ontologiaBarcos);
        managerConecta4.registerLanguage(codec);
        managerConecta4.registerOntology(ontologiaConecta4);
        managerDomino.registerLanguage(codec);
        managerDomino.registerOntology(ontologiaDomino);

        System.out.println("Se inicia la ejecución del agente: " + this.getName());
        //Añadir las tareas principales
        MessageTemplate template = MessageTemplate.and(
                MessageTemplate.MatchProtocol(FIPANames.InteractionProtocol.FIPA_PROPOSE),
                MessageTemplate.MatchPerformative(ACLMessage.PROPOSE));

        addBehaviour(new TableroResponder(this, template));
        //addBehaviour(hacerSuscripcion);
    }

    @Override
    protected void takeDown() {
        //Eliminar registro del agente en las Páginas Amarillas
        switch (tipJuego) {
            case BARCOS:
                tBarcos.setVisible(false);
                break;
            case CONECTA_4:
                tConecta.setVisible(false);
                break;
            case DOMINO:
                tDomino.setVisible(false);
                break;
        }
        //Liberación de recursos, incluido el GUI
        //Despedida
        System.out.println("Finaliza la ejecución del agente: " + this.getName());
    }

    //Métodos de trabajo del agente
    //Clases internas que representan las tareas del agente
    private class TableroResponder extends SimpleAchieveREResponder {

        public TableroResponder(Agent a, MessageTemplate mt) {
            super(a, mt);
        }

        @Override
        protected ACLMessage prepareResponse(ACLMessage propose) throws NotUnderstoodException, RefuseException {

            ACLMessage respuesta = propose.createReply();

            respuesta.setLanguage(codec.getName());

            CompletarJuego completarJuego = null;
            JuegoBarcos juegoBarcos = null;
            JuegoDomino juegoDomino = null;
            JuegoConecta4 juegoConecta = null;

            try {
                //Extraemos el contenido del mensaje propose recibido
                ContentElement content = extraerMensaje(propose);
                if (content instanceof Action) {
                    if (((Action) content).getAction() instanceof CompletarJuego) {
                        completarJuego = (CompletarJuego) ((Action) content).getAction();
                        respuesta.setOntology(getSelectedOntologia(completarJuego.getJuego().getTipoJuego()).getName());
                        tipJuego = completarJuego.getJuego().getTipoJuego();
                        informacionJuego = completarJuego.getTipoJuego();
                        grupo = propose.getSender();
                    } else {
                        System.out.println("No entiendo en el mensaje 1");
                        throw new NotUnderstoodException(propose.getOntology());
                    }
                } else {
                    System.out.println("No entiendo en el mensaje 2");
                    throw new NotUnderstoodException(propose.getOntology());
                }
            } catch (Exception ex) {
                Logger.getLogger(AgenteGrupoJuego.class.getName()).log(Level.SEVERE, null, ex);
            }

            //Acepta jugar
            if (true) {

                //System.out.println("Agent " + getLocalName() + ": Accept");
                respuesta.setPerformative(ACLMessage.ACCEPT_PROPOSAL);
                JuegoAceptado aceptado = new JuegoAceptado(completarJuego.getJuego(), new juegosTablero.dominio.elementos.Jugador(myAgent.getName(), myAgent.getAID()));
                //Incluir contenido del mensaje
                jugadores = ArrayConversor.fromJade2Java(completarJuego.getListaJugadores());
                inicializarTablero(tipJuego, informacionJuego);
                juego = completarJuego.getJuego();

                if (tipJuego == Vocabulario.TipoJuego.BARCOS) {
                    addBehaviour(new enviarColocarBarcos(this.myAgent, completarJuego.getJuego()));
                }

                if (tipJuego == Vocabulario.TipoJuego.DOMINO) {
                    maxJugadores = 4;
                    addBehaviour(new enviarFichas(myAgent, completarJuego.getJuego()));
                }

                try {
                    findManager(getSelectedOntologia(juego.getTipoJuego()).getName()).fillContent(respuesta, aceptado);
                    if (tipJuego == Vocabulario.TipoJuego.CONECTA_4) {
                        addBehaviour(new PrepararContractNet());
                    }
                } catch (Codec.CodecException ex) {
                    Logger.getLogger(AgenteGrupoJuego.class.getName()).log(Level.SEVERE, null, ex);
                } catch (OntologyException ex) {
                    Logger.getLogger(AgenteGrupoJuego.class.getName()).log(Level.SEVERE, null, ex);
                } catch (Exception ex) {
                    Logger.getLogger(AgenteTablero.class.getName()).log(Level.SEVERE, null, ex);
                }

                return respuesta;
            } else {
                //Rechazar juego 
                // System.out.println("Agent " + getLocalName() + ": reject");
                respuesta.setPerformative(ACLMessage.REJECT_PROPOSAL);

                Motivacion motivacion = new Motivacion(completarJuego.getJuego(), juegosTablero.Vocabulario.Motivo.JUEGOS_ACTIVOS_SUPERADOS);
                try {
                    managerBarcos.fillContent(respuesta, motivacion);
                } catch (Codec.CodecException ex) {
                    Logger.getLogger(AgenteGrupoJuego.class.getName()).log(Level.SEVERE, null, ex);
                } catch (OntologyException ex) {
                    Logger.getLogger(AgenteGrupoJuego.class.getName()).log(Level.SEVERE, null, ex);
                }

                return respuesta;
            }
        }

    }

    private void inicializarTablero(juegosTablero.Vocabulario.TipoJuego tipo, Concept informacionJuego) {
        switch (tipo) {
            case BARCOS:
                JuegoBarcos juegoBarco = (JuegoBarcos) informacionJuego;
                tBarcos = new tableroBarcos("Partida Normal", jugadores.get(0).getNombre(), jugadores.get(1).getNombre(), juegoBarco.getTablero().getDimX(), juegoBarco.getTablero().getDimY());
                tBarcos.setVisible(true);
                break;
            case CONECTA_4:
                JuegoConecta4 juegoConecta = (JuegoConecta4) informacionJuego;
                tConecta = new tableroConecta4("Partida Normal", jugadores.get(0).getNombre(), jugadores.get(1).getNombre(), juegoConecta.getTablero().getDimX(), juegoConecta.getTablero().getDimY());
                tConecta.setVisible(true);
                break;
            case DOMINO:
                tDomino = new TableroDomino("Partida Normal", jugadores.get(0).getNombre(), jugadores.get(1).getNombre(), jugadores.get(2).getNombre(), jugadores.get(3).getNombre());
                tDomino.setVisible(true);
                break;
        }
    }

    public class Propose extends ProposeInitiator {

        public Propose(Agent a, ACLMessage msg) {
            super(a, msg);
        }

        @Override
        protected void handleAcceptProposal(ACLMessage inform) {
            //System.out.println("Agent " + inform.getSender().getName() + " successfully performed the requested action");
            try {
                ContentElement content = extraerMensaje(inform);
                PosicionBarcos posicionBarcos = null;
                if (content instanceof Predicate) {
                    if (((Predicate) content) instanceof PosicionBarcos) {
                        posicionBarcos = (PosicionBarcos) ((Predicate) content);
                        // System.out.println("Posicion barcos: " + posicionBarcos.getLocalizacionBarcos().toString());
                        //Colocar barcos en tablero
                        java.util.List<Localizacion> listaPosiciones = ArrayConversor.fromJade2Java(posicionBarcos.getLocalizacionBarcos());
                        //System.out.println(inform.getSender().getName() + "-------------");
                        for (int i = 0; i < listaPosiciones.size(); i++) {
                            tBarcos.ColocarBarco(inform.getSender().getName(), listaPosiciones.get(i).getBarco(), listaPosiciones.get(i).getOrientacion(), listaPosiciones.get(i).getPosicion());
                        }
                        jugadoresColocados++;
                        if (jugadoresColocados == 2) {

                            addBehaviour(new PrepararContractNet());
                        }
                    } else {
                        System.out.println("No entiendo en el mensaje 1");
                        throw new NotUnderstoodException(inform.getOntology());
                    }
                } else {
                    System.out.println("No entiendo en el mensaje 2");
                    throw new NotUnderstoodException(inform.getOntology());
                }
            } catch (Exception ex) {
                Logger.getLogger(AgenteTablero.class.getName()).log(Level.SEVERE, null, ex);
            }
        }

        @Override
        protected void handleRejectProposal(ACLMessage refuse) {
            System.out.println("Agent " + refuse.getSender().getName() + " refused to perform the requested action");

        }

    }

    public class ProposeDomino extends ProposeInitiator {

        public ProposeDomino(Agent a, ACLMessage msg) {
            super(a, msg);
        }

        @Override
        protected void handleAcceptProposal(ACLMessage inform) {
            //System.out.println("Agent " + inform.getSender().getName() + " successfully performed the requested action from EnviarFichasDomino");

            turno++;
            if (turno == 4) {

                for (int i = 0; i < jugadores.size(); i++) {
                    if (jugadores.get(i).getNombre().equals(tDomino.getEmpieza())) {
                        turno = i;
                    }
                }

                addBehaviour(new PrepararContractNet());
            }
        }

        @Override
        protected void handleRejectProposal(ACLMessage refuse) {
            System.out.println("Agent " + refuse.getSender().getName() + " refused to perform the requested action");

        }

    }

    public class ProposeClasificacion extends AchieveREInitiator {

        public ProposeClasificacion(Agent a, ACLMessage msg) {
            super(a, msg);

        }

        @Override
        protected void handleInform(ACLMessage inform) {
            System.out.println("Agent " + inform.getSender().getName() + " successfully performed the requested action");
        }

        @Override
        protected void handleRefuse(ACLMessage refuse) {
            System.out.println("Agent " + refuse.getSender().getName() + " refused to perform the requested action");

        }

        @Override
        protected void handleFailure(ACLMessage failure) {
            if (failure.getSender().equals(myAgent.getAMS())) {
                // FAILURE notification from the JADE runtime: the receiver
                // does not exist
                System.out.println("Responder does not exist");
            } else {
                System.out.println("Agent " + failure.getSender().getName() + " failed to perform the requested action");
            }
        }

    }

    public class enviarColocarBarcos extends OneShotBehaviour {

        private Juego juego;

        public enviarColocarBarcos(Agent a, Juego juego) {
            super(a);

            this.juego = juego;
        }

        @Override
        public void action() {
            ColocarBarcos colocacion = new ColocarBarcos(juego);
            Action ac = new Action(this.myAgent.getAID(), colocacion);
            try {
                //Crear tablero = new agenteTablero()
                java.util.ArrayList<AID> receptores = new java.util.ArrayList<>();
                for (int i = 0; i < jugadores.size(); i++) {
                    receptores.add(jugadores.get(i).getAgenteJugador());
                }
                ACLMessage propose = mensajeProposal(receptores, ac, getSelectedOntologia(juego.getTipoJuego())); //listJugadores hay que cambiarlo por el tablero creado
                addBehaviour(new AgenteTablero.Propose(this.myAgent, propose));
            } catch (Exception ex) {
                Logger.getLogger(AgenteGrupoJuego.class.getName()).log(Level.SEVERE, null, ex);
            }

        }

    }

    public class enviarClasi extends OneShotBehaviour {

        private Juego juego;
        private ClasificacionJuego concept;

        public enviarClasi(Agent a, Juego juego, ClasificacionJuego concepto) {
            super(a);

            this.concept = concepto;
            this.juego = juego;
        }

        @Override
        public void action() {
            java.util.ArrayList<AID> receptores = new java.util.ArrayList<>();
            receptores.add(grupo);
            try {
                ACLMessage msg = new ACLMessage(ACLMessage.REQUEST);
                msg.setProtocol(FIPANames.InteractionProtocol.FIPA_REQUEST);
                msg.setSender(this.myAgent.getAID());
                msg.setLanguage(codec.getName());
                msg.setOntology(getSelectedOntologia(juego.getTipoJuego()).getName());

                for (AID receiver : receptores) {
                    msg.addReceiver(receiver);
                }

                findManager(getSelectedOntologia(juego.getTipoJuego()).getName()).fillContent(msg, concept);
                addBehaviour(new ProposeClasificacion(this.myAgent, msg));
            } catch (Exception ex) {
                Logger.getLogger(AgenteTablero.class.getName()).log(Level.SEVERE, null, ex);
            }
        }

    }

    public class enviarInci extends OneShotBehaviour {

        private Juego juego;
        private IncidenciaJuego concept;

        public enviarInci(Agent a, Juego juego, IncidenciaJuego concepto) {
            super(a);

            this.concept = concepto;
            this.juego = juego;
        }

        @Override
        public void action() {

            java.util.ArrayList<AID> receptores = new java.util.ArrayList<>();
            receptores.add(grupo);
            try {
                ACLMessage msg = new ACLMessage(ACLMessage.REQUEST);
                msg.setProtocol(FIPANames.InteractionProtocol.FIPA_REQUEST);
                msg.setSender(this.myAgent.getAID());
                msg.setLanguage(codec.getName());
                msg.setOntology(getSelectedOntologia(juego.getTipoJuego()).getName());

                for (AID receiver : receptores) {
                    msg.addReceiver(receiver);
                }

                findManager(getSelectedOntologia(juego.getTipoJuego()).getName()).fillContent(msg, concept);
                addBehaviour(new ProposeClasificacion(this.myAgent, msg));
            } catch (Exception ex) {
                Logger.getLogger(AgenteTablero.class.getName()).log(Level.SEVERE, null, ex);
            }
        }

    }

    public class enviarFichas extends OneShotBehaviour {

        private Juego juego;

        public enviarFichas(Agent a, Juego juego) {
            super(a);

            this.juego = juego;
        }

        @Override
        public void action() {
            java.util.List<java.util.List<Ficha>> fichas = tDomino.getMatrizDeFichas();

            for (int i = 0; i < fichas.size(); i++) {

                java.util.List<Concept> fichConcept = new ArrayList<>();
                java.util.List<Ficha> fich = fichas.get(i);
                for (int j = 0; j < fich.size(); j++) {
                    fichConcept.add(fich.get(j));
                }
                java.util.ArrayList<AID> receptores = new java.util.ArrayList<>();
                receptores.add(jugadores.get(i).getAgenteJugador());
                RepartirFichas reparto = new RepartirFichas(juego, ArrayConversor.fromJava2Jade(fichConcept));
                Action ac = new Action(this.myAgent.getAID(), reparto);
                try {
                    ACLMessage propose = mensajeProposal(receptores, ac, getSelectedOntologia(juego.getTipoJuego())); //listJugadores hay que cambiarlo por el tablero creado
                    System.out.println("Reparto de fichas en Tablero ");
                    addBehaviour(new AgenteTablero.ProposeDomino(this.myAgent, propose));
                } catch (Exception ex) {
                    Logger.getLogger(AgenteTablero.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
        }

    }

    public class PrepararContractNet extends OneShotBehaviour {

        @Override
        public void action() {
            jugadoresRespondidos = 0;
            ACLMessage msg = new ACLMessage(ACLMessage.CFP);
            for (int i = 0; i < jugadores.size(); i++) {
                msg.addReceiver(jugadores.get(i).getAgenteJugador());
            }
            msg.setLanguage(codec.getName());
            try {
                msg.setOntology(getSelectedOntologia(juego.getTipoJuego()).getName());
            } catch (Exception ex) {
                Logger.getLogger(AgenteTablero.class.getName()).log(Level.SEVERE, null, ex);
            }
            msg.setProtocol(FIPANames.InteractionProtocol.FIPA_CONTRACT_NET);
            // We want to receive a reply in 10 secs
            msg.setReplyByDate(new Date(System.currentTimeMillis() + 10000));

            PedirMovimiento movimiento = new PedirMovimiento(juego, jugadores.get(turno));
            turno++;
            if (turno == maxJugadores) {
                turno = 0;
            }
            Action action = new Action(myAgent.getAID(), movimiento);
            try {
                managerDomino.fillContent(msg, action);
                addBehaviour(new TableroContractNet(myAgent, msg));
            } catch (Codec.CodecException ex) {
                Logger.getLogger(AgenteTablero.class.getName()).log(Level.SEVERE, null, ex);
            } catch (OntologyException ex) {
                Logger.getLogger(AgenteTablero.class.getName()).log(Level.SEVERE, null, ex);
            }
        }

    }

    public class TableroContractNet extends ContractNetInitiator {

        public TableroContractNet(Agent a, ACLMessage cfp) {
            super(a, cfp);
        }

        protected void handlePropose(ACLMessage propose, Vector v) {

        }

        protected void handleRefuse(ACLMessage refuse) {
            System.out.println("Agent " + refuse.getSender().getName() + " refused");
        }

        protected void handleFailure(ACLMessage failure) {
            if (failure.getSender().equals(myAgent.getAMS())) {
                // FAILURE notification from the JADE runtime: the receiver
                // does not exist
                System.out.println("Responder does not exist");
                IncidenciaJuego incidencia = new IncidenciaJuego(juego, Incidencia.ERROR_AGENTE);
                addBehaviour(new enviarInci(myAgent, juego, incidencia));
            } else {
                System.out.println("Agent " + failure.getSender().getName() + " failed");
            }
            // Immediate failure --> we will not receive a response from this agent
        }

        protected void handleAllResponses(Vector responses, Vector acceptances) {
            if (responses.size() < jugadores.size()) {
                // Some responder didn't reply within the specified timeout
                System.out.println("Timeout expired: missing " + (2 - responses.size()) + " responses");
                IncidenciaJuego incidencia = new IncidenciaJuego(juego, Incidencia.ERROR_AGENTE);
                addBehaviour(new enviarInci(myAgent, juego, incidencia));
            }
            // Evaluate proposals.
            if (tipJuego == Vocabulario.TipoJuego.BARCOS) {
                Enumeration e = responses.elements();
                juegosTablero.aplicacion.barcos.MovimientoEntregado mov = null;
                while (e.hasMoreElements()) {
                    ACLMessage msg = (ACLMessage) e.nextElement();

                    if (msg.getPerformative() == ACLMessage.PROPOSE) {
                        if (msg.getContent() != null) {
                            //System.out.println("Agent " + msg.getSender().getName() + " proposed " + msg.getContent());
                            try {
                                //Extraemos el contenido del mensaje propose recibido
                                ContentElement content = extraerMensaje(msg);
                                if (content instanceof Predicate) {
                                    if (((Predicate) content) instanceof MovimientoEntregado) {
                                        mov = (juegosTablero.aplicacion.barcos.MovimientoEntregado) ((Predicate) content);
                                        Efecto efecto = tBarcos.Disparar(msg.getSender().getName(), mov.getMovimiento().getCoorX(), mov.getMovimiento().getCoorY());
                                        TimeUnit.SECONDS.sleep(1);
                                        //.println(efecto);
                                        ResultadoMovimiento resultado = new ResultadoMovimiento(juego, mov.getMovimiento(), efecto);
                                        ACLMessage reply = msg.createReply();
                                        reply.setSender(myAgent.getAID());
                                        reply.setPerformative(ACLMessage.ACCEPT_PROPOSAL);
                                        reply.setOntology(ontologiaBarcos.getName());
                                        reply.setLanguage(codec.getName());
                                        for (int i = 0; i < jugadores.size(); i++) {
                                            reply.addReceiver(jugadores.get(i).getAgenteJugador());
                                        }
                                        managerBarcos.fillContent(reply, resultado);
                                        acceptances.add(reply);
                                    } else {
                                        System.out.println("No entiendo en el mensaje 1");
                                        throw new NotUnderstoodException(msg.getOntology());
                                    }
                                } else {
                                    System.out.println("No entiendo en el mensaje 2");
                                    throw new NotUnderstoodException(msg.getOntology());
                                }

                            } catch (Exception ex) {
                                Logger.getLogger(AgenteGrupoJuego.class.getName()).log(Level.SEVERE, null, ex);
                            }
                        }
                    }

                }
            }

            if (tipJuego == Vocabulario.TipoJuego.DOMINO) {
                Enumeration e = responses.elements();
                juegosTablero.aplicacion.domino.MovimientoEntregado mov = null;
                while (e.hasMoreElements()) {
                    ACLMessage msg = (ACLMessage) e.nextElement();

                    if (msg.getPerformative() == ACLMessage.PROPOSE) {
                        if (msg.getContent() != null) {
                            //.println("Agent " + msg.getSender().getName() + " proposed " + msg.getContent());
                            try {
                                //Extraemos el contenido del mensaje propose recibido
                                ContentElement content = extraerMensaje(msg);
                                if (content instanceof Predicate) {
                                    if (((Predicate) content) instanceof juegosTablero.aplicacion.domino.MovimientoEntregado) {
                                        mov = (juegosTablero.aplicacion.domino.MovimientoEntregado) ((Predicate) content);
                                        if (mov.getMovimiento().getColocacion() != juegosTablero.Vocabulario.Colocacion.PASAR) {
                                            tDomino.ficha(mov.getMovimiento().getFicha().getValorInf(), mov.getMovimiento().getFicha().getValorSup(), mov.getMovimiento().getColocacion(), msg.getSender().getName());
                                            numJugadoresPasando = 0;
                                            TimeUnit.MILLISECONDS.sleep(500);
                                        } else {
                                            numJugadoresPasando++;
                                        }

                                        juegosTablero.aplicacion.domino.MovimientoEntregado movi = new juegosTablero.aplicacion.domino.MovimientoEntregado(mov.getJuego(), mov.getMovimiento());

                                        ACLMessage reply = msg.createReply();
                                        reply.setSender(myAgent.getAID());
                                        reply.setPerformative(ACLMessage.ACCEPT_PROPOSAL);
                                        reply.setLanguage(codec.getName());
                                        reply.setOntology(ontologiaDomino.getName());
                                        for (int i = 0; i < jugadores.size(); i++) {
                                            reply.addReceiver(jugadores.get(i).getAgenteJugador());
                                        }
                                        findManager(getSelectedOntologia(Vocabulario.TipoJuego.DOMINO).getName()).fillContent(reply, movi);
                                        acceptances.add(reply);
                                    } else {
                                        System.out.println("No entiendo en el mensaje 1");
                                        throw new NotUnderstoodException(msg.getOntology());
                                    }
                                } else {
                                    System.out.println("No entiendo en el mensaje 2");
                                    throw new NotUnderstoodException(msg.getOntology());
                                }

                            } catch (Exception ex) {
                                Logger.getLogger(AgenteGrupoJuego.class.getName()).log(Level.SEVERE, null, ex);
                            }
                        }
                    }

                }
            }

            if (tipJuego == Vocabulario.TipoJuego.CONECTA_4) {
                Enumeration e = responses.elements();
                juegosTablero.aplicacion.conecta4.MovimientoEntregado mov = null;
                while (e.hasMoreElements()) {
                    ACLMessage msg = (ACLMessage) e.nextElement();

                    if (msg.getPerformative() == ACLMessage.PROPOSE) {
                        if (msg.getContent() != null) {
                            try {
                                //Extraemos el contenido del mensaje propose recibido
                                ContentElement content = extraerMensaje(msg);
                                if (content instanceof Predicate) {
                                    if (((Predicate) content) instanceof juegosTablero.aplicacion.conecta4.MovimientoEntregado) {
                                        mov = (juegosTablero.aplicacion.conecta4.MovimientoEntregado) ((Predicate) content);

                                        tConecta.ColocarFicha(mov.getMovimiento().getPosicion().getCoorY());

                                        juegosTablero.aplicacion.conecta4.MovimientoEntregado movi = new juegosTablero.aplicacion.conecta4.MovimientoEntregado(mov.getJuego(), mov.getMovimiento());

                                        ACLMessage reply = msg.createReply();
                                        reply.setSender(myAgent.getAID());
                                        reply.setPerformative(ACLMessage.ACCEPT_PROPOSAL);
                                        reply.setOntology(ontologiaConecta4.getName());
                                        reply.setLanguage(codec.getName());
                                        for (int i = 0; i < jugadores.size(); i++) {
                                            reply.addReceiver(jugadores.get(i).getAgenteJugador());
                                        }
                                        findManager(getSelectedOntologia(Vocabulario.TipoJuego.CONECTA_4).getName()).fillContent(reply, movi);
                                        acceptances.add(reply);
                                    } else {
                                        System.out.println("No entiendo en el mensaje 1");
                                        throw new NotUnderstoodException(msg.getOntology());
                                    }
                                } else {
                                    System.out.println("No entiendo en el mensaje 2");
                                    throw new NotUnderstoodException(msg.getOntology());
                                }

                            } catch (Exception ex) {
                                Logger.getLogger(AgenteGrupoJuego.class.getName()).log(Level.SEVERE, null, ex);
                            }
                        }
                    }

                }
            }

        }

        protected void handleInform(ACLMessage inform) {
            EstadoJuego estado = null;
            ACLMessage msg = inform.createReply();
            try {
                msg.setOntology(getSelectedOntologia(tipJuego).getName());
            } catch (Exception ex) {
                Logger.getLogger(AgenteTablero.class.getName()).log(Level.SEVERE, null, ex);
            }
            msg.setLanguage(codec.getName());
            msg.setSender(myAgent.getAID());
            msg.setPerformative(ACLMessage.INFORM);
            if (tipJuego == Vocabulario.TipoJuego.BARCOS) {
                try {
                    //Extraemos el contenido del mensaje propose recibido
                    ContentElement content = extraerMensaje(inform);
                    if (content instanceof Predicate) {
                        if (((Predicate) content) instanceof EstadoJuego) {
                            estado = (EstadoJuego) ((Predicate) content);
                            switch (estado.getEstadoJuego()) {
                                case SEGUIR_JUGANDO:
                                    proxTurno++;
                                    if (proxTurno == 2) {

                                        addBehaviour(new PrepararContractNet());
                                        proxTurno = 0;
                                    }
                                    break;
                                case ABANDONO:
                                    IncidenciaJuego incidencia = new IncidenciaJuego(juego, Incidencia.CANCELACION);
                                    addBehaviour(new enviarInci(myAgent, estado.getJuego(), incidencia));
                                    break;
                                case FIN_PARTIDA:
                                    java.util.List<Concept> jug2 = new java.util.ArrayList<Concept>();
                                    jade.util.leap.List pun2 = new jade.util.leap.ArrayList();
                                    for (int i = 0; i < jugadores.size(); i++) {

                                        jug2.add(jugadores.get(i));
                                        pun2.add(new Integer(0));

                                    }
                                    ClasificacionJuego clasific2 = new ClasificacionJuego(estado.getJuego(), ArrayConversor.fromJava2Jade(jug2), pun2);
                                    if (!clasificacionEnviada) {
                                        addBehaviour(new enviarClasi(this.myAgent, estado.getJuego(), clasific2));
                                        clasificacionEnviada = true;
                                        takeDown();
                                    }
                                    break;
                                case GANADOR:
                                    java.util.List<Concept> jug = new java.util.ArrayList<Concept>();
                                    jade.util.leap.List pun = new jade.util.leap.ArrayList();
                                    for (int i = 0; i < jugadores.size(); i++) {

                                        if (jugadores.get(i).getNombre().equals(inform.getSender().getName())) {
                                            jug.add(jugadores.get(i));
                                            pun.add(new Integer(3));
                                        } else {
                                            jug.add(jugadores.get(i));
                                            pun.add(new Integer(0));

                                        }
                                    }

                                    ClasificacionJuego clasific = new ClasificacionJuego(estado.getJuego(), ArrayConversor.fromJava2Jade(jug), pun);
                                    if (!clasificacionEnviada) {
                                        addBehaviour(new enviarClasi(this.myAgent, estado.getJuego(), clasific));
                                        clasificacionEnviada = true;
                                        takeDown();
                                    }
                                    break;
                            }
                        } else {
                            System.out.println("No entiendo en el mensaje 1");
                            throw new NotUnderstoodException(inform.getOntology());
                        }
                    } else {
                        System.out.println("No entiendo en el mensaje 2");
                        throw new NotUnderstoodException(inform.getOntology());
                    }
                } catch (Exception ex) {
                    Logger.getLogger(AgenteGrupoJuego.class.getName()).log(Level.SEVERE, null, ex);
                }
            } else if (tipJuego == Vocabulario.TipoJuego.DOMINO) {
                try {
                    juegosTablero.aplicacion.domino.EstadoJuego estadoJuego = null;
                    //Extraemos el contenido del mensaje propose recibido
                    ContentElement content = extraerMensaje(inform);
                    if (content instanceof Predicate) {
                        if (((Predicate) content) instanceof juegosTablero.aplicacion.domino.EstadoJuego) {
                            estadoJuego = (juegosTablero.aplicacion.domino.EstadoJuego) ((Predicate) content);
                            if (numJugadoresPasando == 4) {

                                //Se ha cerrado el tablero
                                jugadoresPuntuacionAID.add(inform.getSender());
                                puntuacionJugadores.add(estadoJuego.getPuntuacion());

                                if (jugadoresPuntuacionAID.size() == 4) {
                                    ArrayList<Integer> posicionesGanadores = new ArrayList<>();
                                    int menorPuntuacion = Integer.MAX_VALUE;
                                    for (int i = 0; i < 4; i++) {
                                        if (puntuacionJugadores.get(i) < menorPuntuacion) {
                                            posicionesGanadores.clear();
                                            posicionesGanadores.add(i);
                                        } else if (puntuacionJugadores.get(i) == menorPuntuacion) {
                                            posicionesGanadores.add(i);
                                        }

                                    }

                                    if (posicionesGanadores.size() == 1) {
                                        //Un ganador
                                        int lugar = posicionesGanadores.get(0);
                                        java.util.List<Concept> jug = new java.util.ArrayList<Concept>();
                                        jade.util.leap.List pun = new jade.util.leap.ArrayList();

                                        jug.add(jugadores.get(lugar));
                                        pun.add(new Integer(3));

                                        for (int i = 0; i < jugadores.size(); i++) {
                                            if (i != lugar) {
                                                jug.add(jugadores.get(i));
                                                pun.add(new Integer(0));
                                            }
                                        }

                                        ClasificacionJuego clasific = new ClasificacionJuego(estadoJuego.getJuego(), ArrayConversor.fromJava2Jade(jug), pun);
                                        if (!clasificacionEnviada) {
                                            addBehaviour(new enviarClasi(this.myAgent, estadoJuego.getJuego(), clasific));
                                            clasificacionEnviada = true;
                                            takeDown();
                                        }
                                    } else {
                                        //Varios ganadores(empate)
                                        java.util.List<Concept> jug = new java.util.ArrayList<Concept>();
                                        jade.util.leap.List pun = new jade.util.leap.ArrayList();
                                        for (int i = 0; i < posicionesGanadores.size(); i++) {
                                            jug.add(jugadores.get(i));
                                            pun.add(new Integer(1));
                                        }

                                        for (int i = 0; i < jugadores.size(); i++) {
                                            if (!posicionesGanadores.contains(i)) {
                                                jug.add(jugadores.get(i));
                                                pun.add(new Integer(0));
                                            }
                                        }

                                        ClasificacionJuego clasific = new ClasificacionJuego(estadoJuego.getJuego(), ArrayConversor.fromJava2Jade(jug), pun);
                                        if (!clasificacionEnviada) {
                                            addBehaviour(new enviarClasi(this.myAgent, estadoJuego.getJuego(), clasific));
                                            clasificacionEnviada = true;
                                            takeDown();
                                        }
                                    }

                                }
                            } else {
                                switch (estadoJuego.getEstadoJuego()) {
                                    case SEGUIR_JUGANDO:
                                        proxTurno++;
                                        if (proxTurno == 4) {

                                            addBehaviour(new PrepararContractNet());
                                            proxTurno = 0;
                                        }
                                        break;
                                    case ABANDONO:

                                        IncidenciaJuego incidencia = new IncidenciaJuego(juego, Incidencia.CANCELACION);
                                        addBehaviour(new enviarInci(myAgent, estado.getJuego(), incidencia));
                                        break;
                                    case FIN_PARTIDA:
                                        break;
                                    case GANADOR:
                                        int lugar = 0;
                                        java.util.List<Concept> jug = new java.util.ArrayList<Concept>();
                                        jade.util.leap.List pun = new jade.util.leap.ArrayList();
                                        for (int i = 0; i < jugadores.size(); i++) {
                                            if (jugadores.get(i).getNombre().equals(inform.getSender().getName())) {
                                                jug.add(jugadores.get(i));
                                                pun.add(new Integer(3));

                                                lugar = i;
                                            }
                                        }

                                        for (int i = 0; i < jugadores.size(); i++) {
                                            if (i != lugar) {
                                                jug.add(jugadores.get(i));
                                                pun.add(new Integer(0));
                                            }
                                        }

                                        ClasificacionJuego clasific = new ClasificacionJuego(estadoJuego.getJuego(), ArrayConversor.fromJava2Jade(jug), pun);
                                        if (!clasificacionEnviada) {
                                            addBehaviour(new enviarClasi(this.myAgent, estadoJuego.getJuego(), clasific));
                                            clasificacionEnviada = true;
                                            takeDown();
                                        }
                                        break;
                                }
                            }
                        } else {
                            System.out.println("No entiendo en el mensaje 1");
                            throw new NotUnderstoodException(inform.getOntology());
                        }
                    } else {
                        System.out.println("No entiendo en el mensaje 2");
                        throw new NotUnderstoodException(inform.getOntology());
                    }
                } catch (Exception ex) {
                    Logger.getLogger(AgenteGrupoJuego.class.getName()).log(Level.SEVERE, null, ex);
                }
            } else if (tipJuego == Vocabulario.TipoJuego.CONECTA_4) {
                try {
                    //Extraemos el contenido del mensaje propose recibido
                    ContentElement content = extraerMensaje(inform);
                    if (content instanceof Predicate) {
                        if (((Predicate) content) instanceof juegosTablero.aplicacion.conecta4.EstadoJuego) {
                            juegosTablero.aplicacion.conecta4.EstadoJuego estadoc = (juegosTablero.aplicacion.conecta4.EstadoJuego) ((Predicate) content);
                            switch (estadoc.getEstadoJuego()) {
                                case SEGUIR_JUGANDO:
                                    proxTurno++;
                                    if (proxTurno == 2) {
                                        TimeUnit.MILLISECONDS.sleep(500);
                                        addBehaviour(new PrepararContractNet());
                                        proxTurno = 0;
                                    }
                                    break;
                                case ABANDONO:
                                    IncidenciaJuego incidencia = new IncidenciaJuego(juego, Incidencia.CANCELACION);
                                    addBehaviour(new enviarInci(myAgent, estado.getJuego(), incidencia));
                                    break;
                                case FIN_PARTIDA:
                                    int lugar = 0;
                                    java.util.List<Concept> jug = new java.util.ArrayList<Concept>();
                                    jade.util.leap.List pun = new jade.util.leap.ArrayList();
                                    for (int i = 0; i < jugadores.size(); i++) {

                                        jug.add(jugadores.get(i));
                                        pun.add(new Integer(1));

                                    }
                                    ClasificacionJuego clasific = new ClasificacionJuego(estadoc.getJuego(), ArrayConversor.fromJava2Jade(jug), pun);
                                    if (!clasificacionEnviada) {
                                        addBehaviour(new enviarClasi(this.myAgent, estadoc.getJuego(), clasific));
                                        clasificacionEnviada = true;
                                        takeDown();
                                    }
                                    break;
                                case GANADOR:
                                    int lugar2 = 0;
                                    java.util.List<Concept> jug2 = new java.util.ArrayList<Concept>();
                                    jade.util.leap.List pun2 = new jade.util.leap.ArrayList();
                                    for (int i = 0; i < jugadores.size(); i++) {
                                        if (jugadores.get(i).getNombre().equals(inform.getSender().getName())) {
                                            jug2.add(jugadores.get(i));
                                            pun2.add(new Integer(3));

                                            lugar2 = i;
                                        }
                                    }

                                    for (int i = 0; i < jugadores.size(); i++) {
                                        if (i != lugar2) {
                                            jug2.add(jugadores.get(i));
                                            pun2.add(new Integer(0));
                                        }
                                    }

                                    ClasificacionJuego clasific2 = new ClasificacionJuego(estadoc.getJuego(), ArrayConversor.fromJava2Jade(jug2), pun2);
                                    if (!clasificacionEnviada) {
                                        addBehaviour(new enviarClasi(this.myAgent, estadoc.getJuego(), clasific2));
                                        clasificacionEnviada = true;
                                        takeDown();
                                    }

                                    break;
                            }
                        } else {
                            System.out.println("No entiendo en el mensaje 1");
                            throw new NotUnderstoodException(inform.getOntology());
                        }
                    } else {
                        System.out.println("No entiendo en el mensaje 2");
                        throw new NotUnderstoodException(inform.getOntology());
                    }
                } catch (Exception ex) {
                    Logger.getLogger(AgenteGrupoJuego.class.getName()).log(Level.SEVERE, null, ex);
                }
            } 
        }

    }

}
