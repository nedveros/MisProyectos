/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package smma.juegosTablero.tableros;

import java.util.ArrayList;
import juegosTablero.Vocabulario.Orientacion;
import juegosTablero.Vocabulario.TipoBarco;
import juegosTablero.dominio.elementos.Posicion;

/**
 *
 * @author davidbaudetmoreno
 */
public class Barco {

    private String tipo;
    private ArrayList<Posicion> ListaCoordenadas = new ArrayList<Posicion>();
    private boolean hundido = false;
    private int impactos = 0;
    private boolean vertical = false;

    public Barco(TipoBarco tipo, Posicion p, Orientacion orientacion) {
        this.tipo = tipo.name();

        if (tipo.equals(TipoBarco.FRAGATA)) {

            ListaCoordenadas.add(p);

        }
        
        if(orientacion.equals(juegosTablero.Vocabulario.Orientacion.VERTICAL)){
            vertical= true;
        }

        if (tipo.equals(TipoBarco.DESTRUCTOR)) {

            if (orientacion.equals(Orientacion.HORIZONTAL)) {

                ListaCoordenadas.add(p);
                ListaCoordenadas.add(new Posicion(p.getCoorX(), p.getCoorY() + 1));

            } else {

                ListaCoordenadas.add(p);
                ListaCoordenadas.add(new Posicion(p.getCoorX() + 1, p.getCoorY()));

            }

        }

        if (tipo.equals(TipoBarco.ACORAZADO)) {

            if (orientacion.equals(Orientacion.HORIZONTAL)) {

                ListaCoordenadas.add(p);
                ListaCoordenadas.add(new Posicion(p.getCoorX(), p.getCoorY() + 1));
                ListaCoordenadas.add(new Posicion(p.getCoorX(), p.getCoorY() + 2));

            } else {

                ListaCoordenadas.add(p);
                ListaCoordenadas.add(new Posicion(p.getCoorX() + 1, p.getCoorY()));
                ListaCoordenadas.add(new Posicion(p.getCoorX() + 2, p.getCoorY()));

            }

        }
        if (tipo.equals(TipoBarco.PORTAAVIONES)) {

            if (orientacion.equals(Orientacion.HORIZONTAL)) {

                ListaCoordenadas.add(p);
                ListaCoordenadas.add(new Posicion(p.getCoorX(), p.getCoorY() + 1));
                ListaCoordenadas.add(new Posicion(p.getCoorX(), p.getCoorY() + 2));
                ListaCoordenadas.add(new Posicion(p.getCoorX(), p.getCoorY() + 3));

            } else {

                ListaCoordenadas.add(p);
                ListaCoordenadas.add(new Posicion(p.getCoorX() + 1, p.getCoorY()));
                ListaCoordenadas.add(new Posicion(p.getCoorX() + 2, p.getCoorY()));
                ListaCoordenadas.add(new Posicion(p.getCoorX() + 3, p.getCoorY()));

            }

        }

    }

    public void impacto() {

        setImpactos(getImpactos() + 1);
        System.out.println("Impacto número: " + this.impactos + this.getTipo());

        if (this.getTipo().equals(TipoBarco.FRAGATA.name()) && getImpactos() == 1) {
            System.out.println("ME HAN HUNDI HIJOPUTA");
            setHundido(true);

        }

        if (this.getTipo().equals(TipoBarco.DESTRUCTOR.name()) && getImpactos() == 2) {

            setHundido(true);

        }

        if (this.getTipo().equals(TipoBarco.ACORAZADO.name()) && getImpactos() == 3) {

            setHundido(true);

        }

        if (this.getTipo().equals(TipoBarco.PORTAAVIONES.name()) && getImpactos() == 4) {

            setHundido(true);

        }

    }

    public boolean hundido() {

        if (isHundido()) {

            return true;

        }

        return false;

    }

    public int parteBarco(int x, int y) {
        int bandera = 99;

        for (int i = 0; i < getListaCoordenadas().size(); i++) {

            if (getListaCoordenadas().get(i).getCoorX() == x && getListaCoordenadas().get(i).getCoorY() == y) {

                bandera = i + 1;

            }

        }

        return bandera;

    }

    /**
     * @return the tipo
     */
    /**
     * @return the hundido
     */
    public boolean isHundido() {
        return hundido;
    }

    /**
     * @param hundido the hundido to set
     */
    public void setHundido(boolean hundido) {
        this.hundido = hundido;
    }

    /**
     * @return the impactos
     */
    public int getImpactos() {
        return impactos;
    }

    /**
     * @param impactos the impactos to set
     */
    public void setImpactos(int impactos) {
        this.impactos = impactos;
    }

    /**
     * @return the vertical
     */
    public boolean isVertical() {
        return vertical;
    }

    /**
     * @param vertical the vertical to set
     */
    public void setVertical(boolean vertical) {
        this.vertical = vertical;
    }

    /**
     * @return the tipo
     */
    public String getTipo() {
        return tipo;
    }

    /**
     * @param tipo the tipo to set
     */
    public void setTipo(String tipo) {
        this.tipo = tipo;
    }

    /**
     * @return the ListaCoordenadas
     */
    public ArrayList<Posicion> getListaCoordenadas() {
        return ListaCoordenadas;
    }

    /**
     * @param ListaCoordenadas the ListaCoordenadas to set
     */
    public void setListaCoordenadas(ArrayList<Posicion> ListaCoordenadas) {
        this.ListaCoordenadas = ListaCoordenadas;
    }

}
