package smma.juegosTablero.agentes;

import jade.content.Concept;
import jade.content.ContentElement;
import jade.content.ContentManager;
import jade.content.Predicate;
import jade.content.lang.Codec;
import jade.content.lang.sl.SLCodec;
import jade.content.onto.BeanOntologyException;
import jade.content.onto.OntologyException;
import jade.content.onto.basic.Action;
import jade.core.AID;
import jade.core.Agent;
import jade.core.behaviours.OneShotBehaviour;
import jade.core.behaviours.TickerBehaviour;
import jade.domain.*;
import jade.domain.FIPAAgentManagement.DFAgentDescription;
import jade.domain.FIPAAgentManagement.FailureException;
import jade.domain.FIPAAgentManagement.NotUnderstoodException;
import jade.domain.FIPAAgentManagement.RefuseException;
import jade.domain.FIPAAgentManagement.ServiceDescription;
import jade.domain.FIPAException;
import jade.domain.FIPANames;
import jade.lang.acl.ACLMessage;
import jade.lang.acl.MessageTemplate;
import jade.proto.AchieveREResponder;
import jade.proto.ProposeInitiator;
import jade.proto.SimpleAchieveREResponder;
import jade.proto.SubscriptionInitiator;
import jade.proto.SubscriptionResponder;
//import java.util.ArrayList;
import jade.util.leap.ArrayList;
import jade.util.leap.Iterator;
import jade.wrapper.StaleProxyException;
import java.util.HashMap;
import java.util.logging.Level;
import java.util.logging.Logger;
import juegosTablero.Vocabulario;

import juegosTablero.Vocabulario.NombreServicio;
import juegosTablero.aplicacion.OntologiaJuegoBarcos;
import juegosTablero.aplicacion.barcos.ColocarBarcos;
import juegosTablero.aplicacion.barcos.JuegoBarcos;
import juegosTablero.aplicacion.conecta4.JuegoConecta4;
import juegosTablero.aplicacion.domino.JuegoDomino;
import juegosTablero.dominio.OntologiaJuegosTablero;
import juegosTablero.dominio.elementos.ClasificacionJuego;
import juegosTablero.dominio.elementos.CompletarJuego;
import juegosTablero.dominio.elementos.Gestor;
import juegosTablero.dominio.elementos.IncidenciaJuego;
import juegosTablero.dominio.elementos.InformarJuego;
import juegosTablero.dominio.elementos.JuegoAceptado;
import juegosTablero.dominio.elementos.Motivacion;
import juegosTablero.dominio.elementos.ProponerJuego;
import utilidades.GestorSuscripciones;
import juegosTablero.dominio.elementos.Juego;
import juegosTablero.dominio.elementos.Jugador;
import juegosTablero.dominio.elementos.Tablero;
import utilidades.ArrayConversor;
import utilidades.ManejadorSuscripcion;

public class AgenteGrupoJuego extends AgenteOntologiaJuegos {

    private jade.content.onto.Ontology ontologiaBarcos;
    private jade.content.onto.Ontology ontologiaConecta4;
    private jade.content.onto.Ontology ontologiaDomino;
    private jade.content.onto.Ontology ontologiaDominio;
    private final jade.content.lang.Codec codec = new SLCodec();
    private final jade.content.ContentManager managerBarcos = (ContentManager) getContentManager();
    private final jade.content.ContentManager managerConecta4 = (ContentManager) getContentManager();
    private final jade.content.ContentManager managerDomino = (ContentManager) getContentManager();
    private final jade.content.ContentManager managerDominio = (ContentManager) getContentManager();

    private HashMap<String, java.util.List<Jugador>> listJugadores;
    private GestorSuscripciones gestor;
    private Vocabulario.TipoJuego tipJuego;
    private HashMap<String, Integer> controlMinimoVictorias;
    private HashMap<String, HashMap<String, Integer>> puntuaciones;
    private HashMap<String, HashMap<String, Integer>> victorias;
    private HashMap<String, Concept> tiposJuegos;
    private boolean numTorneosEnMarcha;
    private int numIndividualesEnMarcha;

    public AgenteGrupoJuego() {

    }

    protected void setup() {
        super.setup();

        //Inicialización de las variables del agente
        numTorneosEnMarcha = false;
        numIndividualesEnMarcha = 0;
        gestor = new GestorSuscripciones();
        MessageTemplate plantilla = MessageTemplate.MatchProtocol(FIPANames.InteractionProtocol.FIPA_SUBSCRIBE);
        ManejadorSuscripcion hacerSuscripcion = new ManejadorSuscripcion(this, plantilla, gestor);
        listJugadores = new HashMap<>();
        puntuaciones = new HashMap<>();
        victorias = new HashMap<>();
        controlMinimoVictorias = new HashMap<>();
        tiposJuegos = new HashMap<>();
        //Configuración del GUI
        //Registro del agente en las Páginas Amarrillas
        DFAgentDescription dfd = new DFAgentDescription();
        dfd.setName(getAID());
        ServiceDescription sd = new ServiceDescription();
        sd.setType(juegosTablero.Vocabulario.TIPO_SERVICIO);
        sd.setName(NombreServicio.GRUPO_JUEGOS.toString());
        dfd.addServices(sd);
        try {
            DFService.register(this, dfd);
        } catch (FIPAException fe) {
            fe.printStackTrace();
        }

        try {
            //Registro de la Ontología
            ontologiaDominio = OntologiaJuegosTablero.getInstance();
            ontologiaBarcos = juegosTablero.aplicacion.OntologiaJuegoBarcos.getInstance();
            ontologiaConecta4 = juegosTablero.aplicacion.OntologiaJuegoConecta4.getInstance();
            ontologiaDomino = juegosTablero.aplicacion.OntologiaJuegoDomino.getInstance();
        } catch (BeanOntologyException ex) {
            Logger.getLogger(AgenteGrupoJuego.class.getName()).log(Level.SEVERE, null, ex);
        }
        managerDominio.registerLanguage(codec);
        managerDominio.registerOntology(ontologiaDominio);
        managerBarcos.registerLanguage(codec);
        managerBarcos.registerOntology(ontologiaBarcos);
        managerConecta4.registerLanguage(codec);
        managerConecta4.registerOntology(ontologiaConecta4);
        managerDomino.registerLanguage(codec);
        managerDomino.registerOntology(ontologiaDomino);

        //Tareas
        MessageTemplate template = MessageTemplate.and(
                MessageTemplate.MatchProtocol(FIPANames.InteractionProtocol.FIPA_PROPOSE),
                MessageTemplate.MatchPerformative(ACLMessage.PROPOSE));

        MessageTemplate template1 = MessageTemplate.and(
                MessageTemplate.MatchProtocol(FIPANames.InteractionProtocol.FIPA_REQUEST),
                MessageTemplate.MatchPerformative(ACLMessage.REQUEST));

        addBehaviour(new GrupoResponder(this, template));
        addBehaviour(hacerSuscripcion);
        addBehaviour(new GrupoClasificacion(this, template1));
        //addBehaviour(new TareaPruebaPublicacion(this, 1000));
    }

    protected void takeDown() {
        // <editor-fold defaultstate="collapsed" desc="Compiled Code">
        /* 0: aload_0
         * 1: invokestatic  jade/domain/DFService.deregister:(Ljade/core/Agent;)V
         * 4: goto          12
         * 7: astore_1
         * 8: aload_1
         * 9: invokevirtual jade/domain/FIPAException.printStackTrace:()V
         * 12: getstatic     java/lang/System.out:Ljava/io/PrintStream;
         * 15: new           java/lang/StringBuilder
         * 18: dup
         * 19: invokespecial java/lang/StringBuilder."<init>":()V
         * 22: ldc           Finaliza la ejecución de
         * 24: invokevirtual java/lang/StringBuilder.append:(Ljava/lang/String;)Ljava/lang/StringBuilder;
         * 27: aload_0
         * 28: invokevirtual juegosTablero/AgentePrueba.getName:()Ljava/lang/String;
         * 31: invokevirtual java/lang/StringBuilder.append:(Ljava/lang/String;)Ljava/lang/StringBuilder;
         * 34: invokevirtual java/lang/StringBuilder.toString:()Ljava/lang/String;
         * 37: invokevirtual java/io/PrintStream.println:(Ljava/lang/String;)V
         * 40: return
         * Exception table:
         * from    to  target type
         * 0     4     7   Class jade/domain/FIPAException
         *  */
        // </editor-fold>
    }

    private boolean checkAction() {
        // Simulate a check by generating a random number
        return (Math.random() > 0.2);
    }

    private class GrupoClasificacion extends SimpleAchieveREResponder {

        public GrupoClasificacion(Agent a, MessageTemplate mt) {
            super(a, mt);
        }

        protected ACLMessage prepareResponse(ACLMessage request) throws NotUnderstoodException, RefuseException {
            ACLMessage respuesta = request.createReply();

            respuesta.setLanguage(codec.getName());

            CompletarJuego completarJuego = null;
            ClasificacionJuego clasific = null;
            IncidenciaJuego incidencia = null;
            try {
                ContentElement content = extraerMensaje(request);
                if (content instanceof Predicate) {
                    if (((Predicate) content) instanceof ClasificacionJuego) {

                        clasific = (ClasificacionJuego) content;
                        java.util.List<Jugador> players = ArrayConversor.fromJade2Java(clasific.getListaJugadores());
                        java.util.List<Long> scores = ArrayConversor.fromJade2Java(clasific.getListaPuntuacion());
                       
                        //Actualizamos las puntuaciones cada vez que llega una clasificacion
                        HashMap<String, Integer> puntuActualizar = puntuaciones.get(clasific.getJuego().getIdJuego());
                        HashMap<String, Integer> victorActualizar = victorias.get(clasific.getJuego().getIdJuego());
                        for (int i = 0; i < players.size(); i++) {
                            if (scores.get(i).intValue() == 3) {
                                if (!victorActualizar.containsKey(players.get(i).getNombre())) {
                                    victorActualizar.put(players.get(i).getNombre(), 0);
                                }
                                victorActualizar.put(players.get(i).getNombre(), victorActualizar.get(players.get(i).getNombre()) + 1);
                            }
                            Integer entero = new Integer(puntuActualizar.get(players.get(i).getNombre()).intValue() + scores.get(i).intValue());
                            puntuActualizar.put(players.get(i).getNombre(), entero);
                        }
                        if (!controlMinimoVictorias.containsKey(clasific.getJuego().getIdJuego())) {
                            controlMinimoVictorias.put(clasific.getJuego().getIdJuego(), 0);
                        }
                        controlMinimoVictorias.put(clasific.getJuego().getIdJuego(), controlMinimoVictorias.get(clasific.getJuego().getIdJuego()) + 1);
                        
                        if (victoriasAlcanzadas(clasific.getJuego().getIdJuego(), clasific.getJuego().getMinVictorias())) {
                            //Se ha terminado el mejor de n
                            //Mandar clasificatorias al agente central
                            ACLMessage msg = new ACLMessage(ACLMessage.INFORM);
                            msg.setLanguage(codec.getName());
                            msg.setOntology(getSelectedOntologia(clasific.getJuego().getTipoJuego()).getName());
                            msg.setContent("Soy el agente: " + myAgent.getName() + " publicando un mensaje.");
                            HashMap<String, Integer> puntuacion = puntuaciones.get(clasific.getJuego().getIdJuego());
                            java.util.List<Concept> jug = new java.util.ArrayList<Concept>();
                            jade.util.leap.List pun = new jade.util.leap.ArrayList();
                            java.util.List<Jugador> jugadoresPartida = ArrayConversor.fromJade2Java(clasific.getListaJugadores());
                            for (int i = 0; i < jugadoresPartida.size(); i++) {
                                int puntuacionJ = puntuacion.get(jugadoresPartida.get(i).getNombre());
                                pun.add(puntuacionJ);
                                jug.add(jugadoresPartida.get(i));
                            }

                            ClasificacionJuego clas = new ClasificacionJuego(clasific.getJuego(), ArrayConversor.fromJava2Jade(jug), pun);
                            try {
                                findManager(getSelectedOntologia(clas.getJuego().getTipoJuego()).getName()).fillContent(msg, clas);
                            } catch (Codec.CodecException ex) {
                                Logger.getLogger(AgenteGrupoJuego.class.getName()).log(Level.SEVERE, null, ex);
                            } catch (OntologyException ex) {
                                Logger.getLogger(AgenteGrupoJuego.class.getName()).log(Level.SEVERE, null, ex);
                            }
                            for (SubscriptionResponder.Subscription subscripcion : gestor.values()) {
                                subscripcion.notify(msg);
                            }
                        } else {
                            //No se ha terminado el mejor de n
                            try {
                                getContainerController().createNewAgent("Tablero" + clasific.getJuego().getIdJuego() + "-" + controlMinimoVictorias.get(clasific.getJuego().getIdJuego()), "smma.juegosTablero.agentes.AgenteTablero", null).start();
                            } catch (StaleProxyException ex) {
                                Logger.getLogger(AgenteGrupoJuego.class.getName()).log(Level.SEVERE, null, ex);
                            }
                            JuegoDomino jD = null;
                            JuegoConecta4 jC4 = null;
                            JuegoBarcos jB = null;
                            AID aidTablero = new AID("Tablero" + clasific.getJuego().getIdJuego() + "-" + controlMinimoVictorias.get(clasific.getJuego().getIdJuego()), AID.ISLOCALNAME);
                            if (clasific.getJuego().getTipoJuego() == Vocabulario.TipoJuego.BARCOS) {
                                jB = (JuegoBarcos) tiposJuegos.get(clasific.getJuego().getIdJuego());
                                addBehaviour(new enviarJuegoTablero(this.myAgent, clasific.getJuego(), jB, aidTablero));
                            } else if (clasific.getJuego().getTipoJuego() == Vocabulario.TipoJuego.CONECTA_4) {
                                jC4 = (JuegoConecta4) tiposJuegos.get(clasific.getJuego().getIdJuego());
                                addBehaviour(new enviarJuegoTablero(this.myAgent, clasific.getJuego(), jC4, aidTablero));
                            } else {
                                jD = (JuegoDomino) tiposJuegos.get(clasific.getJuego().getIdJuego());
                                addBehaviour(new enviarJuegoTablero(this.myAgent, clasific.getJuego(), jD, aidTablero));
                            }
                            //Incluir contenido del mensaje

                        }

                    } else if (((Predicate) content) instanceof IncidenciaJuego) {
                        incidencia = (IncidenciaJuego) content;
                        ACLMessage msg = new ACLMessage(ACLMessage.INFORM);
                        msg.setLanguage(codec.getName());
                        msg.setOntology(getSelectedOntologia(incidencia.getJuego().getTipoJuego()).getName());
                        msg.setContent("Soy el agente: " + myAgent.getName() + " publicando un mensaje.");
                        try {
                            switch (incidencia.getJuego().getTipoJuego()) {
                                case BARCOS:
                                    managerBarcos.fillContent(msg, incidencia);
                                    break;
                                case CONECTA_4:
                                    managerBarcos.fillContent(msg, incidencia);
                                    break;
                                case DOMINO:
                                    managerBarcos.fillContent(msg, incidencia);
                                    break;
                            }
                        } catch (Codec.CodecException ex) {
                            Logger.getLogger(AgenteGrupoJuego.class.getName()).log(Level.SEVERE, null, ex);
                        } catch (OntologyException ex) {
                            Logger.getLogger(AgenteGrupoJuego.class.getName()).log(Level.SEVERE, null, ex);
                        }
                        for (SubscriptionResponder.Subscription subscripcion : gestor.values()) {
                            subscripcion.notify(msg);
                        }

                    } else {
                        System.out.println("No entiendo en el mensaje 1");
                        throw new NotUnderstoodException(request.getOntology());
                    }
                } else {
                    System.out.println("No entiendo en el mensaje 2");
                    throw new NotUnderstoodException(request.getOntology());
                }
            } catch (Exception ex) {
                Logger.getLogger(AgenteGrupoJuego.class.getName()).log(Level.SEVERE, null, ex);
            }

            if (checkAction()) {
                // We agree to perform the action. Note that in the FIPA-Request
                // protocol the AGREE message is optional. Return null if you
                // don't want to send it.
                System.out.println("Agent " + getLocalName() + ": Agree");
                ACLMessage agree = request.createReply();
                agree.setPerformative(ACLMessage.AGREE);
                return agree;
            } else {
                // We refuse to perform the action

                System.out.println("Agent " + getLocalName() + ": Refuse");
                throw new RefuseException("check-failed");
            }
        }

        protected ACLMessage prepareResultNotification(ACLMessage request, ACLMessage response) throws FailureException {
            if (checkAction()) {
                System.out.println("Agent " + getLocalName() + ": Action successfully performed");
                ACLMessage inform = request.createReply();
                inform.setPerformative(ACLMessage.INFORM);
                return inform;
            } else {
                System.out.println("Agent " + getLocalName() + ": Action failed");
                throw new FailureException("unexpected-error");
            }
        }

    }

    private class GrupoResponder extends SimpleAchieveREResponder {

        public GrupoResponder(Agent a, MessageTemplate mt) {
            super(a, mt);
        }

        @Override
        protected ACLMessage prepareResponse(ACLMessage propose) throws NotUnderstoodException, RefuseException {
            //System.out.println("Agent " + getLocalName() + ": Propose received from " + propose.getSender().getName() + ". Action is " + propose.getContent());

            ACLMessage respuesta = propose.createReply();

            respuesta.setLanguage(codec.getName());

            CompletarJuego completarJuego = null;

            try {
                //Extraemos el contenido del mensaje propose recibido
                ContentElement content = extraerMensaje(propose);
                if (content instanceof Action) {
                    if (((Action) content).getAction() instanceof CompletarJuego) {
                        completarJuego = (CompletarJuego) ((Action) content).getAction();
                        if (completarJuego.getJuego().getModoJuego().equals(Vocabulario.ModoJuego.UNICO)) {
                            System.out.println("El grupo acepta la partida");
                            respuesta.setOntology(getSelectedOntologia(completarJuego.getJuego().getTipoJuego()).getName());
                            java.util.List<Jugador> list = ArrayConversor.fromJade2Java(completarJuego.getListaJugadores());
                            listJugadores.put(completarJuego.getJuego().getIdJuego(), list);
                            controlMinimoVictorias.put(completarJuego.getJuego().getIdJuego(), 0);
                            HashMap<String, Integer> punt = new HashMap<String, Integer>();

                            for (int i = 0; i < listJugadores.get(completarJuego.getJuego().getIdJuego()).size(); i++) {
                                punt.put(listJugadores.get(completarJuego.getJuego().getIdJuego()).get(i).getNombre(), 0);
                            }

                            puntuaciones.put(completarJuego.getJuego().getIdJuego(), punt);
                            victorias.put(completarJuego.getJuego().getIdJuego(), new HashMap<>());
                            tiposJuegos.put(completarJuego.getJuego().getIdJuego(), completarJuego.getTipoJuego());

                            //Acepta jugar

                            //System.out.println("Agent " + getLocalName() + ": Accept");
                            respuesta.setPerformative(ACLMessage.ACCEPT_PROPOSAL);
                            JuegoAceptado aceptado = new JuegoAceptado(completarJuego.getJuego(), new juegosTablero.dominio.elementos.Grupo(myAgent.getName(), myAgent.getAID()));
                            try {
                                getContainerController().createNewAgent("Tablero" + completarJuego.getJuego().getIdJuego() + "-0", "smma.juegosTablero.agentes.AgenteTablero", null).start();
                            } catch (StaleProxyException ex) {
                                Logger.getLogger(AgenteGrupoJuego.class.getName()).log(Level.SEVERE, null, ex);
                            }

                            AID aidTablero = new AID("Tablero" + completarJuego.getJuego().getIdJuego() + "-0", AID.ISLOCALNAME);

                            addBehaviour(new enviarJuegoTablero(this.myAgent, completarJuego.getJuego(), completarJuego.getTipoJuego(), aidTablero));
                            //Incluir contenido del mensaje
                            try {
                                managerDominio.fillContent(respuesta, aceptado);
                            } catch (Codec.CodecException ex) {
                                Logger.getLogger(AgenteGrupoJuego.class.getName()).log(Level.SEVERE, null, ex);
                            } catch (OntologyException ex) {
                                Logger.getLogger(AgenteGrupoJuego.class.getName()).log(Level.SEVERE, null, ex);
                            }

                            return respuesta;
                        } else {
                            //Rechazar juego 
                            //System.out.println("Agent " + getLocalName() + ": reject");
                            System.out.println("El grupo rechaza el torneo");
                            respuesta.setPerformative(ACLMessage.REJECT_PROPOSAL);

                            Motivacion motivacion = new Motivacion(completarJuego.getJuego(), juegosTablero.Vocabulario.Motivo.JUEGOS_ACTIVOS_SUPERADOS);
                            try {
                                managerDominio.fillContent(respuesta, motivacion);
                            } catch (Codec.CodecException ex) {
                                Logger.getLogger(AgenteGrupoJuego.class.getName()).log(Level.SEVERE, null, ex);
                            } catch (OntologyException ex) {
                                Logger.getLogger(AgenteGrupoJuego.class.getName()).log(Level.SEVERE, null, ex);
                            }

                            return respuesta;
                        }
                    } else {
                        System.out.println("No entiendo en el mensaje 1");
                        throw new NotUnderstoodException(propose.getOntology());
                    }
                } else {
                    System.out.println("No entiendo en el mensaje 2");
                    throw new NotUnderstoodException(propose.getOntology());
                }
            } catch (Exception ex) {
                Logger.getLogger(AgenteGrupoJuego.class.getName()).log(Level.SEVERE, null, ex);
            }

            return respuesta;

        }

    }

    /**
     * Tarea que se encarga de generar una nueva cosecha
     */
    public class TareaPruebaPublicacion extends OneShotBehaviour {

        @Override
        public void action() {

            Juego juego = new Juego("0", 1, Vocabulario.ModoJuego.UNICO, Vocabulario.TipoJuego.BARCOS);
            IncidenciaJuego incidencia = new IncidenciaJuego(juego, juegosTablero.Vocabulario.Incidencia.ERROR_MENSAJE_INCORRECTO);

        }

    }

    public class Propose extends ProposeInitiator {

        public Propose(Agent a, ACLMessage msg) {
            super(a, msg);
        }

        @Override
        protected void handleAcceptProposal(ACLMessage inform) {
            //System.out.println("Agent " + inform.getSender().getName() + " successfully performed the requested action");
        }

        @Override
        protected void handleRejectProposal(ACLMessage refuse) {
            //System.out.println("Agent " + refuse.getSender().getName() + " refused to perform the requested action");

        }

    }

    public class enviarJuegoTablero extends OneShotBehaviour {

        private Juego juego;
        private Concept tipJuego;
        private AID tablero;

        public enviarJuegoTablero(Agent a, Juego juego, Concept tipJuego, AID tablero) {
            super(a);

            this.juego = juego;
            this.tipJuego = tipJuego;
            this.tablero = tablero;
        }

        @Override
        public void action() {
            java.util.List<Concept> fichConcept = new java.util.ArrayList<>();
            for (int i = 0; i < listJugadores.get(juego.getIdJuego()).size(); i++) {
                fichConcept.add(listJugadores.get(juego.getIdJuego()).get(i));
            }
            CompletarJuego partida = new CompletarJuego(juego, tipJuego, ArrayConversor.fromJava2Jade(fichConcept));
            Action ac = new Action(this.myAgent.getAID(), partida);
            try {
                //Crear tablero = new agenteTablero()
                java.util.ArrayList<AID> receptores = new java.util.ArrayList<>();
                receptores.add(tablero);
                ACLMessage propose = mensajeProposal(receptores, ac, getSelectedOntologia(juego.getTipoJuego())); //listJugadores hay que cambiarlo por el tablero creado
                addBehaviour(new Propose(this.myAgent, propose));
            } catch (Exception ex) {
                Logger.getLogger(AgenteGrupoJuego.class.getName()).log(Level.SEVERE, null, ex);
            }

        }

    }

    static jade.util.leap.ArrayList fromJava2Jade(java.util.ArrayList<AID> list) {
        jade.util.leap.ArrayList ret = new jade.util.leap.ArrayList();
        for (AID c : list) {
            ret.add(c);
        }
        return ret;
    }

    static <T extends Concept> java.util.ArrayList<T> fromJade2Java(jade.util.leap.ArrayList list) {
        java.util.ArrayList<T> ret = new java.util.ArrayList<T>();
        for (Iterator it = list.iterator(); it.hasNext();) {
            T o2 = (T) it.next();
            ret.add(o2);
        }
        return ret;
    }

    private boolean victoriasAlcanzadas(String idJuego, int numVictorias) {
        HashMap<String, Integer> victoriasTotales = victorias.get(idJuego);
        for (Integer victorias : victoriasTotales.values()) {
            if (victorias == numVictorias) {
                return true;
            }
        }

        return false;
    }
}
