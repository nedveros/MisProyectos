package utilidades;

import jade.core.Agent;
import jade.domain.FIPAAgentManagement.FailureException;
import jade.domain.FIPAAgentManagement.NotUnderstoodException;
import jade.domain.FIPAAgentManagement.RefuseException;
import jade.lang.acl.ACLMessage;
import jade.lang.acl.MessageTemplate;
import jade.proto.SubscriptionResponder;

/**
 *
 * @author  javiermq
 */
public class ManejadorSuscripcion extends SubscriptionResponder {
    
    GestorSuscripciones manager;

    public ManejadorSuscripcion(Agent a, MessageTemplate mt, GestorSuscripciones sm) {
        super(a, mt);
        this.manager=sm;
    }
    
    @Override
    protected ACLMessage handleSubscription(ACLMessage subscription) throws NotUnderstoodException, RefuseException {   
        ACLMessage response = subscription.createReply();
        if(!manager.containsKey(subscription.getSender())){
            SubscriptionResponder.Subscription sub=this.createSubscription(subscription);
            manager.register(sub);
            response.setPerformative(ACLMessage.AGREE);

        }else{
            response.setPerformative(ACLMessage.REFUSE);
        }
        return response;
    }

    @Override
    protected ACLMessage handleCancel(ACLMessage subscriptor) throws FailureException {
        ACLMessage response = subscriptor.createReply();
        try{
            SubscriptionResponder.Subscription sub=manager.getSuscripcion(subscriptor.getSender());
            manager.deregister(sub);
            response.setPerformative(ACLMessage.INFORM);
        }catch(Exception ex){
                response.setPerformative(ACLMessage.REFUSE);
        }
        return response;
    }
}
