/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package smma.juegosTablero.tableros;

import java.awt.GridLayout;
import javafx.scene.paint.Color;
import javax.swing.BorderFactory;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.ScrollPaneConstants;
import javax.swing.border.AbstractBorder;
import javax.swing.border.BevelBorder;
import javax.swing.border.LineBorder;

/**
 *
 * @author davidbaudetmoreno
 */
public class tableroConecta4 extends javax.swing.JFrame {

    /**
     * Creates new form tableroConecta4
     */
    
    private JPanel panel;
    int[][] Matriz;
    JButton bMatriz[][];
    int turno = 1;
    int i;
    String jugador1;
    String jugador2;
    JTextArea area ;
    final static String newline = "\n";
   
   
    
    
    
    public tableroConecta4(String tipoPartida,String Jugador1 ,String Jugador2,int x , int y) {
        initComponents();
        
        this.setSize(900, 500);
         bMatriz= new JButton[x][y];
        i=x;

        panel = new JPanel();
        jLabel1.setText(tipoPartida);
        jLabel4.setText(Jugador1);
        jLabel5.setText(Jugador2);    
        this.jugador1 = Jugador1;
        this.jugador2 = Jugador2;
        jLabel2.setForeground(java.awt.Color.BLUE);
        jLabel3.setForeground(java.awt.Color.RED);
        area = jTextArea2;
       
        
    
        panel.setBorder(BorderFactory.createLineBorder(java.awt.Color.BLACK));
        panel.setLayout(new GridLayout(x, y));
        Matriz = new int[x][y];
        inicializarMatriz(x, y);

        for (int f = 0; f < x; f++) {
            for (int c = 0; c < y; c++) {
                bMatriz[f][c] = new JButton();
                bMatriz[f][c].setBounds(20, 10, 360, 360);
                bMatriz[f][c].setContentAreaFilled(false);
                

               // this.setBounds(140, 15, 270, 300);
                panel.setBounds(140, 15, 370, 400);
                panel.add(bMatriz[f][c]);
                panel.setVisible(true);
            }
        }
        panel.setLocation(500, 50);
        this.add(panel);
        
        // jTextArea2.setEditable ( false ); // set textArea non-editable
   // JScrollPane scroll = new JScrollPane ( jTextArea2 );
   // scroll.setVerticalScrollBarPolicy ( ScrollPaneConstants.VERTICAL_SCROLLBAR_ALWAYS );
        
        
    }
    
     public void ColocarFicha(int columna){
        
            int posicion =0;
            for(int d = 0 ; d < i ; d++){
            
            
                if(Matriz[d][columna] == 0){
                posicion = d;
                }
            
            
            }
            
            
            if(turno == 1){
                
               // System.out.println(this.jugador1+" coloca una ficha en la columna "+columna +"fila "+posicion);
                area.append(this.jugador1+ " coloca una ficha en la columna "+columna +" fila "+posicion+newline);
                   area.setCaretPosition(area.getDocument().getLength());
                ImageIcon icono = new ImageIcon("fichaAzul.jpg");
                bMatriz[posicion][columna].setIcon(icono);
                
            
            
                turno = 2;
            }else{
                // System.out.println(this.jugador2+" coloca una ficha en la columna "+columna +"fila "+posicion);
                   area.append(this.jugador2+" coloca una ficha en la columna "+columna +" fila "+posicion+newline);
                      area.setCaretPosition(area.getDocument().getLength());
                   
                 ImageIcon icono = new ImageIcon("fichaRoja.jpg");
                   bMatriz[posicion][columna].setIcon(icono);
                 turno = 1;
            }
        
            
            if(turno == 1 ){
            Matriz[posicion][columna]=1;
            }else{
            
                Matriz[posicion][columna]=2;
            
            }
            RedibujarTablero();
        
        }
        
     private void inicializarMatriz(int i , int j){
        
        
        for(int k =0;k < i ;k++){
        
            for(int h =0;h < j ;h++){
            
               Matriz[k][h]=0;
            
            }
        
        
        }
        

        
        }
    
      private void RedibujarTablero()
    {
        //Se valida los componentes del elemento pnlTablero
        panel.validate();
        //Se redibuja el elemento pnlTablero y sus componentes hijos
       panel.repaint();
    }

    private tableroConecta4() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jScrollPane2 = new javax.swing.JScrollPane();
        jTextArea2 = new javax.swing.JTextArea();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jLabel1.setText("tipoPartida");

        jLabel2.setBackground(new java.awt.Color(51, 153, 255));
        jLabel2.setText("Jugador1");

        jLabel3.setText("Jugador2");

        jLabel4.setText("jLabel4");

        jLabel5.setText("jLabel5");

        jTextArea2.setColumns(20);
        jTextArea2.setRows(5);
        jScrollPane2.setViewportView(jTextArea2);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(18, 18, 18)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel1)
                            .addGroup(layout.createSequentialGroup()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addComponent(jLabel2)
                                    .addComponent(jLabel3))
                                .addGap(18, 18, 18)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel5)
                                    .addComponent(jLabel4)))))
                    .addGroup(layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 486, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(408, 408, 408))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addGap(20, 20, 20)
                .addComponent(jLabel1)
                .addGap(28, 28, 28)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel2)
                    .addComponent(jLabel4))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel5)
                    .addComponent(jLabel3))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 193, Short.MAX_VALUE)
                .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 197, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(26, 26, 26))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(tableroConecta4.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(tableroConecta4.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(tableroConecta4.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(tableroConecta4.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new tableroConecta4().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JTextArea jTextArea2;
    // End of variables declaration//GEN-END:variables
}
