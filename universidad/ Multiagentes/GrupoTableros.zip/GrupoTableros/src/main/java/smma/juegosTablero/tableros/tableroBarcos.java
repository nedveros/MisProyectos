/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package smma.juegosTablero.tableros;

import java.awt.Color;
import java.awt.GridLayout;
import javax.swing.BorderFactory;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JPanel;
import javax.swing.JTextArea;
import juegosTablero.Vocabulario;
import juegosTablero.Vocabulario.TipoBarco;
import juegosTablero.dominio.elementos.Posicion;

/**
 *
 * @author davidbaudetmoreno
 */
public class tableroBarcos extends javax.swing.JFrame {

    /**
     * Creates new form tableroBarcos
     */
    int i = 1;
    String Jugador1;
    String Jugador2;
    JButton bMatriz[][];
    JButton bMatriz2[][];
    Barco Matriz1[][];
    Barco Matriz2[][];
    int tamaX;
    int tamaY;
    JTextArea area;
    final static String newline = "\n";

    public tableroBarcos(String tipoPartida, String Jugador1, String Jugador2, int x, int y) {
        initComponents();
        area = jTextArea1;
        this.setSize(1200, 600);
        jLabel1.setText(tipoPartida);
        jLabel3.setText(Jugador1);
        jLabel6.setText(Jugador1);
        jLabel7.setText(Jugador2);
        jLabel5.setText(Jugador2);
        tamaX = x;
        tamaY = y;
        this.Jugador1 = Jugador1;
        this.Jugador2 = Jugador2;
        bMatriz = new JButton[x][y];
        Matriz1 = new Barco[y][y];
        Matriz2 = new Barco[y][y];
//           inicializarMatriz(Matriz1);
//           inicializarMatriz(Matriz2);
        JPanel uno = new JPanel();
        uno.setBorder(BorderFactory.createLineBorder(Color.black));
        uno.setLayout(new GridLayout(x, y));
        for (int f = 0; f < x; f++) {
            for (int c = 0; c < y; c++) {
                bMatriz[f][c] = new JButton();
                bMatriz[f][c].setBounds(20, 10, 360, 360);
                bMatriz[f][c].setContentAreaFilled(false);
                bMatriz[f][c].setBackground(Color.CYAN);

                // this.setBounds(140, 15, 270, 300);
                uno.setBounds(420, 90, 370, 400);
                uno.add(bMatriz[f][c]);
                uno.setVisible(true);
            }
        }

        this.add(uno);
        uno.setLocation(420, 90);

        bMatriz2 = new JButton[x][y];
        JPanel dos = new JPanel();
        dos.setBorder(BorderFactory.createLineBorder(Color.black));
        dos.setLayout(new GridLayout(x, y));
        for (int f = 0; f < x; f++) {
            for (int c = 0; c < y; c++) {
                bMatriz2[f][c] = new JButton();
                bMatriz2[f][c].setBounds(20, 10, 360, 360);
                bMatriz2[f][c].setContentAreaFilled(false);
                bMatriz2[f][c].setBackground(Color.CYAN);

                dos.setBounds(800, 90, 370, 400);
                dos.add(bMatriz2[f][c]);
                dos.setVisible(true);
            }
        }

        this.add(dos);
        dos.setLocation(800, 90);

    }

    //int casillas , posicion (x,y) ,orientacion = HORIZONTAL o VERTICAL
    public void ColocarBarco(String Jugador, TipoBarco tipobarco, Vocabulario.Orientacion orientacion, Posicion posicion) {

        if (Jugador.equals(this.Jugador1)) {

            if (tipobarco == Vocabulario.TipoBarco.FRAGATA) {

                Barco nuevo = new Barco(tipobarco, posicion, orientacion);
                //bMatriz[coordenadaInicioX][coordenadaInicioY].setText(1 + "");
                ImageIcon icono = new ImageIcon("barcos1.png");
                bMatriz[posicion.getCoorX()][posicion.getCoorY()].setIcon(icono);
                Matriz1[posicion.getCoorX()][posicion.getCoorY()] = nuevo;

            }

            if (tipobarco == Vocabulario.TipoBarco.DESTRUCTOR) {
                Barco nuevo = new Barco(tipobarco, posicion, orientacion);

                if (orientacion.equals(Vocabulario.Orientacion.HORIZONTAL)) {
                    ImageIcon icono = new ImageIcon("barcos2_1.jpg");
                    bMatriz[posicion.getCoorX()][posicion.getCoorY()].setIcon(icono);
                    ImageIcon icono2 = new ImageIcon("barcos2_2.jpg");
                    bMatriz[posicion.getCoorX()][posicion.getCoorY() + 1].setIcon(icono2);

                    Matriz1[posicion.getCoorX()][posicion.getCoorY()] = nuevo;
                    Matriz1[posicion.getCoorX()][posicion.getCoorY() + 1] = nuevo;

                } else {
                    ImageIcon icono = new ImageIcon("barcos2_1_vertical.jpg");
                    bMatriz[posicion.getCoorX()][posicion.getCoorY()].setIcon(icono);
                    ImageIcon icono2 = new ImageIcon("barcos2_2_vertical.jpg");
                    bMatriz[posicion.getCoorX() + 1][posicion.getCoorY()].setIcon(icono2);

                    Matriz1[posicion.getCoorX()][posicion.getCoorY()] = nuevo;
                    Matriz1[posicion.getCoorX() + 1][posicion.getCoorY()] = nuevo;

                }

            }
            if (tipobarco == Vocabulario.TipoBarco.ACORAZADO) {
                Barco nuevo = new Barco(tipobarco, posicion, orientacion);
                if (orientacion.equals(Vocabulario.Orientacion.HORIZONTAL)) {

                    // bMatriz2[coordenadaInicioX][coordenadaInicioY].setText(3 + "");
                    ImageIcon icono = new ImageIcon("barcos3_1.jpg");
                    bMatriz[posicion.getCoorX()][posicion.getCoorY()].setIcon(icono);
                    icono = new ImageIcon("barcos3_2.jpg");
                    bMatriz[posicion.getCoorX()][posicion.getCoorY() + 1].setIcon(icono);
                    //     bMatriz2[coordenadaFinalX][coordeanadaFinalY].setText(3 + "");
                    icono = new ImageIcon("barcos3_3.jpg");
                    bMatriz[posicion.getCoorX()][posicion.getCoorY() + 2].setIcon(icono);
                    Matriz1[posicion.getCoorX()][posicion.getCoorY()] = nuevo;
                    Matriz1[posicion.getCoorX()][posicion.getCoorY() + 1] = nuevo;
                    Matriz1[posicion.getCoorX()][posicion.getCoorY() + 2] = nuevo;

                } else {

                    ImageIcon icono = new ImageIcon("barcos3_1_vertical.jpg");
                    bMatriz[posicion.getCoorX()][posicion.getCoorY()].setIcon(icono);
                    icono = new ImageIcon("barcos3_2_vertical.jpg");
                    bMatriz[posicion.getCoorX() + 1][posicion.getCoorY()].setIcon(icono);
                    //     bMatriz2[coordenadaFinalX][coordeanadaFinalY].setText(3 + "");
                    icono = new ImageIcon("barcos3_3_vertical.jpg");
                    bMatriz[posicion.getCoorX() + 2][posicion.getCoorY()].setIcon(icono);
                    Matriz1[posicion.getCoorX()][posicion.getCoorY()] = nuevo;
                    Matriz1[posicion.getCoorX() + 1][posicion.getCoorY()] = nuevo;
                    Matriz1[posicion.getCoorX() + 2][posicion.getCoorY()] = nuevo;

                }

            }
            if (tipobarco == Vocabulario.TipoBarco.PORTAAVIONES) {
                Barco nuevo = new Barco(tipobarco, posicion, orientacion);
                if (orientacion.equals(Vocabulario.Orientacion.HORIZONTAL)) {

                    ImageIcon icono = new ImageIcon("barcos4_1.jpg");
                    bMatriz[posicion.getCoorX()][posicion.getCoorY()].setIcon(icono);
                    icono = new ImageIcon("barcos4_2.jpg");
                    bMatriz[posicion.getCoorX()][posicion.getCoorY() + 1].setIcon(icono);
                    icono = new ImageIcon("barcos4_3.jpg");
                    bMatriz[posicion.getCoorX()][posicion.getCoorY() + 2].setIcon(icono);
                    //     bMatriz2[coordenadaFinalX][coordeanadaFinalY].setText(3 + "");
                    icono = new ImageIcon("barcos4_4.jpg");
                    bMatriz[posicion.getCoorX()][posicion.getCoorY() + 3].setIcon(icono);
                    Matriz1[posicion.getCoorX()][posicion.getCoorY()] = nuevo;
                    Matriz1[posicion.getCoorX()][posicion.getCoorY() + 1] = nuevo;
                    Matriz1[posicion.getCoorX()][posicion.getCoorY() + 2] = nuevo;
                    Matriz1[posicion.getCoorX()][posicion.getCoorY() + 3] = nuevo;

                } else {

                    ImageIcon icono = new ImageIcon("barcos4_1_vertical.jpg");
                    bMatriz[posicion.getCoorX()][posicion.getCoorY()].setIcon(icono);
                    icono = new ImageIcon("barcos4_2_vertical.jpg");
                    bMatriz[posicion.getCoorX() + 1][posicion.getCoorY()].setIcon(icono);
                    icono = new ImageIcon("barcos4_3_vertical.jpg");
                    bMatriz[posicion.getCoorX() + 2][posicion.getCoorY()].setIcon(icono);
                    //     bMatriz2[coordenadaFinalX][coordeanadaFinalY].setText(3 + "");
                    icono = new ImageIcon("barcos4_4_vertical.jpg");
                    bMatriz[posicion.getCoorX() + 3][posicion.getCoorY()].setIcon(icono);

                    Matriz1[posicion.getCoorX()][posicion.getCoorY()] = nuevo;
                    Matriz1[posicion.getCoorX() + 1][posicion.getCoorY()] = nuevo;
                    Matriz1[posicion.getCoorX() + 2][posicion.getCoorY()] = nuevo;
                    Matriz1[posicion.getCoorX() + 3][posicion.getCoorY()] = nuevo;

                }

            }

        } else {

            if (tipobarco == Vocabulario.TipoBarco.FRAGATA) {

                Barco nuevo = new Barco(tipobarco, posicion, orientacion);
                //bMatriz[coordenadaInicioX][coordenadaInicioY].setText(1 + "");
                ImageIcon icono = new ImageIcon("barcos1.png");
                bMatriz2[posicion.getCoorX()][posicion.getCoorY()].setIcon(icono);
                Matriz2[posicion.getCoorX()][posicion.getCoorY()] = nuevo;

            }

            if (tipobarco == Vocabulario.TipoBarco.DESTRUCTOR) {

                Barco nuevo = new Barco(tipobarco, posicion, orientacion);

                if (orientacion.equals(Vocabulario.Orientacion.HORIZONTAL)) {

                    ImageIcon icono = new ImageIcon("barcos2_1.jpg");
                    bMatriz2[posicion.getCoorX()][posicion.getCoorY()].setIcon(icono);
                    ImageIcon icono2 = new ImageIcon("barcos2_2.jpg");
                    bMatriz2[posicion.getCoorX()][posicion.getCoorY() + 1].setIcon(icono2);

                    Matriz2[posicion.getCoorX()][posicion.getCoorY()] = nuevo;
                    Matriz2[posicion.getCoorX()][posicion.getCoorY() + 1] = nuevo;

                } else {

                    ImageIcon icono = new ImageIcon("barcos2_1_vertical.jpg");
                    bMatriz2[posicion.getCoorX()][posicion.getCoorY()].setIcon(icono);
                    ImageIcon icono2 = new ImageIcon("barcos2_2_vertical.jpg");
                    bMatriz2[posicion.getCoorX() + 1][posicion.getCoorY()].setIcon(icono2);

                    Matriz2[posicion.getCoorX()][posicion.getCoorY()] = nuevo;
                    Matriz2[posicion.getCoorX() + 1][posicion.getCoorY()] = nuevo;

                }

            }
            if (tipobarco == Vocabulario.TipoBarco.ACORAZADO) {
                Barco nuevo = new Barco(tipobarco, posicion, orientacion);
                if (orientacion.equals(Vocabulario.Orientacion.HORIZONTAL)) {

                    // bMatriz2[coordenadaInicioX][coordenadaInicioY].setText(3 + "");
                    ImageIcon icono = new ImageIcon("barcos3_1.jpg");
                    bMatriz2[posicion.getCoorX()][posicion.getCoorY()].setIcon(icono);
                    icono = new ImageIcon("barcos3_2.jpg");
                    bMatriz2[posicion.getCoorX()][posicion.getCoorY() + 1].setIcon(icono);
                    //     bMatriz2[coordenadaFinalX][coordeanadaFinalY].setText(3 + "");
                    icono = new ImageIcon("barcos3_3.jpg");
                    bMatriz2[posicion.getCoorX()][posicion.getCoorY() + 2].setIcon(icono);
                    Matriz2[posicion.getCoorX()][posicion.getCoorY()] = nuevo;
                    Matriz2[posicion.getCoorX()][posicion.getCoorY() + 1] = nuevo;
                    Matriz2[posicion.getCoorX()][posicion.getCoorY() + 2] = nuevo;

                } else {

                    ImageIcon icono = new ImageIcon("barcos3_1_vertical.jpg");
                    bMatriz2[posicion.getCoorX()][posicion.getCoorY()].setIcon(icono);
                    icono = new ImageIcon("barcos3_2_vertical.jpg");
                    bMatriz2[posicion.getCoorX() + 1][posicion.getCoorY()].setIcon(icono);
                    //     bMatriz2[coordenadaFinalX][coordeanadaFinalY].setText(3 + "");
                    icono = new ImageIcon("barcos3_3_vertical.jpg");
                    bMatriz2[posicion.getCoorX() + 2][posicion.getCoorY()].setIcon(icono);
                    Matriz2[posicion.getCoorX()][posicion.getCoorY()] = nuevo;
                    Matriz2[posicion.getCoorX() + 1][posicion.getCoorY()] = nuevo;
                    Matriz2[posicion.getCoorX() + 2][posicion.getCoorY()] = nuevo;

                }

            }
            if (tipobarco == Vocabulario.TipoBarco.PORTAAVIONES) {
                Barco nuevo = new Barco(tipobarco, posicion, orientacion);
                if (orientacion.equals(Vocabulario.Orientacion.HORIZONTAL)) {

                    ImageIcon icono = new ImageIcon("barcos4_1.jpg");
                    bMatriz2[posicion.getCoorX()][posicion.getCoorY()].setIcon(icono);
                    icono = new ImageIcon("barcos4_2.jpg");
                    bMatriz2[posicion.getCoorX()][posicion.getCoorY() + 1].setIcon(icono);
                    icono = new ImageIcon("barcos4_3.jpg");
                    bMatriz2[posicion.getCoorX()][posicion.getCoorY() + 2].setIcon(icono);
                    //     bMatriz2[coordenadaFinalX][coordeanadaFinalY].setText(3 + "");
                    icono = new ImageIcon("barcos4_4.jpg");
                    bMatriz2[posicion.getCoorX()][posicion.getCoorY() + 3].setIcon(icono);
                    Matriz2[posicion.getCoorX()][posicion.getCoorY()] = nuevo;
                    Matriz2[posicion.getCoorX()][posicion.getCoorY() + 1] = nuevo;
                    Matriz2[posicion.getCoorX()][posicion.getCoorY() + 2] = nuevo;
                    Matriz2[posicion.getCoorX()][posicion.getCoorY() + 3] = nuevo;

                } else {

                    ImageIcon icono = new ImageIcon("barcos4_1_vertical.jpg");
                    bMatriz2[posicion.getCoorX()][posicion.getCoorY()].setIcon(icono);
                    icono = new ImageIcon("barcos4_2_vertical.jpg");
                    bMatriz2[posicion.getCoorX() + 1][posicion.getCoorY()].setIcon(icono);
                    icono = new ImageIcon("barcos4_3_vertical.jpg");
                    bMatriz2[posicion.getCoorX() + 2][posicion.getCoorY()].setIcon(icono);
                    //     bMatriz2[coordenadaFinalX][coordeanadaFinalY].setText(3 + "");
                    icono = new ImageIcon("barcos4_4_vertical.jpg");
                    bMatriz2[posicion.getCoorX() + 3][posicion.getCoorY()].setIcon(icono);

                    Matriz2[posicion.getCoorX()][posicion.getCoorY()] = nuevo;
                    Matriz2[posicion.getCoorX() + 1][posicion.getCoorY()] = nuevo;
                    Matriz2[posicion.getCoorX() + 2][posicion.getCoorY()] = nuevo;
                    Matriz2[posicion.getCoorX() + 3][posicion.getCoorY()] = nuevo;

                }

            }

        }
    }

    public juegosTablero.Vocabulario.Efecto Disparar(String Jugador, int x, int y) {
        //fragata     1
        //destructor  2
        //acorazado  3
        //portaaviones  4

        if (Jugador.equals(this.Jugador1)) {

            if (Matriz2[x][y] != null) {

                //  bMatriz2[x][y].setText("*");
                if (Matriz2[x][y].getTipo().equals("FRAGATA")) {

                    ImageIcon icono = new ImageIcon("barcos1_quemado.jpg");
                    bMatriz2[x][y].setIcon(icono);

                }

                if (Matriz2[x][y].getTipo().equals("DESTRUCTOR")) {

                    if (Matriz2[x][y].isVertical()) {

                        int posicion = Matriz2[x][y].parteBarco(x, y);
                        ImageIcon icono = new ImageIcon("barcos2_" + posicion + "_quemado_vertical.jpg");
                        bMatriz2[x][y].setIcon(icono);

                    } else {

                        int posicion = Matriz2[x][y].parteBarco(x, y);
                        ImageIcon icono = new ImageIcon("barcos2_" + posicion + "_quemado.jpg");
                        bMatriz2[x][y].setIcon(icono);

                    }

                }
                if (Matriz2[x][y].getTipo().equals("ACORAZADO")) {

                    if (Matriz2[x][y].isVertical()) {

                        int posicion = Matriz2[x][y].parteBarco(x, y);
                        ImageIcon icono = new ImageIcon("barcos3_" + posicion + "_quemado_vertical.jpg");
                        bMatriz2[x][y].setIcon(icono);

                    } else {

                        int posicion = Matriz2[x][y].parteBarco(x, y);
                        ImageIcon icono = new ImageIcon("barcos3_" + posicion + "_quemado.jpg");
                        bMatriz2[x][y].setIcon(icono);

                    }

                }

                if (Matriz2[x][y].getTipo().equals("PORTAAVIONES")) {

                    if (Matriz2[x][y].isVertical()) {

                        int posicion = Matriz2[x][y].parteBarco(x, y);
                        ImageIcon icono = new ImageIcon("barcos4_" + posicion + "_quemado_vertical.jpg");
                        bMatriz2[x][y].setIcon(icono);

                    } else {

                        int posicion = Matriz2[x][y].parteBarco(x, y);
                        ImageIcon icono = new ImageIcon("barcos4_" + posicion + "_quemado.jpg");
                        bMatriz2[x][y].setIcon(icono);

                    }

                }
                area.append(Jugador+"\n");
                area.append("hizo blanco en la posicion " + x + " " + y + newline);
                area.setCaretPosition(area.getDocument().getLength());
                Matriz2[x][y].impacto();

                if (Matriz2[x][y].hundido()) {
                    area.append(Jugador+"\n");
                    area.append( "El barco se ha hundido" + x + " " + y + newline);
                    area.setCaretPosition(area.getDocument().getLength());
                    return Vocabulario.Efecto.HUNDIDO;

                } else {
                    return Vocabulario.Efecto.TOCADO;
                }

            } else {
                area.append(Jugador+"\n");
                area.append( "ha fallado el disparo a la posicion " + x + " " + y + newline);
                area.setCaretPosition(area.getDocument().getLength());
                return Vocabulario.Efecto.AGUA;
            }

        } else {

            if (Matriz1[x][y] != null) {

                //  bMatriz[x][y].setText("*");
                if (Matriz1[x][y].getTipo().equals("FRAGATA")) {
                    ImageIcon icono = new ImageIcon("barcos1_quemado.jpg");
                    bMatriz[x][y].setIcon(icono);
                }

                if (Matriz1[x][y].getTipo().equals("DESTRUCTOR")) {

                    if (Matriz1[x][y].isVertical()) {

                        int posicion = Matriz1[x][y].parteBarco(x, y);
                        ImageIcon icono = new ImageIcon("barcos2_" + posicion + "_quemado_vertical.jpg");
                        System.out.println(posicion + "vertical");
                        bMatriz[x][y].setIcon(icono);

                    } else {

                        int posicion = Matriz1[x][y].parteBarco(x, y);
                        System.out.println(posicion);
                        ImageIcon icono = new ImageIcon("barcos2_" + posicion + "_quemado.jpg");
                        bMatriz[x][y].setIcon(icono);

                    }

                }
                if (Matriz1[x][y].getTipo().equals("ACORAZADO")) {

                    if (Matriz1[x][y].isVertical()) {

                        int posicion = Matriz1[x][y].parteBarco(x, y);
                        ImageIcon icono = new ImageIcon("barcos3_" + posicion + "_quemado_vertical.jpg");
                        System.out.println(posicion + "vertical");
                        bMatriz[x][y].setIcon(icono);

                    } else {

                        int posicion = Matriz1[x][y].parteBarco(x, y);
                        System.out.println(posicion);
                        ImageIcon icono = new ImageIcon("barcos3_" + posicion + "_quemado.jpg");
                        bMatriz[x][y].setIcon(icono);

                    }

                }
                if (Matriz1[x][y].getTipo().equals("PORTAAVIONES")) {

                    if (Matriz1[x][y].isVertical()) {

                        int posicion = Matriz1[x][y].parteBarco(x, y);
                        ImageIcon icono = new ImageIcon("barcos4_" + posicion + "_quemado_vertical.jpg");
                        System.out.println(posicion + "vertical");
                        bMatriz[x][y].setIcon(icono);

                    } else {

                        int posicion = Matriz1[x][y].parteBarco(x, y);
                        System.out.println(posicion);
                        ImageIcon icono = new ImageIcon("barcos4_" + posicion + "_quemado.jpg");
                        bMatriz[x][y].setIcon(icono);

                    }

                }
                area.append(Jugador+"\n");
                area.append( "hizo blanco en la posicion " + x + " " + y + newline);
                area.setCaretPosition(area.getDocument().getLength());

                Matriz1[x][y].impacto();

                if (Matriz1[x][y].hundido()) {
                    area.append(Jugador+"\n");
                    area.append( "El barco se ha hundido " + x + " " + y + newline);
                    area.setCaretPosition(area.getDocument().getLength());
                    return Vocabulario.Efecto.HUNDIDO;
                } else {
                    return Vocabulario.Efecto.TOCADO;
                }

            } else {
                area.append(Jugador+"\n");
                area.append( "ha fallado el disparo a la posicion " + x + " " + y + newline);
                area.setCaretPosition(area.getDocument().getLength());
                return Vocabulario.Efecto.AGUA;

            }

        }

    }

    private tableroBarcos() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTextArea1 = new javax.swing.JTextArea();
        jLabel6 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jLabel1.setText("jLabel1");

        jLabel2.setText("Jugador1");

        jLabel3.setText("jLabel3");

        jLabel4.setText("Jugador2");

        jLabel5.setText("jLabel5");

        jTextArea1.setColumns(20);
        jTextArea1.setRows(5);
        jScrollPane1.setViewportView(jTextArea1);

        jLabel6.setText("jLabel6");

        jLabel7.setText("jLabel7");

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel1)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jLabel2)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jLabel3))
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jLabel4)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jLabel5)
                        .addGap(217, 217, 217)
                        .addComponent(jLabel6)
                        .addGap(236, 236, 236)
                        .addComponent(jLabel7))
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 357, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(557, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(19, 19, 19)
                .addComponent(jLabel1)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel2)
                    .addComponent(jLabel3))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel4)
                    .addComponent(jLabel5)
                    .addComponent(jLabel6)
                    .addComponent(jLabel7))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 210, Short.MAX_VALUE)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 117, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(94, 94, 94))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(tableroBarcos.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(tableroBarcos.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(tableroBarcos.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(tableroBarcos.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new tableroBarcos().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTextArea jTextArea1;
    // End of variables declaration//GEN-END:variables
}
