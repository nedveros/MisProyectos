package utilidades;

import jade.core.AID;
import jade.domain.FIPAAgentManagement.FailureException;
import jade.domain.FIPAAgentManagement.NotUnderstoodException;
import jade.domain.FIPAAgentManagement.RefuseException;
import jade.proto.SubscriptionResponder;
import java.util.HashMap;


/**
 *
 * @author  javiermq
 */
public class GestorSuscripciones extends HashMap<AID, SubscriptionResponder.Subscription> implements SubscriptionResponder.SubscriptionManager {
    
    public GestorSuscripciones() {
       super();
    }

    @Override
    public boolean register(SubscriptionResponder.Subscription s) throws RefuseException, NotUnderstoodException {
        try{
            this.put(s.getMessage().getSender(), s);
            return true;
        }catch(Exception e){
            e.printStackTrace();
            return false;
        }
    }

    @Override
    public boolean deregister(SubscriptionResponder.Subscription s) throws FailureException {
        try{
            this.remove(s.getMessage().getSender());
            s.close(); 
            return true;
        }catch(Exception e){
            e.printStackTrace();
            return false;
        }
    }
    
    public SubscriptionResponder.Subscription getSuscripcion( AID id ) {
        return this.get(id);
    }

}
