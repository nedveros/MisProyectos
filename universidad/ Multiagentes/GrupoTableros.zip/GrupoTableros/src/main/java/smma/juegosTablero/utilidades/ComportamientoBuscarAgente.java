package utilidades;
import jade.core.AID;
import jade.core.Agent;
import jade.core.behaviours.OneShotBehaviour;
import jade.core.behaviours.TickerBehaviour;
import jade.domain.DFService;
import jade.domain.FIPAAgentManagement.DFAgentDescription;
import jade.domain.FIPAAgentManagement.ServiceDescription;
import jade.domain.FIPAException;
import java.util.LinkedList;
import java.util.List;

/**
 *
 * @author  javiermq
 */
public class ComportamientoBuscarAgente extends OneShotBehaviour{

    final private String servicio;
    final private BusquedaAgentesInterfaz interfaz;
 
    public ComportamientoBuscarAgente(Agent a, String servicio, BusquedaAgentesInterfaz interfaz) {
        super(a);
        this.servicio=servicio;
        this.interfaz=interfaz;
    }

    @Override
    public void action() {
        System.out.println("Buscamos agentes");
        DFAgentDescription plantillaMensaje=new DFAgentDescription();
        ServiceDescription descServicio=new ServiceDescription();
        descServicio.setName(this.servicio);
        plantillaMensaje.addServices(descServicio);

        try {
           DFAgentDescription[] aidsResultado=DFService.search(myAgent, plantillaMensaje);
           List<AID> ret=null;
            if (aidsResultado!=null) {
                ret=new LinkedList<>();
              
                for (int i=0; i<aidsResultado.length; ++i) 
                    ret.add(aidsResultado[i].getName());
            }
            this.interfaz.finBusqueda(ret, this.servicio);
        }
        catch (FIPAException fe) {
            fe.printStackTrace();
        }
    }  
}
