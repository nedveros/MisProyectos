Asignatura Sistemas Multiagente
Grado en Ingeniería Informática de la Universidad de Jaén

Juegos del curso 2018-19

Se incluye el código para el AgenteCentralJuegos

Además se incluyen versiones de prueba para los agentes:
    - AgenteGrupoJuegos
    - AgenteJugador
