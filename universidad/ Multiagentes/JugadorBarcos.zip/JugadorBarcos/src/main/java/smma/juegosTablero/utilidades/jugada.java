/*
 * Copyright (C) 2019 davidbaudetmoreno
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

package utilidades;

import java.util.ArrayList;
import juegosTablero.dominio.elementos.Posicion;

/**
 *
 * @author davidbaudetmoreno
 */
public class jugada {
    
    public int ultimox=0;
    public int ultimoy=0;
    public String Estado ="AGUA";
    public int[][] matriz;
    private int tamañoAncho = 10;
    private int tamañoAlto= 10;
    public String movimiento ="";
  
    
    
    public ArrayList<Posicion> horizontal = new ArrayList<Posicion>();
    public ArrayList<Posicion> vertical = new ArrayList<Posicion>();
    
    
    
    //agua=0
    //visitada=1
    //tocado=2
    //hundido=3
    
    public jugada(){
    
    ultimox =0;
    ultimoy=0;
    Estado = "AGUA";
    matriz = new int[10][10];
    
    for(int i = 0 ; i < tamañoAncho ;i ++){
        for(int j = 0 ; j < tamañoAlto;j++){
        
            matriz[i][j]=0;
        
        }
    
    }
    
    
    }

    /**
     * @return the ultimox
     */
    public int getUltimox() {
        return ultimox;
    }

    /**
     * @param ultimox the ultimox to set
     */
    public void setUltimox(int ultimox) {
        this.ultimox = ultimox;
    }

    /**
     * @return the ultimoy
     */
    public int getUltimoy() {
        return ultimoy;
    }

    /**
     * @param ultimoy the ultimoy to set
     */
    public void setUltimoy(int ultimoy) {
        this.ultimoy = ultimoy;
    }

    /**
     * @return the Estado
     */
    public String getEstado() {
        return Estado;
    }

    /**
     * @param Estado the Estado to set
     */
    public void setEstado(String Estado) {
        this.Estado = Estado;
    }
    
    
    
    
}
