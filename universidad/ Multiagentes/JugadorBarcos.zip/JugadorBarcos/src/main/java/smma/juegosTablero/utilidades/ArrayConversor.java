/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package utilidades;

import jade.content.Concept;
import jade.util.leap.Iterator;

/**
 *
 * @author admin
 */
public class ArrayConversor {

    public static jade.util.leap.List fromJava2Jade(java.util.List<Concept> list) {
        jade.util.leap.ArrayList ret = new jade.util.leap.ArrayList();
        for (Concept c : list) {
            ret.add(c);
        }
        return ret;
    }

    public static <T> java.util.List<T> fromJade2Java(jade.util.leap.List list) {
        java.util.ArrayList<T> ret = new java.util.ArrayList<T>();
        for (Iterator it = list.iterator(); it.hasNext();) {
            T o2 = (T) it.next();
            ret.add(o2);
        }
        return ret;
    }
}
