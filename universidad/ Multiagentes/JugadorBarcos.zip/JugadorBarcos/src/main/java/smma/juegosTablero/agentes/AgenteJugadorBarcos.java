package smma.juegosTablero.agentes;

import com.sun.javafx.scene.control.behavior.BehaviorBase;
import jade.content.Concept;
import jade.content.ContentElement;
import jade.content.ContentManager;
import jade.content.Predicate;
import jade.content.lang.Codec;
import jade.content.lang.sl.SLCodec;
import jade.content.onto.BeanOntologyException;
import jade.content.onto.OntologyException;
import jade.content.onto.basic.Action;
import jade.core.AID;
import jade.core.Agent;
import jade.core.behaviours.TickerBehaviour;
import jade.domain.*;
import jade.domain.FIPAAgentManagement.DFAgentDescription;
import jade.domain.FIPAAgentManagement.FailureException;
import jade.domain.FIPAAgentManagement.NotUnderstoodException;
import jade.domain.FIPAAgentManagement.RefuseException;
import jade.domain.FIPAAgentManagement.ServiceDescription;
import jade.domain.FIPAException;
import jade.domain.FIPANames;
import jade.lang.acl.ACLMessage;
import jade.lang.acl.MessageTemplate;
import jade.proto.AchieveREResponder;
import jade.proto.ContractNetResponder;
import jade.proto.SimpleAchieveREResponder;
import jade.util.leap.List;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Random;
import java.util.logging.Level;
import java.util.logging.Logger;
import juegosTablero.Vocabulario;
import juegosTablero.Vocabulario.Efecto;

import juegosTablero.Vocabulario.NombreServicio;
import juegosTablero.aplicacion.OntologiaJuegoBarcos;
import juegosTablero.aplicacion.barcos.ColocarBarcos;
import juegosTablero.aplicacion.barcos.EstadoJuego;
import juegosTablero.aplicacion.barcos.JuegoBarcos;
import juegosTablero.aplicacion.barcos.Localizacion;
import juegosTablero.aplicacion.barcos.MovimientoEntregado;
import juegosTablero.aplicacion.barcos.PosicionBarcos;
import juegosTablero.aplicacion.barcos.Localizacion;
import juegosTablero.aplicacion.barcos.ResultadoMovimiento;
import juegosTablero.dominio.OntologiaJuegosTablero;
import juegosTablero.dominio.elementos.CompletarJuego;
import juegosTablero.dominio.elementos.JuegoAceptado;
import juegosTablero.dominio.elementos.Motivacion;
import juegosTablero.dominio.elementos.PedirMovimiento;
import juegosTablero.dominio.elementos.Posicion;
import juegosTablero.dominio.elementos.ProponerJuego;
import utilidades.ArrayConversor;
import utilidades.jugada;

public class AgenteJugadorBarcos extends AgenteOntologiaJuegos {

    private jade.content.onto.Ontology ontologiaBarcos;
    private jade.content.onto.Ontology ontologiaConecta4;
    private jade.content.onto.Ontology ontologiaDomino;
    private jade.content.onto.Ontology ontologiaDominio;
    private final jade.content.lang.Codec codec = new SLCodec();
    private final jade.content.ContentManager managerBarcos = (ContentManager) getContentManager();
    private final jade.content.ContentManager managerConecta4 = (ContentManager) getContentManager();
    private final jade.content.ContentManager managerDomino = (ContentManager) getContentManager();
    private final jade.content.ContentManager managerDominio = (ContentManager) getContentManager();
    private HashMap<String, Integer> numHundidos;

    private final int numBarcos = 9;
    private HashMap<String, Boolean> ultimoMovimientoMio;
    private HashMap<String, Efecto[][]> tableros;
    private HashMap<String, jugada> jugadas;
    private final int MAXJUEGOS = 5;
    private int numPartidas;

    public AgenteJugadorBarcos() {

    }

    public Posicion realizarJugada(String id) {
        Random a = new Random();
        Posicion pos = null;

        if (jugadas.get(id).getEstado().equals("AGUA") && !jugadas.get(id).horizontal.isEmpty() && !jugadas.get(id).vertical.isEmpty()) {

            if (!jugadas.get(id).horizontal.isEmpty()) {

                pos = new Posicion(jugadas.get(id).horizontal.get(0).getCoorX(), jugadas.get(id).horizontal.get(0).getCoorY());

                jugadas.get(id).movimiento = "HORIZONTAL";
                jugadas.get(id).horizontal.remove(0);
                jugadas.get(id).matriz[pos.getCoorX()][pos.getCoorY()] = 1;
                return pos;
            }
            if (!jugadas.get(id).vertical.isEmpty()) {

                pos = new Posicion(jugadas.get(id).vertical.get(0).getCoorX(), jugadas.get(id).vertical.get(0).getCoorY());

                jugadas.get(id).movimiento = "VERTICAL";
                jugadas.get(id).vertical.remove(0);
                jugadas.get(id).matriz[pos.getCoorX()][pos.getCoorY()] = 1;
                return pos;
            }

        } else if (jugadas.get(id).getEstado().equals("AGUA") && jugadas.get(id).horizontal.isEmpty() && jugadas.get(id).vertical.isEmpty()) {
            int x = 0;
            int y = 0;
            boolean bandera = false;

            while (!bandera) {

                x = a.nextInt(tableros.get(id).length);
                y = a.nextInt(tableros.get(id).length);

                if (jugadas.get(id).matriz[x][y] == 0) {

                    //disparo
                    pos = new Posicion(x, y);
                    jugadas.get(id).matriz[pos.getCoorX()][pos.getCoorY()] = 1;
                    return pos;

                }

            }

        } else if (jugadas.get(id).getEstado().equals("TOCADO")) {

            if (!jugadas.get(id).movimiento.equals("")) {
                if (jugadas.get(id).movimiento.equals("HORIZONTAL")) {

                    jugadas.get(id).vertical.clear();

                } else {

                    jugadas.get(id).horizontal.clear();

                }
            }

            if (jugadas.get(id).ultimox - 1 >= 0) {

                if (jugadas.get(id).matriz[jugadas.get(id).ultimox - 1][jugadas.get(id).ultimoy] == 0) {

                    jugadas.get(id).horizontal.add(new Posicion(jugadas.get(id).ultimox - 1, jugadas.get(id).ultimoy));
                }
            }

            if (jugadas.get(id).ultimox + 1 < 10) {

                if (jugadas.get(id).matriz[jugadas.get(id).ultimox + 1][jugadas.get(id).ultimoy] == 0) {
                    jugadas.get(id).horizontal.add(new Posicion(jugadas.get(id).ultimox + 1, jugadas.get(id).ultimoy));
                }
            }

            if (jugadas.get(id).ultimoy - 1 >= 0) {
                if (jugadas.get(id).matriz[jugadas.get(id).ultimox][jugadas.get(id).ultimoy - 1] == 0) {
                    jugadas.get(id).vertical.add(new Posicion(jugadas.get(id).ultimox, jugadas.get(id).ultimoy - 1));
                }
            }

            if (jugadas.get(id).ultimoy + 1 < 10) {
                if (jugadas.get(id).matriz[jugadas.get(id).ultimox][jugadas.get(id).ultimoy + 1] == 0) {
                    jugadas.get(id).vertical.add(new Posicion(jugadas.get(id).ultimox, jugadas.get(id).ultimoy + 1));
                }
            }

            if (!jugadas.get(id).horizontal.isEmpty()) {

                pos = new Posicion(jugadas.get(id).horizontal.get(0).getCoorX(), jugadas.get(id).horizontal.get(0).getCoorY());

                jugadas.get(id).horizontal.remove(0);
                jugadas.get(id).matriz[pos.getCoorX()][pos.getCoorY()] = 1;

                return pos;
            }
            if (!jugadas.get(id).vertical.isEmpty()) {

                pos = new Posicion(jugadas.get(id).vertical.get(0).getCoorX(), jugadas.get(id).vertical.get(0).getCoorY());

                jugadas.get(id).vertical.remove(0);
                jugadas.get(id).matriz[pos.getCoorX()][pos.getCoorY()] = 1;

                return pos;
            }

            if (jugadas.get(id).vertical.size() == 0 && jugadas.get(id).horizontal.size() == 0) {

                int x = 0;
                int y = 0;
                boolean bandera = false;

                while (!bandera) {

                    x = a.nextInt(tableros.get(id).length);
                    y = a.nextInt(tableros.get(id).length);

                    if (jugadas.get(id).matriz[x][y] == 0) {

                        //disparo
                        pos = new Posicion(x, y);
                        jugadas.get(id).matriz[pos.getCoorX()][pos.getCoorY()] = 1;
                        return pos;

                    }

                }

            }

            return pos;
        }

        int x = 0;
        int y = 0;
        boolean bandera = false;

        while (!bandera) {

            x = a.nextInt(tableros.get(id).length);
            y = a.nextInt(tableros.get(id).length);

            if (jugadas.get(id).matriz[x][y] == 0) {

                //disparo
                pos = new Posicion(x, y);
                jugadas.get(id).matriz[pos.getCoorX()][pos.getCoorY()] = 1;
                bandera = true;

            }

        }
        return pos;
    }

    public java.util.List<Concept> localizaciones() {
        java.util.List<Concept> localizaciones = new ArrayList<>();

        double random = Math.random();
        if (random <= 0.5) {

            Localizacion fragataPrimera = new Localizacion(Vocabulario.TipoBarco.FRAGATA, new Posicion(9, 0), Vocabulario.Orientacion.HORIZONTAL);
            localizaciones.add(fragataPrimera);
            Localizacion fragataSegunda = new Localizacion(Vocabulario.TipoBarco.FRAGATA, new Posicion(6, 4), Vocabulario.Orientacion.HORIZONTAL);
            localizaciones.add(fragataSegunda);
            Localizacion destructorPrimero = new Localizacion(Vocabulario.TipoBarco.DESTRUCTOR, new Posicion(7, 1), Vocabulario.Orientacion.HORIZONTAL);
            localizaciones.add(destructorPrimero);
            Localizacion destructorSegundo = new Localizacion(Vocabulario.TipoBarco.DESTRUCTOR, new Posicion(9, 2), Vocabulario.Orientacion.HORIZONTAL);
            localizaciones.add(destructorSegundo);
            Localizacion destructorTercero = new Localizacion(Vocabulario.TipoBarco.DESTRUCTOR, new Posicion(4, 7), Vocabulario.Orientacion.HORIZONTAL);
            localizaciones.add(destructorTercero);
            Localizacion acorazadoPrimero = new Localizacion(Vocabulario.TipoBarco.ACORAZADO, new Posicion(3, 1), Vocabulario.Orientacion.VERTICAL);
            localizaciones.add(acorazadoPrimero);
            Localizacion acorazadoSegundo = new Localizacion(Vocabulario.TipoBarco.ACORAZADO, new Posicion(4, 3), Vocabulario.Orientacion.HORIZONTAL);
            localizaciones.add(acorazadoSegundo);
            Localizacion acorazadoTercero = new Localizacion(Vocabulario.TipoBarco.ACORAZADO, new Posicion(6, 6), Vocabulario.Orientacion.HORIZONTAL);
            localizaciones.add(acorazadoTercero);
            Localizacion portaAviones = new Localizacion(Vocabulario.TipoBarco.PORTAAVIONES, new Posicion(9, 6), Vocabulario.Orientacion.HORIZONTAL);
            localizaciones.add(portaAviones);

        } else {

            Localizacion fragataPrimera = new Localizacion(Vocabulario.TipoBarco.FRAGATA, new Posicion(8, 2), Vocabulario.Orientacion.HORIZONTAL);
            localizaciones.add(fragataPrimera);
            Localizacion fragataSegunda = new Localizacion(Vocabulario.TipoBarco.FRAGATA, new Posicion(8, 6), Vocabulario.Orientacion.HORIZONTAL);
            localizaciones.add(fragataSegunda);
            Localizacion destructorPrimero = new Localizacion(Vocabulario.TipoBarco.DESTRUCTOR, new Posicion(0, 0), Vocabulario.Orientacion.VERTICAL);
            localizaciones.add(destructorPrimero);
            Localizacion destructorSegundo = new Localizacion(Vocabulario.TipoBarco.DESTRUCTOR, new Posicion(0, 8), Vocabulario.Orientacion.HORIZONTAL);
            localizaciones.add(destructorSegundo);
            Localizacion destructorTercero = new Localizacion(Vocabulario.TipoBarco.DESTRUCTOR, new Posicion(2, 4), Vocabulario.Orientacion.VERTICAL);
            localizaciones.add(destructorTercero);
            Localizacion acorazadoPrimero = new Localizacion(Vocabulario.TipoBarco.ACORAZADO, new Posicion(3, 0), Vocabulario.Orientacion.VERTICAL);
            localizaciones.add(acorazadoPrimero);
            Localizacion acorazadoSegundo = new Localizacion(Vocabulario.TipoBarco.ACORAZADO, new Posicion(4, 2), Vocabulario.Orientacion.VERTICAL);
            localizaciones.add(acorazadoSegundo);
            Localizacion acorazadoTercero = new Localizacion(Vocabulario.TipoBarco.ACORAZADO, new Posicion(4, 6), Vocabulario.Orientacion.VERTICAL);
            localizaciones.add(acorazadoTercero);
            Localizacion portaAviones = new Localizacion(Vocabulario.TipoBarco.PORTAAVIONES, new Posicion(5, 4), Vocabulario.Orientacion.VERTICAL);
            localizaciones.add(portaAviones);

        }

        return localizaciones;
    }

    protected void setup() {
        super.setup();
        //Inicialización de las variables del agente
        tableros = new HashMap<>();
        numHundidos = new HashMap<>();
        jugadas = new HashMap<>();
        ultimoMovimientoMio = new HashMap<>();
        numPartidas = 0;
        //MEnsaje con ontologia
        //mensaje.setLanguage(codec.getName());
        //mensaje.setOntology(ontologiaBarcos.getName());
        //Configuración del GUI
        //Registro del agente en las Páginas Amarrillas
        DFAgentDescription dfd = new DFAgentDescription();
        dfd.setName(getAID());
        ServiceDescription sd = new ServiceDescription();
        sd.setType(juegosTablero.Vocabulario.TIPO_SERVICIO);
        sd.setName(NombreServicio.JUEGO_BARCOS.toString());
        dfd.addServices(sd);
        try {
            DFService.register(this, dfd);
        } catch (FIPAException fe) {
            fe.printStackTrace();
        }

        try {
            //Registro de la Ontología
            ontologiaDominio = OntologiaJuegosTablero.getInstance();
            ontologiaBarcos = juegosTablero.aplicacion.OntologiaJuegoBarcos.getInstance();
            ontologiaConecta4 = juegosTablero.aplicacion.OntologiaJuegoConecta4.getInstance();
            ontologiaDomino = juegosTablero.aplicacion.OntologiaJuegoDomino.getInstance();
        } catch (BeanOntologyException ex) {
            Logger.getLogger(AgenteJugadorBarcos.class.getName()).log(Level.SEVERE, null, ex);
        }

        managerDominio.registerLanguage(codec);
        managerDominio.registerOntology(ontologiaDominio);
        managerBarcos.registerLanguage(codec);
        managerBarcos.registerOntology(ontologiaBarcos);
        managerConecta4.registerLanguage(codec);
        managerConecta4.registerOntology(ontologiaConecta4);
        managerDomino.registerLanguage(codec);
        managerDomino.registerOntology(ontologiaDomino);

        //Tareas
        MessageTemplate template = MessageTemplate.and(
                MessageTemplate.MatchProtocol(FIPANames.InteractionProtocol.FIPA_PROPOSE),
                MessageTemplate.MatchPerformative(ACLMessage.PROPOSE));

        addBehaviour(new JugadorResponder(this, template));

        MessageTemplate template2 = MessageTemplate.and(
                MessageTemplate.MatchProtocol(FIPANames.InteractionProtocol.FIPA_CONTRACT_NET),
                MessageTemplate.MatchPerformative(ACLMessage.CFP));

        addBehaviour(new JugadorContractNet(this, template2));

    }

    protected void takeDown() {
        // <editor-fold defaultstate="collapsed" desc="Compiled Code">
        /* 0: aload_0
         * 1: invokestatic  jade/domain/DFService.deregister:(Ljade/core/Agent;)V
         * 4: goto          12
         * 7: astore_1
         * 8: aload_1
         * 9: invokevirtual jade/domain/FIPAException.printStackTrace:()V
         * 12: getstatic     java/lang/System.out:Ljava/io/PrintStream;
         * 15: new           java/lang/StringBuilder
         * 18: dup
         * 19: invokespecial java/lang/StringBuilder."<init>":()V
         * 22: ldc           Finaliza la ejecución de
         * 24: invokevirtual java/lang/StringBuilder.append:(Ljava/lang/String;)Ljava/lang/StringBuilder;
         * 27: aload_0
         * 28: invokevirtual juegosTablero/AgentePrueba.getName:()Ljava/lang/String;
         * 31: invokevirtual java/lang/StringBuilder.append:(Ljava/lang/String;)Ljava/lang/StringBuilder;
         * 34: invokevirtual java/lang/StringBuilder.toString:()Ljava/lang/String;
         * 37: invokevirtual java/io/PrintStream.println:(Ljava/lang/String;)V
         * 40: return
         * Exception table:
         * from    to  target type
         * 0     4     7   Class jade/domain/FIPAException
         *  */
        // </editor-fold>
    }

    private boolean checkAction() {
        if (numPartidas < MAXJUEGOS) {
            return true;
        } else {
            return false;
        }
    }

    private class JugadorResponder extends SimpleAchieveREResponder {

        public JugadorResponder(Agent a, MessageTemplate mt) {
            super(a, mt);
        }

        @Override
        protected ACLMessage prepareResponse(ACLMessage propose) throws NotUnderstoodException, RefuseException {

            ACLMessage respuesta = propose.createReply();

            respuesta.setLanguage(codec.getName());
            respuesta.setOntology(ontologiaBarcos.getName());

            ProponerJuego proponerJuego = null;

            try {
                //Extraemos el contenido del mensaje propose recibido
                ContentElement content = extraerMensaje(propose);
                if (content instanceof Action) {
                    if (((Action) content).getAction() instanceof ProponerJuego) {
                        proponerJuego = (ProponerJuego) ((Action) content).getAction();
                        //Acepta jugar
                        if (checkAction()) {
                            numPartidas++;
                            System.out.println("Agent " + getLocalName() + ": Accept");
                            respuesta.setPerformative(ACLMessage.ACCEPT_PROPOSAL);
                            JuegoAceptado aceptado = new JuegoAceptado(proponerJuego.getJuego(), new juegosTablero.dominio.elementos.Jugador(myAgent.getName(), myAgent.getAID()));
                            JuegoBarcos inforJuego = (JuegoBarcos) proponerJuego.getTipoJuego();
                            Efecto tabl[][] = new Efecto[inforJuego.getTablero().getDimX()][inforJuego.getTablero().getDimY()];
                            for (int i = 0; i < inforJuego.getTablero().getDimX(); i++) {
                                for (int j = 0; j < inforJuego.getTablero().getDimY(); j++) {
                                    tabl[i][j] = Efecto.AGUA;
                                }
                            }
                            tableros.put(proponerJuego.getJuego().getIdJuego(), tabl);
                            //Incluir contenido del mensaje
                            try {
                                managerBarcos.fillContent(respuesta, aceptado);
                            } catch (Codec.CodecException ex) {
                                Logger.getLogger(AgenteJugadorBarcos.class.getName()).log(Level.SEVERE, null, ex);
                            } catch (OntologyException ex) {
                                Logger.getLogger(AgenteJugadorBarcos.class.getName()).log(Level.SEVERE, null, ex);
                            }

                            return respuesta;
                        } else {
                            //Rechazar juego 
                            System.out.println("Agent " + getLocalName() + ": reject");
                            respuesta.setPerformative(ACLMessage.REJECT_PROPOSAL);

                            Motivacion motivacion = new Motivacion(proponerJuego.getJuego(), juegosTablero.Vocabulario.Motivo.JUEGOS_ACTIVOS_SUPERADOS);
                            try {
                                managerBarcos.fillContent(respuesta, motivacion);
                            } catch (Codec.CodecException ex) {
                                Logger.getLogger(AgenteJugadorBarcos.class.getName()).log(Level.SEVERE, null, ex);
                            } catch (OntologyException ex) {
                                Logger.getLogger(AgenteJugadorBarcos.class.getName()).log(Level.SEVERE, null, ex);
                            }

                            return respuesta;
                        }
                    } else if (((Action) content).getAction() instanceof ColocarBarcos) {
                        ColocarBarcos colocacionBarcos = (ColocarBarcos) ((Action) content).getAction();
                        //Devolver un posicionBarcos
                        if (checkAction()) {

                            System.out.println("Agent " + getLocalName() + ": Accept");
                            respuesta.setPerformative(ACLMessage.ACCEPT_PROPOSAL);
                            numHundidos.put(colocacionBarcos.getJuego().getIdJuego(), 0);
                            jugada nueva = new jugada();
                            jugadas.put(colocacionBarcos.getJuego().getIdJuego(), nueva);
                            ultimoMovimientoMio.put(colocacionBarcos.getJuego().getIdJuego(), false);
                            PosicionBarcos posBarcos = new PosicionBarcos(colocacionBarcos.getJuego(), ArrayConversor.fromJava2Jade(localizaciones()));
                            //Incluir contenido del mensaje
                            try {
                                managerBarcos.fillContent(respuesta, posBarcos);
                            } catch (Codec.CodecException ex) {
                                Logger.getLogger(AgenteJugadorBarcos.class.getName()).log(Level.SEVERE, null, ex);
                            } catch (OntologyException ex) {
                                Logger.getLogger(AgenteJugadorBarcos.class.getName()).log(Level.SEVERE, null, ex);
                            }
                            return respuesta;
                        } else {
                            //Rechazar juego 
                            System.out.println("Agent " + getLocalName() + ": reject");
                            respuesta.setPerformative(ACLMessage.REJECT_PROPOSAL);

                            Motivacion motivacion = new Motivacion(proponerJuego.getJuego(), juegosTablero.Vocabulario.Motivo.JUEGOS_ACTIVOS_SUPERADOS);
                            try {
                                managerBarcos.fillContent(respuesta, motivacion);
                            } catch (Codec.CodecException ex) {
                                Logger.getLogger(AgenteJugadorBarcos.class.getName()).log(Level.SEVERE, null, ex);
                            } catch (OntologyException ex) {
                                Logger.getLogger(AgenteJugadorBarcos.class.getName()).log(Level.SEVERE, null, ex);
                            }

                            return respuesta;
                        }
                    } else {
                        System.out.println("No entiendo en el mensaje 1");
                        throw new NotUnderstoodException(propose.getOntology());
                    }
                } else {
                    System.out.println("No entiendo en el mensaje 2");
                    throw new NotUnderstoodException(propose.getOntology());
                }
            } catch (Exception ex) {
                Logger.getLogger(AgenteJugadorBarcos.class.getName()).log(Level.SEVERE, null, ex);
            }
            return respuesta;

        }

    }

    private class JugadorContractNet extends ContractNetResponder {

        public JugadorContractNet(Agent a, MessageTemplate mt) {
            super(a, mt);
        }

        protected ACLMessage prepareResponse(ACLMessage cfp) throws NotUnderstoodException, RefuseException {
            PedirMovimiento pedida = null;

            ACLMessage propose = cfp.createReply();
            propose.setOntology(ontologiaBarcos.getName());
            propose.setLanguage(codec.getName());
            propose.setSender(myAgent.getAID());
            propose.setPerformative(ACLMessage.PROPOSE);

            try {
                //Extraemos el contenido del mensaje propose recibido
                ContentElement content = extraerMensaje(cfp);
                if (content instanceof Action) {
                    if (((Action) content).getAction() instanceof PedirMovimiento) {
                        pedida = (PedirMovimiento) ((Action) content).getAction();
                        if (myAgent.getAID().equals(pedida.getJugadorActivo().getAgenteJugador())) {
                            ultimoMovimientoMio.put(pedida.getJuego().getIdJuego(), true);
                            Posicion pos = realizarJugada(pedida.getJuego().getIdJuego());
                            MovimientoEntregado movimiento = new MovimientoEntregado(pedida.getJuego(), pos);
                            managerBarcos.fillContent(propose, movimiento);
                        } else {
                        }
                        return propose;
                    } else {
                        System.out.println("No entiendo en el mensaje 1");
                        throw new NotUnderstoodException(cfp.getOntology());
                    }
                } else {
                    System.out.println("No entiendo en el mensaje 2");
                    throw new NotUnderstoodException(cfp.getOntology());
                }
            } catch (Exception ex) {
                Logger.getLogger(AgenteJugadorBarcos.class.getName()).log(Level.SEVERE, null, ex);
            }
            return null;
        }

        @Override
        protected ACLMessage handleAcceptProposal(ACLMessage cfp, ACLMessage propose, ACLMessage accept) throws FailureException {
            ResultadoMovimiento resultado = null;
            ACLMessage msg = accept.createReply();
            msg.setOntology(ontologiaBarcos.getName());
            msg.setLanguage(codec.getName());
            msg.setSender(myAgent.getAID());
            msg.setPerformative(ACLMessage.INFORM);

            try {
                //Extraemos el contenido del mensaje propose recibido
                ContentElement content = extraerMensaje(accept);
                if (content instanceof Predicate) {
                    if (((Predicate) content) instanceof ResultadoMovimiento) {
                        resultado = (ResultadoMovimiento) ((Predicate) content);
                        if (ultimoMovimientoMio.get(resultado.getJuego().getIdJuego())) {
                            Efecto tabl[][] = tableros.get(resultado.getJuego().getIdJuego());
                            tabl[resultado.getMovimiento().getCoorX()][resultado.getMovimiento().getCoorY()] = resultado.getResultado();
                            tableros.put(resultado.getJuego().getIdJuego(), tabl);
                            ultimoMovimientoMio.put(resultado.getJuego().getIdJuego(), false);
                            if (resultado.getResultado().equals(Efecto.HUNDIDO)) {

                                jugadas.get(resultado.getJuego().getIdJuego()).ultimox = resultado.getMovimiento().getCoorX();
                                jugadas.get(resultado.getJuego().getIdJuego()).ultimoy = resultado.getMovimiento().getCoorY();
                                jugadas.get(resultado.getJuego().getIdJuego()).Estado = "HUNDIDO";
                                jugadas.get(resultado.getJuego().getIdJuego()).horizontal.clear();
                                jugadas.get(resultado.getJuego().getIdJuego()).vertical.clear();
                                if (!numHundidos.containsKey(resultado.getJuego().getIdJuego())) {
                                    numHundidos.put(resultado.getJuego().getIdJuego(), 0);
                                }
                                int hundidos = numHundidos.get(resultado.getJuego().getIdJuego()) + 1;
                                numHundidos.put(resultado.getJuego().getIdJuego(), hundidos);
                                if (hundidos == numBarcos) {
                                    EstadoJuego estado = new EstadoJuego(resultado.getJuego(), Vocabulario.Estado.GANADOR);
                                    managerBarcos.fillContent(msg, estado);
                                    numPartidas--;
                                    return msg;
                                }
                            } else if (resultado.getResultado().equals(Efecto.TOCADO)) {

                                jugadas.get(resultado.getJuego().getIdJuego()).Estado = "TOCADO";
                                jugadas.get(resultado.getJuego().getIdJuego()).ultimox = resultado.getMovimiento().getCoorX();
                                jugadas.get(resultado.getJuego().getIdJuego()).ultimoy = resultado.getMovimiento().getCoorY();

                                if (jugadas.get(resultado.getJuego().getIdJuego()).movimiento.equals("HORIZONTAL")) {
                                    jugadas.get(resultado.getJuego().getIdJuego()).vertical.clear();

                                } else if (jugadas.get(resultado.getJuego().getIdJuego()).movimiento.equals("VERTICAL")) {
                                    jugadas.get(resultado.getJuego().getIdJuego()).horizontal.clear();

                                }

                            } else {

                                jugadas.get(resultado.getJuego().getIdJuego()).Estado = "AGUA";
                                jugadas.get(resultado.getJuego().getIdJuego()).ultimox = resultado.getMovimiento().getCoorX();
                                jugadas.get(resultado.getJuego().getIdJuego()).ultimoy = resultado.getMovimiento().getCoorY();

                            }
                            //Actualizar variables
                        }

                        EstadoJuego estado = new EstadoJuego(resultado.getJuego(), Vocabulario.Estado.SEGUIR_JUGANDO);
                        managerBarcos.fillContent(msg, estado);
                        return msg;
                    } else {
                        System.out.println("No entiendo en el mensaje 1");
                        throw new NotUnderstoodException(accept.getOntology());
                    }
                } else {
                    System.out.println("No entiendo en el mensaje 2");
                    throw new NotUnderstoodException(accept.getOntology());
                }
            } catch (Exception ex) {
                Logger.getLogger(AgenteJugadorBarcos.class.getName()).log(Level.SEVERE, null, ex);
            }

            return null;
        }

    }

}
